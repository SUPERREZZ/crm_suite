<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */


if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

//the left value is the key stored in the db and the right value is ie display value
//to translate, only modify the right value in each key/value pair
$app_list_strings = array(
//e.g. auf Deutsch 'Contacts'=>'Contakten',
    'language_pack_name' => 'Bahasa Indonesia - id_ID',
    'moduleList' => array(
        'Home' => 'Rumah',
        'ResourceCalendar' => 'Kalender Sumber Daya',
        'Contacts' => 'Contacts',
        'Accounts' => 'Akun',
        'Alerts' => 'Peringatan',
        'Opportunities' => 'Peluang',
        'Cases' => 'Kasus',
        'Notes' => 'Catatan',
        'Calls' => 'Panggilan Telepon',
        'TemplateSectionLine' => 'Pola Garis Bagian',
        'Calls_Reschedule' => 'Jadwal Ulang Panggilan',
        'Emails' => 'Email',
        'EAPM' => 'EAPM',
        'Meetings' => 'Rapat',
        'Tasks' => 'Tugas',
        'Calendar' => 'Kalender',
        'Leads' => 'Leads',
        'Currencies' => 'Mata Uang',
        'Activities' => 'Activities',
        'Bugs' => 'Kerusakan',
        'Feeds' => 'RSS',
        'iFrames' => 'Site SAya',
        'TimePeriods' => 'Periode Waktu',
        'ContractTypes' => 'Jenis Kontrak',
        'Schedulers' => 'Penjadwalan',
        'Project' => 'Projects',
        'ProjectTask' => 'Tugas Proyek',
        'Campaigns' => 'Kampanye',
        'CampaignLog' => 'Log Kampanye',
        'Documents' => 'Dokumen',
        'DocumentRevisions' => 'Revisi Dokumen',
        'Connectors' => 'Pengaturan Connector',
        'Roles' => 'Peran',
        'Notifications' => 'Notifikasi',
        'Sync' => 'Sinkronisasi',
        'Users' => 'Pengguna',
        'Employees' => 'Karyawan',
        'Administration' => 'Administration',
        'ACLRoles' => 'Roles',
        'InboundEmail' => 'Akun Email Masuk',
        'Releases' => 'Pers',
        'Prospects' => 'Target',
        'Queues' => 'Antri',
        'EmailMarketing' => 'Email Pemasaran',
        'EmailTemplates' => 'Email - Template',
        'ProspectLists' => 'Sasaran - Daftar',
        'SavedSearch' => 'Pencarian Tersimpan',
        'UpgradeWizard' => 'Pemandu Upgrade',
        'Trackers' => 'Pemantau',
        'TrackerSessions' => 'Tracker Sesi',
        'TrackerQueries' => 'Tracker Query',
        'FAQ' => 'Pertanyaan Yang Sering Diajukan',
        'Newsletters' => 'Laporan',
        'SugarFeed' => 'SuiteCRM Pemasok',
        'SugarFavorites' => 'SuiteCRM Favorit',

        'OAuthKeys' => 'OAuth Consumer Keys',
        'OAuthTokens' => 'OAuth Tokens',
        'OAuth2Clients' => 'OAuth klien',
        'OAuth2Tokens' => 'Token OAuth',
    ),

    'moduleListSingular' => array(
        'Home' => 'Home',
        'Dashboard' => 'Dasbor',
        'Contacts' => 'Kontak',
        'Accounts' => 'Akun',
        'Opportunities' => 'Peluang',
        'Cases' => 'Kasus',
        'Notes' => 'Catatan',
        'Calls' => 'Panggilan',
        'Emails' => 'Surel',
        'EmailTemplates' => 'Template Email',
        'Meetings' => 'Rapat',
        'Tasks' => 'Tugas',
        'Calendar' => 'Calendar',
        'Leads' => 'Pengantar',
        'Activities' => 'Aktivitas',
        'History' => 'History',
        'Bugs' => 'Kerusakan',
        'KBDocuments' => 'Knowledge Base',
        'Feeds' => 'RSS',
        'iFrames' => 'My Sites',
        'TimePeriods' => 'Periode Waktu',
        'Project' => 'Proyek',
        'ProjectTask' => 'Tugas Proyek',
        'Prospects' => 'Sasaran',
        'Campaigns' => 'Kampanye',
        'Documents' => 'Document',
        'Sync' => 'Sinkronisasi',
        'Users' => 'User',
        'SugarFavorites' => 'SuiteCRM Favorit',

    ),

    'checkbox_dom' => array(
        '' => '',
        '1' => 'Ya',
        '2' => 'Tidak',
    ),

    //e.g. en français 'Analyst'=>'Analyste',
    'account_type_dom' => array(
        '' => '',
        'Analyst' => 'Analyst',
        'Competitor' => 'Competitor',
        'Customer' => 'Customer',
        'Integrator' => 'Integrator',
        'Investor' => 'Investor',
        'Partner' => 'Partner',
        'Press' => 'Press',
        'Prospect' => 'Prospect',
        'Reseller' => 'Reseller',
        'Other' => 'Other',
    ),
    //e.g. en español 'Apparel'=>'Ropa',
    'industry_dom' => array(
        '' => '',
        'Apparel' => 'Pakaian',
        'Banking' => 'Per-bank-an',
        'Biotechnology' => 'Bioteknologi',
        'Chemicals' => 'Bahan Kimia',
        'Communications' => 'Komunikasi',
        'Construction' => 'Konstruksi',
        'Consulting' => 'Konsultasi',
        'Education' => 'Pendidikan',
        'Electronics' => 'Elektronik',
        'Energy' => 'Energi',
        'Engineering' => 'Ahli Teknik',
        'Entertainment' => 'Hiburan',
        'Environmental' => 'Lingkungan',
        'Finance' => 'Keuangan',
        'Government' => 'Pemerintahan',
        'Healthcare' => 'Kesehatan',
        'Hospitality' => 'Rumah Sakit',
        'Insurance' => 'Asuransi',
        'Machinery' => 'Mesin',
        'Manufacturing' => 'Produksi',
        'Media' => 'Media',
        'Not For Profit' => 'Lembaga Sosial Masyarakat',
        'Recreation' => 'Rekreasi',
        'Retail' => 'Eceran',
        'Shipping' => 'Pengiriman',
        'Technology' => 'Teknologi',
        'Telecommunications' => 'Telekomunikasi',
        'Transportation' => 'Transportasi',
        'Utilities' => 'Perkakas',
        'Other' => 'Other',
    ),
    'lead_source_default_key' => 'Self Generated',
    'lead_source_dom' => array(
        '' => '',
        'Cold Call' => 'Panggilan Baru',
        'Existing Customer' => 'Customer yang ada',
        'Self Generated' => 'Self Generated',
        'Employee' => 'Karyawan',
        'Partner' => 'Partner',
        'Public Relations' => 'Humas',
        'Direct Mail' => 'Surat Langsung',
        'Conference' => 'Konferensi',
        'Trade Show' => 'Pameran',
        'Web Site' => 'Situs Web',
        'Word of mouth' => 'Mulut ke Mulut',
        'Email' => 'Surel',
        'Campaign' => 'Campaign',
        'Other' => 'Other',
    ),
    'opportunity_type_dom' => array(
        '' => '',
        'Existing Business' => 'Existing Business',
        'New Business' => 'New Business',
    ),
    'roi_type_dom' => array(
        'Revenue' => 'Hasil',
        'Investment' => 'Investasi',
        'Expected_Revenue' => 'Hasil Yang Diharapkan',
        'Budget' => 'Anggaran',

    ),
    'subpanel_pagination_type' => [
        'pagination' => 'Pagination',
        'load-more' => 'Load More'
    ],
    'listview_pagination_type' => [
        'pagination' => 'Pagination',
        'load-more' => 'Load More'
    ],
    'record_modal_pagination_type' => [
        'pagination' => 'Pagination',
        'load-more' => 'Load More'
    ],
    //Note:  do not translate opportunity_relationship_type_default_key
//       it is the key for the default opportunity_relationship_type_dom value
    'opportunity_relationship_type_default_key' => 'Primary Decision Maker',
    'opportunity_relationship_type_dom' => array(
        '' => '',
        'Primary Decision Maker' => 'Primary Decision Maker',
        'Business Decision Maker' => 'Pembuat Keputusan Bisnis',
        'Business Evaluator' => 'Penilai Bisnis',
        'Technical Decision Maker' => 'Pembuat Keputusan Teknis',
        'Technical Evaluator' => 'Penilai Teknis',
        'Executive Sponsor' => 'Sponsor Eksekutif',
        'Influencer' => 'Yang Mempengaruhi',
        'Other' => 'Other',
    ),
    //Note:  do not translate case_relationship_type_default_key
//       it is the key for the default case_relationship_type_dom value
    'case_relationship_type_default_key' => 'Primary Contact',
    'case_relationship_type_dom' => array(
        '' => '',
        'Primary Contact' => 'Primary Contact',
        'Alternate Contact' => 'Kontak Alternatif',
    ),
    'payment_terms' => array(
        '' => '',
        'Net 15' => 'Net 15',
        'Net 30' => 'Net 30',
    ),
    'sales_stage_default_key' => 'Prospeksi',
    'sales_stage_dom' => array(
        'Prospecting' => 'Prospeksi',
        'Qualification' => 'Kualifikasi',
        'Needs Analysis' => 'Analisis Kebutuhan',
        'Value Proposition' => 'Nilai Saran',
        'Id. Decision Makers' => 'Identifikasi pengambil keputusan',
        'Perception Analysis' => 'Tanggapan Analis',
        'Proposal/Price Quote' => 'Proposal/Perkiraan Harga',
        'Negotiation/Review' => 'Negosiasi/Tinjauan',
        'Closed Won' => 'Berakhir Menang',
        'Closed Lost' => 'Berakhir Kalah',
    ),
    'sales_probability_dom' => // keys must be the same as sales_stage_dom
        array(
            'Prospecting' => '10',
            'Qualification' => '20',
            'Needs Analysis' => '25',
            'Value Proposition' => '30',
            'Id. Decision Makers' => '40',
            'Perception Analysis' => '50',
            'Proposal/Price Quote' => '65',
            'Negotiation/Review' => '80',
            'Closed Won' => '100',
            'Closed Lost' => '0',
        ),
    'activity_dom' => array(
        'Call' => 'Call',
        'Meeting' => 'Meeting',
        'Task' => 'Task',
        'Email' => 'Surel',
        'Note' => 'Note',
    ),
    'salutation_dom' => array(
        '' => '',
        'Mr.' => 'Tn.',
        'Ms.' => 'Nn.',
        'Mrs.' => 'Ny.',
        'Miss' => 'Kehilangan',
        'Dr.' => 'Dr.',
        'Prof.' => 'Prof.',
    ),

    'redirect_uri_type_dom' => [
        'pretty_url' => 'Pretty URL (/ep/)',
        'query_string' => 'Query String (index.php?entryPoint=)'
    ],

    //time is in seconds; the greater the time the longer it takes;
    'reminder_max_time' => 90000,
    'reminder_time_options' => array(
        60 => '1 menit sebelumnya',
        300 => '5 menit sebelumnya',
        600 => '10 menit sebelumnya',
        900 => '15 menit sebelumnya',
        1800 => '30 menit sebelumnya',
        3600 => '1 jam sebelumnya',
        7200 => '2 jam sebelumnya',
        10800 => '3 jam sebelumnya',
        18000 => '5 jam sebelumnya',
        86400 => '1 hari sebelumnya',
    ),

    // snooze for alerts
    'snooze_alert_timer' => array(
        60 => 'Snooze for 1 minute',
        300 => 'Snooze for 5 minutes',
        600 => 'Snooze for 10 minutes',
        900 => 'Snooze for 15 minutes',
        1800 => 'Snooze for 30 minutes',
        3600 => 'Snooze for 1 hour',
        7200 => 'Snooze for 2 hours',
        10800 => 'Snooze for 3 hours',
        18000 => 'Snooze for 5 hours',
        86400 => 'Snooze for 1 day',
    ),

    'snooze_alert_timer_simple' => array(
        60 => '1 min',
        300 => '5 mins',
        600 => '10 mins',
        900 => '15 mins',
        1800 => '30 mins',
        3600 => '1 jam',
        7200 => '2 jam',
        10800 => '3 jam',
        18000 => '5 hours',
        86400 => '1 hari',
    ),

    'task_priority_default' => 'Medium',
    'task_priority_dom' => array(
        'High' => 'High',
        'Medium' => 'Medium',
        'Low' => 'Low',
    ),
    'task_status_default' => 'Belum Dimulai',
    'task_status_dom' => array(
        'Not Started' => 'Not Started',
        'In Progress' => 'Dalam Penyelesaian',
        'Completed' => 'Lengkap',
        'Pending Input' => 'Pending Input',
        'Deferred' => 'Menunda',
    ),
    'meeting_status_default' => 'Planned',
    'meeting_status_dom' => array(
        'Planned' => 'Planned',
        'Held' => 'Mengadakan',
        'Not Held' => 'Tidak Mengadakan',
    ),
    'extapi_meeting_password' => array(
        'WebEx' => 'WebEx',
    ),
    'meeting_type_dom' => array(
        'Other' => 'Other',
        'Sugar' => 'SuiteCRM',
    ),
    'call_status_default' => 'Planned',
    'call_status_dom' => array(
        'Planned' => 'Planned',
        'Held' => 'Held',
        'Not Held' => 'Not Held',
    ),
    'call_direction_default' => 'Outbound',
    'call_direction_dom' => array(
        'Inbound' => 'Panggilan Masuk',
        'Outbound' => 'Outbound',
    ),
    'lead_status_dom' => array(
        '' => '',
        'New' => 'New',
        'Assigned' => 'Assigned',
        'In Process' => 'Dalam Proses',
        'Converted' => 'Konversi',
        'Recycled' => 'Dikembalikan',
        'Dead' => 'Meninggal',
    ),
    'case_priority_default_key' => 'P2',
    'case_priority_dom' => array(
        'P1' => 'High',
        'P2' => 'Medium',
        'P3' => 'Low',
    ),
    'user_type_dom' => array(
        'RegularUser' => 'Pengguna Reguler',
        'Administrator' => 'Administrator',
    ),
    'user_status_dom' => array(
        'Active' => 'Active',
        'Inactive' => 'Nonaktif',
    ),
    'user_factor_auth_interface_dom' => array(
        'FactorAuthEmailCode' => 'Kode Email',
    ),
    'employee_status_dom' => array(
        'Active' => 'Active',
        'Terminated' => 'Terminasi',
        'Leave of Absence' => 'Cuti Absen',
    ),
    'messenger_type_dom' => array(
        '' => '',
        'MSN' => 'MSN',
        'Yahoo!' => 'Yahoo!',
        'AOL' => 'AOL',
    ),
    'project_task_priority_options' => array(
        'High' => 'High',
        'Medium' => 'Medium',
        'Low' => 'Low',
    ),
    'project_task_priority_default' => 'Medium',

    'project_task_status_options' => array(
        'Not Started' => 'Not Started',
        'In Progress' => 'In Progress',
        'Completed' => 'Completed',
        'Pending Input' => 'Pending Input',
        'Deferred' => 'Deferred',
    ),
    'project_task_utilization_options' => array(
        '0' => 'Tidak ada',
        '25' => '25',
        '50' => '50',
        '75' => '75',
        '100' => '100',
    ),

    'project_status_dom' => array(
        'Draft' => 'Draft',
        'In Review' => 'Dalam Tinjauan',
        'Underway' => 'Berjalan',
        'On_Hold' => 'Ditahan',
        'Completed' => 'Completed',
    ),
    'project_status_default' => 'Draft',

    'project_duration_units_dom' => array(
        'Days' => 'Hari',
        'Hours' => 'Jam',
    ),

    'activity_status_type_dom' => array(
        '' => '--Kosong--',
        'active' => 'Active',
        'inactive' => 'Inactive',
    ),

    // Note:  do not translate record_type_default_key
    //        it is the key for the default record_type_module value
    'record_type_default_key' => 'Akun',
    'record_type_display' => array(
        '' => '',
        'Accounts' => 'Akun',
        'Opportunities' => 'Opportunity',
        'Cases' => 'Case',
        'Leads' => 'Pengantar',
        'Contacts' => 'Contact', // cn (11/22/2005) added to support Emails

        'Bugs' => 'Bug',
        'Project' => 'Project',

        'Prospects' => 'Target',
        'ProjectTask' => 'Project Task',

        'Tasks' => 'Task',

        'AOS_Contracts' => 'Kontrak',
        'AOS_Invoices' => 'Faktur',
        'AOS_Quotes' => 'Kutipan',
        'AOS_Products' => 'Product',

    ),

    'record_type_display_notes' => array(
        'Accounts' => 'Akun',
        'Contacts' => 'Contact',
        'Opportunities' => 'Opportunity',
        'Campaigns' => 'Campaign',
        'Tasks' => 'Task',
        'Emails' => 'Surel',

        'Bugs' => 'Bug',
        'Project' => 'Project',
        'ProjectTask' => 'Project Task',
        'Prospects' => 'Target',
        'Cases' => 'Case',
        'Leads' => 'Pengantar',

        'Meetings' => 'Meeting',
        'Calls' => 'Call',

        'AOS_Contracts' => 'Kontrak',
        'AOS_Invoices' => 'Faktur',
        'AOS_Quotes' => 'Kutipan',
        'AOS_Products' => 'Product',
    ),

    'parent_type_display' => array(
        'Accounts' => 'Akun',
        'Contacts' => 'Contact',
        'Tasks' => 'Task',
        'Opportunities' => 'Opportunity',

        'Bugs' => 'Bug',
        'Cases' => 'Case',
        'Leads' => 'Pengantar',

        'Project' => 'Project',
        'ProjectTask' => 'Project Task',

        'Prospects' => 'Target',

        'AOS_Contracts' => 'Kontrak',
        'AOS_Invoices' => 'Faktur',
        'AOS_Quotes' => 'Kutipan',
        'AOS_Products' => 'Product',

    ),
    'parent_line_items' => array(
        'AOS_Quotes' => 'Penawaran',
        'AOS_Invoices' => 'Faktur',
        'AOS_Contracts' => 'Kontrak',
    ),
    'issue_priority_default_key' => 'Medium',
    'issue_priority_dom' => array(
        'Urgent' => 'Mendesak',
        'High' => 'High',
        'Medium' => 'Medium',
        'Low' => 'Low',
    ),
    'issue_resolution_default_key' => '',
    'issue_resolution_dom' => array(
        '' => '',
        'Accepted' => 'Accepted',
        'Duplicate' => 'Duplicate',
        'Closed' => 'Closed',
        'Out of Date' => 'Out of Date',
        'Invalid' => 'Tidak Valid',
    ),

    'issue_status_default_key' => 'New',
    'issue_status_dom' => array(
        'New' => 'New',
        'Assigned' => 'Assigned',
        'Closed' => 'Closed',
        'Pending' => 'Pending',
        'Rejected' => 'Rejected',
    ),

    'bug_priority_default_key' => 'Medium',
    'bug_priority_dom' => array(
        'Urgent' => 'Urgent',
        'High' => 'High',
        'Medium' => 'Medium',
        'Low' => 'Low',
    ),
    'bug_resolution_default_key' => '',
    'bug_resolution_dom' => array(
        '' => '',
        'Accepted' => 'Accepted',
        'Duplicate' => 'Duplicate',
        'Fixed' => 'Harga Tetap',
        'Out of Date' => 'Out of Date',
        'Invalid' => 'Tidak Valid',
        'Later' => 'Nanti',
    ),
    'bug_status_default_key' => 'New',
    'bug_status_dom' => array(
        'New' => 'New',
        'Assigned' => 'Assigned',
        'Closed' => 'Closed',
        'Pending' => 'Pending',
        'Rejected' => 'Rejected',
    ),
    'bug_type_default_key' => 'Bug',
    'bug_type_dom' => array(
        'Defect' => 'Kerusakan',
        'Feature' => 'Fitur',
    ),
    'case_type_dom' => array(
        'Administration' => 'Administration',
        'Product' => 'Product',
        'User' => 'User',
    ),

    'source_default_key' => '',
    'source_dom' => array(
        '' => '',
        'Internal' => 'Internal',
        'Forum' => 'Forum',
        'Web' => 'Web',
        'InboundEmail' => 'Surel',
    ),

    'product_category_default_key' => '',
    'product_category_dom' => array(
        '' => '',
        'Accounts' => 'Akun',
        'Activities' => 'Activities',
        'Bugs' => 'Bugs',
        'Calendar' => 'Calendar',
        'Calls' => 'Calls',
        'Campaigns' => 'Campaigns',
        'Cases' => 'Cases',
        'Contacts' => 'Contacts',
        'Currencies' => 'Currencies',
        'Dashboard' => 'Dasbor',
        'Documents' => 'Dokumen',
        'Emails' => 'Email',
        'Feeds' => 'Umpan',
        'Forecasts' => 'Perkiraan',
        'Help' => 'Membantu',
        'Home' => 'Home',
        'Leads' => 'Leads',
        'Meetings' => 'Meetings',
        'Notes' => 'Notes',
        'Opportunities' => 'Opportunities',
        'Outlook Plugin' => 'Outlook Plugin',
        'Projects' => 'Projects',
        'Quotes' => 'Quotes',
        'Releases' => 'Releases',
        'RSS' => 'RSS',
        'Studio' => 'Studio',
        'Upgrade' => 'Tingkatkan',
        'Users' => 'Users',
    ),
    /*Added entries 'Queued' and 'Sending' for 4.0 release..*/
    'campaign_status_dom' => array(
        'Planning' => 'Perencanaan',
        'Active' => 'Active',
        'Inactive' => 'Inactive',
        'Complete' => 'Lengkap',
        //'In Queue' => 'In Queue',
        //'Sending' => 'Sending',
    ),
    'campaign_type_dom' => array(
        '' => '',
        'Telesales' => 'Penjualan melalui telepon',
        'Mail' => 'Surat',
        'Email' => 'Surel',
        'Print' => 'Cetak',
        'Web' => 'Web',
        'Radio' => 'Radio',
        'Television' => 'TV',
        'NewsLetter' => 'Koran',
        'Survey' => 'Survei',
    ),

    'newsletter_frequency_dom' => array(
        '' => '',
        'Weekly' => 'Mingguan',
        'Monthly' => 'Bulanan',
        'Quarterly' => 'Tiga Bulanan',
        'Annually' => 'Tahunan',
    ),

    'notifymail_sendtype' => array(
        'SMTP' => 'SMTP',
    ),
    'dom_cal_month_long' => array(
        '0' => '',
        '1' => 'Januari',
        '2' => 'Februari',
        '3' => 'Mar',
        '4' => 'Apr',
        '5' => 'Mei',
        '6' => 'Jun',
        '7' => 'Jul',
        '8' => 'Agu',
        '9' => 'Sep',
        '10' => 'Okt',
        '11' => 'Nov',
        '12' => 'Des',
    ),
    'dom_cal_month_short' => array(
        '0' => '',
        '1' => 'Jan',
        '2' => 'Feb',
        '3' => 'Mar',
        '4' => 'Apr',
        '5' => 'May',
        '6' => 'Jun',
        '7' => 'Jul',
        '8' => 'Agt',
        '9' => 'Sep',
        '10' => 'Okt',
        '11' => 'Nov',
        '12' => 'Des',
    ),
    'dom_cal_day_long' => array(
        '0' => '',
        '1' => 'Minggu',
        '2' => 'Senin',
        '3' => 'Selasa',
        '4' => 'Rabu',
        '5' => 'Kamis',
        '6' => 'Jum\'at',
        '7' => 'Sabtu',
    ),
    'dom_cal_day_short' => array(
        '0' => '',
        '1' => 'Minggu',
        '2' => 'Senin',
        '3' => 'Selasa',
        '4' => 'Rabu',
        '5' => 'Kamis',
        '6' => 'Jumat',
        '7' => 'Sabtu',
    ),
    'dom_meridiem_lowercase' => array(
        'am' => 'am',
        'pm' => 'pm',
    ),
    'dom_meridiem_uppercase' => array(
        'AM' => 'PM',
        'PM' => 'PM',
    ),

    'dom_inbound_email_account_types' => [
        'personal' => 'Pribadi',
        'group' => 'Grup',
        'bounce' => 'Terpental',
    ],

    'dom_inbound_email_auth_types' => [
        'basic' => 'Otentikasi Dasar',
        'oauth' => 'OAuth',
    ],

    'dom_outbound_email_auth_types' => [
        'no_auth' => 'No Auth',
        'basic' => 'Otentikasi Dasar',
        'oauth' => 'OAuth',
    ],

    'dom_external_oauth_connection_types' => [
        'personal' => 'Pribadi',
        'group' => 'Grup',
    ],

    'dom_external_oauth_provider_types' => [
        'personal' => 'Pribadi',
        'group' => 'Grup',
    ],

    'dom_outbound_email_account_types' => [
        'user' => 'Pribadi',
        'group' => 'Grup',
        'system' => 'Sistem',
        'system-override' => 'Penimpaan Sistem',
    ],

    'dom_inbound_email_account_status' => [
        'Active' => 'Active',
        'Inactive' => 'Inactive',
    ],

    'dom_email_body_filtering_option' => [
      'multi' => 'Multi Word Search',
      'single' => 'Single Word Search',
    ],

    'dom_email_types' => array(
        'out' => 'Kirim',
        'archived' => 'Terarsip',
        'draft' => 'Draft',
        'inbound' => 'Inbound',
        'campaign' => 'Campaign',
    ),
    'dom_email_status' => array(
        'archived' => 'Archived',
        'closed' => 'Closed',
        'draft' => 'Konsep',
        'read' => 'Baca',
        'replied' => 'menjawab',
        'sent' => 'Sent',
        'send_error' => 'Pengiriman Error',
        'unread' => 'Belum Dibaca',
    ),
    'dom_email_archived_status' => array(
        'archived' => 'Archived',
    ),

    'dom_email_server_type' => array(
        '' => '--Kosong--',
        'imap' => 'IMAP',
    ),
    'dom_mailbox_type' => array(/*''           => '--None Specified--',*/
        'pick' => '--Kosong--',
        'createcase' => 'Buat Kasus',
        'bounce' => 'Penanganan Bounce',
    ),
    'dom_email_distribution' => array(
        '' => '--Kosong--',
        'direct' => 'Menugaskan Langsung',
        'roundRobin' => 'Round-Robin',
        'leastBusy' => 'Least-busy',
    ),
    'dom_email_errors' => array(
        1 => 'Pilih salah satu pengguna ketika hanya menetapkan barang-barang langsung.',
        2 => 'Anda harus menetapkan hanya memeriksa item ketika langsung menetapkan item',
    ),
    'dom_email_bool' => array(
        'bool_true' => 'Ya',
        'bool_false' => 'No',
    ),
    'dom_int_bool' => array(
        1 => 'Ya',
        0 => 'No',
    ),
    'dom_int_bool_string' => array(
        '1' => 'Ya',
        '0' => 'No',
    ),
    'dom_switch_bool' => array(
        'on' => 'Ya',
        'off' => 'No',
        '' => 'No',
    ),

    'dom_email_link_type' => array(
        'sugar' => 'Email klien SuiteCRM',
        'mailto' => 'Mail Client Eksternal',
    ),

    'dom_editor_type' => array(
        'none' => 'HTML langsung',
        'tinymce' => 'TinyMCE',
    ),

    'dom_email_editor_option' => array(
        '' => 'Format Email Bawaan',
        'html' => 'Email HTML',
        'plain' => 'Email Teks',
    ),

    'schedulers_times_dom' => array(
        'not run' => 'Past Run Time, Tidak Dieksekusi',
        'ready' => 'Siap',
        'in progress' => 'In Progress',
        'failed' => 'Gagal',
        'completed' => 'Completed',
        'no curl' => 'Tidak Jalan: Tidak ada cURL yang tersedia',
    ),

    'scheduler_status_dom' => array(
        'Active' => 'Active',
        'Inactive' => 'Inactive',
    ),

    'scheduler_period_dom' => array(
        'min' => 'Menit',
        'hour' => 'Hours',
    ),
    'document_category_dom' => array(
        '' => '',
        'Marketing' => 'Marketing',
        'Knowledege Base' => 'Berbasis Pengetahuan',
        'Sales' => 'Sales',
    ),

    'email_category_dom' => array(
        '' => '',
        'Archived' => 'Archived',
        // TODO: add more categories here...
    ),

    'document_subcategory_dom' => array(
        '' => '',
        'Marketing Collateral' => 'Marketing Collateral',
        'Product Brochures' => 'Product Brochures',
        'FAQ' => 'Pertanyaan Yang Sering Diajukan',
    ),

    'document_status_dom' => array(
        'Active' => 'Active',
        'Draft' => 'Draft',
        'FAQ' => 'Pertanyaan Yang Sering Diajukan',
        'Expired' => 'Expired',
        'Under Review' => 'Under Review',
        'Pending' => 'Pending',
    ),
    'document_template_type_dom' => array(
        '' => '',
        'mailmerge' => 'Menggabungkan surat',
        'eula' => 'EULA',
        'nda' => 'NDA',
        'license' => 'Perjanjian lisensi',
    ),
    'dom_meeting_accept_options' => array(
        'accept' => 'Diterima',
        'decline' => 'Ditolak',
        'tentative' => 'Sementara',
    ),
    'dom_meeting_accept_status' => array(
        'accept' => 'Accepted',
        'decline' => 'Ditolak',
        'tentative' => 'Tentative',
        'none' => 'Tidak ada',
    ),
    'duration_intervals' => array(
        '0' => '00',
        '15' => '15',
        '30' => '30',
        '45' => '45',
    ),
    'repeat_type_dom' => array(
        '' => 'Tidak ada',
        'Daily' => 'Harian',
        'Weekly' => 'Weekly',
        'Monthly' => 'Monthly',
        'Yearly' => 'Tahunan',
    ),

    'repeat_intervals' => array(
        '' => '',
        'Daily' => 'hari(s)',
        'Weekly' => 'minggu(s)',
        'Monthly' => 'bulan(s)',
        'Yearly' => 'tahun(s)',
    ),

    'duration_dom' => array(
        '' => 'Tidak ada',
        '900' => '15 menit',
        '1800' => '30 menit',
        '2700' => '45 menit',
        '3600' => '1 jam',
        '5400' => '1,5 jam',
        '7200' => '2 jam',
        '10800' => '3 jam',
        '21600' => '6 jam',
        '86400' => '1 hari',
        '172800' => '2 hari',
        '259200' => '3 hari',
        '604800' => '1 minggu',
    ),


//prospect list type dom
    'prospect_list_type_dom' => array(
        'default' => 'Default',
        'seed' => 'Benih',
        'exempt_domain' => 'Daftar Singkat - Dengan Domain',
        'exempt_address' => 'Daftar Singkat - Dengan Email Address',
        'exempt' => 'Daftar Singkat - Dengan ID',
        'test' => 'Tes',
    ),

    'email_settings_num_dom' => array(
        '10' => '10',
        '20' => '20',
        '50' => '50',
    ),
    'email_marketing_status_dom' => array(
        '' => '',
        'active' => 'Active',
        'draft' => 'Draft',
        'scheduled' => 'Scheduled',
        'pending_send' => 'Pending Send',
        'aborted' => 'Aborted',
        'sending' => 'Sending',
        'sent' => 'Sent'
    ),
    'email_marketing_duplicate_dom' => [
        'email' => 'Prevent sending to duplicate records and email addresses',
        'record' => 'Prevent sending to duplicate records',
    ],
    'email_marketing_queueing_status_dom' => array(
        'not_started' => 'Not Started',
        'in_progress' => 'In Progress',
        'finished' => 'Finished',
    ),
    'email_marketing_type_dom' => array(
        'legacy' => 'Legacy',
        'marketing' => 'Marketing',
        'survey' => 'Survei',
        'transactional' => 'Transactional',
    ),

    'campainglog_activity_type_dom' => array(
        '' => '',
        'targeted' => 'Sent/Attempted',
        'send error' => 'Pesan Tidak Terkirim, Lainnya',
        'invalid email' => 'Pesan Tidak Terkirim, Email tidak valid',
        'link' => 'Klik-thru link',
        'viewed' => 'Pesan yang dilihat',
        'removed' => 'Dihapus',
        'lead' => 'Leads yang Dibuat',
        'contact' => 'Kontak telah dibuat',
        'blocked' => 'Diblokir oleh DOmain',
        'Survey' => 'Survei dijawab',
    ),

    'campainglog_target_type_dom' => array(
        'Contacts' => 'Contacts',
        'Users' => 'Users',
        'Prospects' => 'Targets',
        'Leads' => 'Leads',
        'Accounts' => 'Akun',
    ),
    'merge_operators_dom' => array(
        'like' => 'Yang Termasuk',
        'exact' => 'Persis',
        'start' => 'Mulai Dengan',
    ),

    'custom_fields_importable_dom' => array(
        'true' => 'Ya',
        'false' => 'No',
        'required' => 'Dibutuhkan',
    ),

    'custom_fields_merge_dup_dom' => array(
        0 => 'Tidak Diaktifkan',
        1 => 'Diaktifkan',
        2 => 'Cari',
        3 => 'Filter terpilih bawaan',
        4 => 'Hanya filter',
    ),

    'projects_priority_options' => array(
        'high' => 'High',
        'medium' => 'Medium',
        'low' => 'Low',
    ),

    'projects_status_options' => array(
        'notstarted' => 'Not Started',
        'inprogress' => 'In Progress',
        'completed' => 'Completed',
    ),
    // strings to pass to Flash charts
    'chart_strings' => array(
        'expandlegend' => 'Tampilkan Semua Legenda',
        'collapselegend' => 'Sembunyikan Semua Legenda',
        'clickfordrilldown' => 'Klik untuk Click for Menyelusuri',
        'detailview' => 'Lebih Detil',
        'piechart' => 'Pie Chart',
        'groupchart' => 'Bagan kelompok',
        'stackedchart' => 'Bagan bertumpuk',
        'barchart' => 'Grafik batang',
        'horizontalbarchart' => 'Bagan horisontal',
        'linechart' => 'Garis bagan',
        'noData' => 'Data tidak tersedia',
        'print' => 'Print',
        'pieWedgeName' => 'Bagian',
    ),
    'release_status_dom' => array(
        'Active' => 'Active',
        'Inactive' => 'Inactive',
    ),
    'email_settings_for_ssl' => array(
        '0' => '',
        '1' => 'SSL',
        '2' => 'TLS',
    ),
    'import_enclosure_options' => array(
        '\'' => 'Tanda Kutip (&#39;)',
        '"' => 'Tanda Kutip 2 (&#34;)',
        '' => 'Tidak ada',
        'other' => 'Lainnya:',
    ),
    'import_delimeter_options' => array(
        ',' => ',',
        ';' => ';',
        '\t' => '\t',
        '.' => '.',
        ':' => ':',
        '|' => '|',
        'other' => 'Other:',
    ),
    'link_target_dom' => array(
        '_blank' => 'Window Baru',
        '_self' => 'Window yang sama',
    ),
    'dashlet_auto_refresh_options' => array(
        '-1' => 'Secara Manual',
        '30' => 'Setiap 30 detik',
        '60' => 'Setiap Jam',
        '180' => 'Setiap 3 menit',
        '300' => 'Setiap 5 menit',
        '600' => 'Setiap 10 menit',
    ),
    'dashlet_auto_refresh_options_admin' => array(
        '-1' => 'Tidak Pernah',
        '30' => 'Setiap 30 detik',
        '60' => 'Every 1 minute',
        '180' => 'Setiap 3 menit',
        '300' => 'Setiap 5 menit',
        '600' => 'Setiap 10 menit',
    ),
    'date_range_search_dom' => array(
        '=' => 'Sama',
        'not_equal' => 'Tidak menyala',
        'greater_than' => 'Sesudah',
        'less_than' => 'Sebelum',
        'last_7_days' => '7 hari terakhir',
        'next_7_days' => '7 hari ke depan',
        'last_30_days' => '30 Hari Terakhir',
        'next_30_days' => '30 hari ke depan',
        'last_month' => 'Bulan Lalu',
        'this_month' => 'Bulan Ini',
        'next_month' => 'Bulan Berikutnya',
        'last_year' => 'Tahun Lalu',
        'this_year' => 'Tahun Ini',
        'next_year' => 'Tahun Berikutnya',
        'between' => 'Diantara',
    ),
    'numeric_range_search_dom' => array(
        '=' => 'Sama',
        'not_equal' => 'Tidak sama',
        'greater_than' => 'Lebih besar dari',
        'greater_than_equals' => 'Lebih Besar Dari Atau Sama Dengan',
        'less_than' => 'Kurang dari',
        'less_than_equals' => 'Kurang Dari Atau Sama Dengan',
        'between' => 'Is Between',
    ),
    'lead_conv_activity_opt' => array(
        'copy' => 'Salin',
        'move' => 'Pindah',
        'donothing' => 'Tidak melakukan apapun',
    ),
);

$app_strings = array(
    'LBL_SEARCH_RESULTS_TITLE' => 'Hasil',
    'ERR_SEARCH_INVALID_QUERY' => 'Terjadi kesalahan saat melakukan pencarian. Sintaksis kueri Anda mungkin tidak valid.',
    'ERR_SEARCH_NO_RESULTS' => 'Tidak ada hasil yang sesuai dengan kriteria pencarian Anda. Perluas pencarian.',
    'LBL_SEARCH_PERFORMED_IN' => 'Pencarian dilakukan di',
    'LBL_EMAIL_CODE' => 'Kode Email:',
    'LBL_SEND' => 'Kirim',
    'LBL_SEND_BUTTON_TITLE' => 'Send',
    'LBL_LOGOUT' => 'Keluar',
    'LBL_LOGOUT_SUCCESS' => 'Berhasil keluar',
    'LBL_LOGGED_OUT_MESSAGE' => 'Anda telah keluar',
    'LBL_LOGIN_AGAIN' => 'Masuk kembali ',
    'LBL_TOUR_NEXT' => 'Berikutnya',
    'LBL_TOUR_SKIP' => 'Lewat',
    'LBL_TOUR_BACK' => 'Kembali',
    'LBL_TOUR_TAKE_TOUR' => 'Ikuti tur',
    'LBL_MOREDETAIL' => 'Lebih Detail', /*for 508 compliance fix*/
    'LBL_EDIT_INLINE' => 'Inline Edit', /*for 508 compliance fix*/
    'LBL_VIEW_INLINE' => 'View', /*for 508 compliance fix*/
    'LBL_BASIC_SEARCH' => 'Menyaring', /*for 508 compliance fix*/
    'LBL_Blank' => ' ', /*for 508 compliance fix*/
    'LBL_ID_FF_ADD' => 'Tambah', /*for 508 compliance fix*/
    'LBL_ID_FF_ADD_EMAIL' => 'Tambahkan Alamat Email', /*for 508 compliance fix*/
    'LBL_HIDE_SHOW' => 'Sembunyikan/Tampilkan', /*for 508 compliance fix*/
    'LBL_DELETE_INLINE' => 'Hapus', /*for 508 compliance fix*/
    'LBL_ID_FF_CLEAR' => 'Bersihkan [Alt+C]', /*for 508 compliance fix*/
    'LBL_ID_FF_VCARD' => 'vCard', /*for 508 compliance fix*/
    'LBL_ID_FF_REMOVE' => 'Remove', /*for 508 compliance fix*/
    'LBL_ID_FF_REMOVE_EMAIL' => 'Hapus Alamat Email', /*for 508 compliance fix*/
    'LBL_ID_FF_OPT_OUT' => 'Opsi Keluar',
    'LBL_ID_FF_INVALID' => 'Membuat Tidak Valid',
    'LBL_ADD' => 'Add', /*for 508 compliance fix*/
    'LBL_COMPANY_LOGO' => 'Logo Perusahaan', /*for 508 compliance fix*/
    'LBL_CONNECTORS_POPUPS' => 'Konektor Popup',
    'LBL_CLOSEINLINE' => 'Close',
    'LBL_VIEWINLINE' => 'View',
    'LBL_INFOINLINE' => 'Info',
    'LBL_PRINT' => 'Print',
    'LBL_HELP' => 'Bantuan',
    'LBL_ID_FF_SELECT' => 'Pilih [Alt+T]',
    'DEFAULT' => 'Dasar',
    'LBL_SORT' => 'Sortir',
    'LBL_EMAIL_SMTP_SSL_OR_TLS' => 'Mampukan SMTP lewat SSL atau TLS',
    'LBL_NO_ACTION' => 'Tidak ada tindakan oleh nama: %s',
    'LBL_NO_SHORTCUT_MENU' => 'Tidak ada tindakan yang tersedia.',
    'LBL_NO_DATA' => 'Tidak Ada Data',

    'LBL_ROUTING_FLAGGED' => 'Set Bendera',
    'LBL_ROUTING_TO' => 'Ke',
    'LBL_ROUTING_TO_ADDRESS' => 'Kepada Alamat',
    'LBL_ROUTING_WITH_TEMPLATE' => 'Dengan template',

    'NTC_OVERWRITE_ADDRESS_PHONE_CONFIRM' => 'Anda telah mengisi data nomor Telepon dan alamat di form yang ada. Untuk menggantikan data yang ada dengan data nomor Telepon dan alamat yang baru , klik "Oke". Untuk tetap menggunakan data yang telah ada, klik "Batal".',
    'LBL_DROP_HERE' => '[Drop Di sini]',
    'LBL_EMAIL_ACCOUNTS_GMAIL_DEFAULTS' => 'Set Gmail Defaults',
    'LBL_EMAIL_ACCOUNTS_NAME' => 'Nama ',
    'LBL_EMAIL_ACCOUNTS_OUTBOUND' => 'Outbound Mail Server',
    'LBL_EMAIL_ACCOUNTS_SMTPPASS' => 'Pasword SMTP',
    'LBL_EMAIL_ACCOUNTS_SMTPPORT' => 'Port SMTP ',
    'LBL_EMAIL_ACCOUNTS_SMTPSERVER' => 'Server SMTP ',
    'LBL_EMAIL_ACCOUNTS_SMTPUSER' => 'Nama Pengguna SMTP ',
    'LBL_EMAIL_ACCOUNTS_SMTPDEFAULT' => 'Standar',
    'LBL_EMAIL_WARNING_MISSING_USER_CREDS' => 'Warning: Tidak ada username dan password untuk outgoing mail account.',
    'LBL_OAUTH_CONNECTION_NOT_SET' => 'Please set an External OAuth Connection.',
    'LBL_EMAIL_PASSWORD_NOT_SET' => 'Warning: A password has not been set.',
    'LBL_EMAIL_WARNING_MISSING_CREDS' => 'Peringatan: Kredensial hilang',
    'LBL_EMAIL_ACCOUNTS_SUBTITLE' => 'Mengatur account Email untuk melihat email masuk dari Email Account Anda.',
    'LBL_EMAIL_ACCOUNTS_OUTBOUND_SUBTITLE' => 'Isi informasi SMTP mail server untuk email keluar di Account Email.',
    'ERR_TIMEOUT' => "Kegagalan paksa pada timeout",
    'LBL_EMAIL_ADDRESS_BOOK_ADD' => 'Selesai',
    'LBL_EMAIL_ADDRESS_BOOK_CLEAR' => 'Clear',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_TO' => 'Untuk:',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_CC' => 'Cc:',
    'LBL_EMAIL_ADDRESS_BOOK_ADD_BCC' => 'Bcc:',
    'LBL_EMAIL_ADDRESS_BOOK_ADRRESS_TYPE' => 'Ke/Cc/Bcc',
    'LBL_EMAIL_ADDRESS_BOOK_EMAIL_ADDR' => 'Alamat Surel',
    'LBL_EMAIL_ADDRESS_BOOK_FILTER' => 'Filter',
    'LBL_EMAIL_ADDRESS_BOOK_NAME' => 'Nama ',
    'LBL_EMAIL_ADDRESS_BOOK_NOT_FOUND' => 'Alamat Tidak Ditemukan',
    'LBL_EMAIL_ADDRESS_BOOK_SAVE_AND_ADD' => 'Simpan & Tambah ke Buku Alamat',
    'LBL_EMAIL_ADDRESS_BOOK_SELECT_TITLE' => 'Pilih Catatan Buku Alamat',
    'LBL_EMAIL_ADDRESS_BOOK_TITLE' => 'Buku Alamat',
    'LBL_EMAIL_REMOVE_SMTP_WARNING' => 'Peringatan! Account Surat Keluar yang ingin Anda hapus terkait dengan account Surat Masuk yang sudah ada. Anda yakin ingin melanjutkan?',
    'LBL_EMAIL_ADDRESSES' => 'Alamat Surel',
    'LBL_EMAIL' => 'Surel',
    'LBL_EMAIL_ADDRESS_PRIMARY' => 'Alamat Surel',
    'LBL_EMAIL_ADDRESS_OPT_IN' => 'Anda berhasil mengonfirmasi bahwa alamat email Anda telah terdaftar: ',
    'LBL_EMAIL_ADDRESS_OPT_IN_ERR' => 'Gagal mengonfirmasi alamat email',
    'LBL_EMAIL_ARCHIVE_TO_SUITE' => 'Impor ke SuiteCRM',
    'LBL_EMAIL_ASSIGNMENT' => 'Tugas',
    'LBL_EMAIL_ATTACH_FILE_TO_EMAIL' => 'Lampiran',
    'LBL_EMAIL_ATTACHMENT' => 'Attach',
    'LBL_EMAIL_ATTACHMENTS' => 'Dari System Lokal',
    'LBL_EMAIL_ATTACHMENTS2' => 'Dari Dokumen SuiteCRM',
    'LBL_EMAIL_ATTACHMENTS3' => 'Lampiran Template',
    'LBL_EMAIL_ATTACHMENTS_FILE' => 'Arsip',
    'LBL_EMAIL_ATTACHMENTS_DOCUMENT' => 'Document',
    'LBL_EMAIL_BCC' => 'BCC',
    'LBL_EMAIL_CANCEL' => 'Batal',
    'LBL_EMAIL_CC' => 'CC',
    'LBL_EMAIL_CHARSET' => 'Set Karakter',
    'LBL_EMAIL_CHECK' => 'Memeriksa Surat',
    'LBL_EMAIL_CHECKING_NEW' => 'Cek Pesan Baru',
    'LBL_EMAIL_CHECKING_DESC' => 'Cek Pesan Baru. <br><br>If this is the first check for the mail account, it may take some time.',
    'LBL_EMAIL_CLOSE' => 'Close',
    'LBL_EMAIL_COFFEE_BREAK' => 'Cek Pesan Baru. <br><br>Large mail accounts may take a considerable amount of time.',

    'LBL_EMAIL_COMPOSE' => 'Surel',
    'LBL_EMAIL_COMPOSE_ERR_NO_RECIPIENTS' => 'Mohon isi penerima pesan ini.',
    'LBL_EMAIL_COMPOSE_NO_BODY' => 'Isi pesan ini kosong.  Tetap dikirim?',
    'LBL_EMAIL_COMPOSE_NO_SUBJECT' => 'Pesan ini tidak bersubyek.  Tetap dikirim?',
    'LBL_EMAIL_COMPOSE_NO_SUBJECT_LITERAL' => '(Tidak ada subject)',
    'LBL_EMAIL_COMPOSE_INVALID_ADDRESS' => 'Mohon masukkan alamat E-Mail yang valid untuk kolom Kepada, CC dan BCC',

    'LBL_EMAIL_CONFIRM_CLOSE' => 'Buang pesan ini?',
    'LBL_EMAIL_CONFIRM_DELETE_SIGNATURE' => 'Anda yakin mau menghapus tanda-tangan ini?',

    'LBL_EMAIL_SENT_SUCCESS' => 'Kirim Email',

    'LBL_EMAIL_CREATE_NEW' => '--Memilih Untuk Simpan--',
    'LBL_EMAIL_MULT_GROUP_FOLDER_ACCOUNTS' => 'Beberapa',
    'LBL_EMAIL_MULT_GROUP_FOLDER_ACCOUNTS_EMPTY' => 'Kosong',
    'LBL_EMAIL_DATE_SENT_BY_SENDER' => 'Tanggal Kirim Oleh Pengirim',
    'LBL_EMAIL_DATE_TODAY' => 'Hari Ini',
    'LBL_EMAIL_DELETE' => 'Delete',
    'LBL_EMAIL_DELETE_CONFIRM' => 'Hapus pesan yang dipilih?',
    'LBL_EMAIL_DELETE_SUCCESS' => 'Pesan sukses dihapus.',
    'LBL_EMAIL_DELETING_MESSAGE' => 'Hapus Pesan',
    'LBL_EMAIL_DETAILS' => 'Rincian',

    'LBL_EMAIL_EDIT_CONTACT_WARN' => 'Hanya alamat utama yang digunakan dengan Kontak saat bekerja.',

    'LBL_EMAIL_EMPTYING_TRASH' => 'Kosongkan Sampah',
    'LBL_EMAIL_DELETING_OUTBOUND' => 'Menghapus outbound server',
    'LBL_EMAIL_CLEARING_CACHE_FILES' => 'Clearing cache files',
    'LBL_EMAIL_EMPTY_MSG' => 'Tidak ada email untuk ditampilkan.',
    'LBL_EMAIL_EMPTY_ADDR_MSG' => 'Tidak ada alamat email yang akan ditampilkan.',

    'LBL_EMAIL_ERROR_ADD_GROUP_FOLDER' => 'Nama folder harus unik dan tidak kosong. Silahkan coba lagi.',
    'LBL_EMAIL_ERROR_DELETE_GROUP_FOLDER' => 'Folder tidak dapat dihapus. Hal ini dikarenakan didalam folder ataupun subfolder tersebut terdapat sebuah mail box yang sehubungan dengan itu.',
    'LBL_EMAIL_ERROR_CANNOT_FIND_NODE' => 'Tidak dapat menentukan intended folder dari konteks.  Coba lagi.',
    'LBL_EMAIL_ERROR_CHECK_IE_SETTINGS' => 'Mohon cek settings anda.',
    'LBL_EMAIL_ERROR_DESC' => 'Kesalahan dideteksi: ',
    'LBL_EMAIL_DELETE_ERROR_DESC' => 'Anda tidak memiliki akses terhadap area ini. Hubungi administrator untuk mengetahui cara akses terhadap area ini.',
    'LBL_EMAIL_ERROR_DUPE_FOLDER_NAME' => 'Nama SuiteCRM Folder harus unik.',
    'LBL_EMAIL_ERROR_EMPTY' => 'Mohon masukkan kriteria pencarian.',
    'LBL_EMAIL_ERROR_GENERAL_TITLE' => 'Terjadi kesalahan',
    'LBL_EMAIL_ERROR_MESSAGE_DELETED' => 'Pesan dihapus dari Server',
    'LBL_EMAIL_ERROR_IMAP_MESSAGE_DELETED' => 'Pesan dihapus dari Server atau pindah ke map lain',
    'LBL_EMAIL_ERROR_MAILSERVERCONNECTION' => 'Sambungan ke server pesan gagal. Mohon hubungi administrator anda',
    'LBL_EMAIL_ERROR_MOVE' => 'Memindahkan email antara server dan/atau account email tidak berjalan saat ini.',
    'LBL_EMAIL_ERROR_MOVE_TITLE' => 'Pemindahan Error',
    'LBL_EMAIL_ERROR_NAME' => 'Nama diperlukan.',
    'LBL_EMAIL_ERROR_FROM_ADDRESS' => 'Alamat dari diperlukan.',
    'LBL_EMAIL_ERROR_NO_FILE' => 'Tolong sediakan sebuah file.',
    'LBL_EMAIL_ERROR_SERVER' => 'Alamat server Email diperlukan.',
    'LBL_EMAIL_ERROR_SAVE_ACCOUNT' => 'Account Email mungkin belum tersimpan.',
    'LBL_EMAIL_ERROR_TIMEOUT' => 'Ada Error yang muncul saat berkomunikasi dengan Server Email.',
    'LBL_EMAIL_ERROR_USER' => 'Login Name diperlukan.',
    'LBL_EMAIL_ERROR_PORT' => 'Port server pesan diperlukan.',
    'LBL_EMAIL_ERROR_PROTOCOL' => 'Protokol server diperlukan.',
    'LBL_EMAIL_ERROR_MONITORED_FOLDER' => 'Monitored Folder diperlukan.',
    'LBL_EMAIL_ERROR_TRASH_FOLDER' => 'Folder sampah diperlukan.',
    'LBL_EMAIL_ERROR_VIEW_RAW_SOURCE' => 'Informasi ini tidak tersedia',
    'LBL_EMAIL_ERROR_NO_OUTBOUND' => 'Tidak ada server Outgoing Email yang dikonfigurasi.',
    'LBL_EMAIL_ERROR_SENDING' => 'Gagal Mengirim Email. Silahkan hubungi administrator kamu untuk bantuan.',
    'LBL_EMAIL_FOLDERS' => SugarThemeRegistry::current()->getImage('icon_email_folder', 'align=absmiddle border=0', null, null, '.gif', '') . 'Map',
    'LBL_EMAIL_FOLDERS_SHORT' => SugarThemeRegistry::current()->getImage('icon_email_folder', 'align=absmiddle border=0', null, null, '.gif', ''),
    'LBL_EMAIL_FOLDERS_ADD' => 'Add',
    'LBL_EMAIL_FOLDERS_ADD_DIALOG_TITLE' => 'Tambah Folder Baru',
    'LBL_EMAIL_FOLDERS_RENAME_DIALOG_TITLE' => 'Ubah nama Folder',
    'LBL_EMAIL_FOLDERS_ADD_NEW_FOLDER' => 'Simpan [Alt+S]',
    'LBL_EMAIL_FOLDERS_ADD_THIS_TO' => 'Tambah Folder ini ke',
    'LBL_EMAIL_FOLDERS_CHANGE_HOME' => 'Folder ini tidak bisa dirubah',
    'LBL_EMAIL_FOLDERS_DELETE_CONFIRM' => 'Anda yakin akan menghapus folder ini?\nData yang telah dihapus tidak dapat dikembalikan.\nPenghapusan terhadap folder juga akan dilakukan terhadap subfolder didalamnya.',
    'LBL_EMAIL_FOLDERS_NEW_FOLDER' => 'Nama Folder Baru',
    'LBL_EMAIL_FOLDERS_NO_VALID_NODE' => 'Silahkan pilih sebuah folder sebelum melakukan aksi ini.',
    'LBL_EMAIL_FOLDERS_TITLE' => 'Manajemen Folder',

    'LBL_EMAIL_FORWARD' => 'Meneruskan',
    'LBL_EMAIL_DELIMITER' => '::;::',
    'LBL_EMAIL_DOWNLOAD_STATUS' => 'Unduh [[count]] dari [[total]] pesan',
    'LBL_EMAIL_FROM' => 'Dari',
    'LBL_EMAIL_GROUP' => 'Grup',
    'LBL_EMAIL_UPPER_CASE_GROUP' => 'Grup',
    'LBL_EMAIL_HOME_FOLDER' => 'Home',
    'LBL_EMAIL_IE_DELETE' => 'Hapus Account Pesan',
    'LBL_EMAIL_IE_DELETE_SIGNATURE' => 'Hapus tanda-tangan',
    'LBL_EMAIL_IE_DELETE_CONFIRM' => 'Anda yakin akan menghapus Account pesan ini?',
    'LBL_EMAIL_IE_DELETE_SUCCESSFUL' => 'Penghapusan berhasil dilakukan.',
    'LBL_EMAIL_IE_SAVE' => 'Simpan Informasi Account Pesan',
    'LBL_EMAIL_IMPORTING_EMAIL' => 'Mengimpor Email',
    'LBL_EMAIL_IMPORT_EMAIL' => 'Impor menjadi alat yang berguna',
    'LBL_EMAIL_IMPORT_SETTINGS' => 'Pengaturan Import',
    'LBL_EMAIL_INVALID' => 'Tidak Valid',
    'LBL_EMAIL_LOADING' => 'Memuat ......',
    'LBL_EMAIL_MARK' => 'Tanda',
    'LBL_EMAIL_MARK_FLAGGED' => 'Bendera',
    'LBL_EMAIL_MARK_READ' => 'Baca',
    'LBL_EMAIL_MARK_UNFLAGGED' => 'Tidak berbendera',
    'LBL_EMAIL_MARK_UNREAD' => 'Tidak dibaca',
    'LBL_EMAIL_ASSIGN_TO' => 'Ditugaskan kepada',

    'LBL_EMAIL_MENU_ADD_FOLDER' => 'Buat Folder',
    'LBL_EMAIL_MENU_COMPOSE' => 'Buat ke',
    'LBL_EMAIL_MENU_DELETE_FOLDER' => 'Hapus Folder',
    'LBL_EMAIL_MENU_EMPTY_TRASH' => 'Kosongkan Sampah',
    'LBL_EMAIL_MENU_SYNCHRONIZE' => 'Sinkronisasi',
    'LBL_EMAIL_MENU_CLEAR_CACHE' => 'Bersihkan arsip cache',
    'LBL_EMAIL_MENU_REMOVE' => 'Remove',
    'LBL_EMAIL_MENU_RENAME_FOLDER' => 'Rename Folder',
    'LBL_EMAIL_MENU_RENAMING_FOLDER' => 'Ganti Nama Folder',
    'LBL_EMAIL_MENU_MAKE_SELECTION' => 'Silakan membuat pilihan sebelum mencoba operasi ini.',

    'LBL_EMAIL_MENU_HELP_ADD_FOLDER' => 'Buat Folder (remote atau di SuiteCRM)',
    'LBL_EMAIL_MENU_HELP_DELETE_FOLDER' => 'Hapus Folder (jauh atau di SuiteCRM)',
    'LBL_EMAIL_MENU_HELP_EMPTY_TRASH' => 'Kosongkan semua map sampah untuk Account pesan anda',
    'LBL_EMAIL_MENU_HELP_MARK_READ' => 'Tandai pesan ini baca',
    'LBL_EMAIL_MENU_HELP_MARK_UNFLAGGED' => 'Tandai pesan ini tidak berbendera',
    'LBL_EMAIL_MENU_HELP_RENAME_FOLDER' => 'Ganti nama Folder (jauh atau di SuiteCRM)',

    'LBL_EMAIL_MESSAGES' => 'pesan',

    'LBL_EMAIL_ML_NAME' => 'Daftar Nama',
    'LBL_EMAIL_ML_ADDRESSES_1' => 'Pilih Daftar Alamat',
    'LBL_EMAIL_ML_ADDRESSES_2' => 'Daftar Alamat Tersedia',

    'LBL_EMAIL_MULTISELECT' => '<b>Ctrl-Klik</b> untuk memilih lebih dari 1 <br />(Mac users use <b>CMD-Click</b>)',

    'LBL_EMAIL_NO' => 'No',
    'LBL_EMAIL_NOT_SENT' => 'Sistem tidak bisa memproses request Anda. Silahkan hubungi Administrator Sistem. ',

    'LBL_EMAIL_OK' => 'OK',
    'LBL_EMAIL_ONE_MOMENT' => 'Mohon tunggu...',
    'LBL_EMAIL_OPEN_ALL' => 'Membuka Beberapa Email',
    'LBL_EMAIL_OPTIONS' => 'Pilihan',
    'LBL_EMAIL_QUICK_COMPOSE' => 'Compose Cepat',
    'LBL_EMAIL_OPT_OUT' => 'Opted Out',
    'LBL_EMAIL_OPT_OUT_AND_INVALID' => 'Memilih keluar dan tidak valid',
    'LBL_EMAIL_PERFORMING_TASK' => 'Melakukan Tugas',
    'LBL_EMAIL_PRIMARY' => 'Utama',
    'LBL_EMAIL_PRINT' => 'Print',

    'LBL_EMAIL_QC_BUGS' => 'Bug',
    'LBL_EMAIL_QC_CASES' => 'Case',
    'LBL_EMAIL_QC_LEADS' => 'Pengantar',
    'LBL_EMAIL_QC_CONTACTS' => 'Contact',
    'LBL_EMAIL_QC_TASKS' => 'Task',
    'LBL_EMAIL_QC_OPPORTUNITIES' => 'Opportunity',
    'LBL_EMAIL_QUICK_CREATE' => 'Membuat Cepat',

    'LBL_EMAIL_REBUILDING_FOLDERS' => 'Membuat Ulang Folders',
    'LBL_EMAIL_RELATE_TO' => 'Hubungkan',
    'LBL_EMAIL_VIEW_RELATIONSHIPS' => 'Lihat relasi',
    'LBL_EMAIL_RECORD' => 'record Email',
    'LBL_EMAIL_REMOVE' => 'Remove',
    'LBL_EMAIL_REPLY' => 'Balas [Alt + R]',
    'LBL_EMAIL_REPLY_ALL' => 'Balas Semua',
    'LBL_EMAIL_REPLY_TO' => 'Balas ke',
    'LBL_EMAIL_RETRIEVING_MESSAGE' => 'Mengakses Message',
    'LBL_EMAIL_RETRIEVING_RECORD' => 'Mengakses Email Record',
    'LBL_EMAIL_SELECT_ONE_RECORD' => 'Silahkan pilih hanya satu record email',
    'LBL_EMAIL_RETURN_TO_VIEW' => 'Kembali ke modul sebelumnya?',
    'LBL_EMAIL_REVERT' => 'Kembalikan',
    'LBL_EMAIL_RELATE_EMAIL' => 'Email Terkait',

    'LBL_EMAIL_RULES_TITLE' => 'Manajemen Peraturan',

    'LBL_EMAIL_SAVE' => 'Save',
    'LBL_EMAIL_SAVE_AND_REPLY' => 'Simpan & Balas',
    'LBL_EMAIL_SAVE_DRAFT' => 'Simpan Konsep [Alt + R]',
    'LBL_EMAIL_DRAFT_SAVED' => 'Draf telah disimpan',

    'LBL_EMAIL_SEARCH' => SugarThemeRegistry::current()->getImage('Search', 'align=absmiddle border=0', null, null,    '.gif', ''),
    'LBL_EMAIL_SEARCH_SHORT' => SugarThemeRegistry::current()->getImage('Search', 'align=absmiddle border=0', null,        null, '.gif', ''),
    'LBL_EMAIL_SEARCH_DATE_FROM' => 'Dari Tanggal',
    'LBL_EMAIL_SEARCH_DATE_UNTIL' => 'Sampai Tanggal',
    'LBL_EMAIL_SEARCH_NO_RESULTS' => 'Tidak ada hasil dari kriteria pencarian yang dimasukkan.',
    'LBL_EMAIL_SEARCH_RESULTS_TITLE' => 'Hasil Pencarian',

    'LBL_EMAIL_SELECT' => 'Select',

    'LBL_EMAIL_SEND' => 'Send',
    'LBL_EMAIL_SENDING_EMAIL' => 'Kirim Pesan',

    'LBL_EMAIL_SETTINGS' => 'Pengaturan',
    'LBL_EMAIL_SETTINGS_ACCOUNTS' => 'Email Accounts',
    'LBL_EMAIL_SETTINGS_ADD_ACCOUNT' => 'Kosongkan Form',
    'LBL_EMAIL_SETTINGS_CHECK_INTERVAL' => 'Cek Pesan Baru',
    'LBL_EMAIL_SETTINGS_FROM_ADDR' => 'Dari Alamat',
    'LBL_EMAIL_SETTINGS_FROM_TO_EMAIL_ADDR' => 'Alamat Email untuk tes notifikasi:',
    'LBL_EMAIL_SETTINGS_FROM_ADDR_NOT_SET' => 'From address and/or From name not set',
    'LBL_EMAIL_SETTINGS_FROM_NAME' => 'Dari Nama',
    'LBL_EMAIL_SETTINGS_REPLY_TO_ADDR' => 'Balas ke Alamat',
    'LBL_EMAIL_SETTINGS_FULL_SYNC' => 'Sinkronisasi Semua Email Account',
    'LBL_EMAIL_TEST_NOTIFICATION_SENT' => 'Sebuah email telah dikirim ke alamat email menggunakan setting email yang ada. Silahkan cek apakah email tersebut telah diterima, dengan tujuan untuk melihat apakah pengaturannya sudah benar.',
    'LBL_EMAIL_TEST_SEE_FULL_SMTP_LOG' => 'Lihat Log SMTP penuh',
    'LBL_EMAIL_SETTINGS_FULL_SYNC_WARN' => 'Lakukan sinkronisasi penuh?\n Email Account yang berukuran besar akan membutuhkan waktu lama.',
    'LBL_EMAIL_SUBSCRIPTION_FOLDER_HELP' => 'Klik tombol Shift or tombol Ctrl untuk memilih lebih dari 1 folder.',
    'LBL_EMAIL_SETTINGS_GENERAL' => 'Umum',
    'LBL_EMAIL_SETTINGS_GROUP_FOLDERS_CREATE' => 'Buat Group Folder',

    'LBL_EMAIL_SETTINGS_GROUP_FOLDERS_EDIT' => 'Edit Folder Grup',

    'LBL_EMAIL_SETTINGS_NAME' => 'Nama',
    'LBL_EMAIL_SETTINGS_REQUIRE_REFRESH' => 'Pengaturan ini akan membutuhkan halaman ini untuk di-refresh.',
    'LBL_EMAIL_SETTINGS_RETRIEVING_ACCOUNT' => 'Mengakses Email Account',
    'LBL_EMAIL_SETTINGS_SAVED' => 'Pengaturan telah disimpan.',
    'LBL_EMAIL_SETTINGS_SEND_EMAIL_AS' => 'Kirim Pesan sebagai Plain Text',
    'LBL_EMAIL_SETTINGS_SHOW_NUM_IN_LIST' => 'Jumlah email per halaman',
    'LBL_EMAIL_SETTINGS_TITLE_LAYOUT' => 'Pengaturan Visual',
    'LBL_EMAIL_SETTINGS_TITLE_PREFERENCES' => 'Preferensi',
    'LBL_EMAIL_SETTINGS_USER_FOLDERS' => 'User Folders yang ada',
    'LBL_EMAIL_ERROR_PREPEND' => 'Terjadi kesalahan email:',
    'LBL_EMAIL_INVALID_PERSONAL_OUTBOUND' => 'Outbound mail server yang dipilih untuk Email Account yang Anda gunakan salah. Periksa pengaturannya atau pilih mail server yang berbeda untuk Email Account tersebut.',
    'LBL_EMAIL_INVALID_SYSTEM_OUTBOUND' => 'Outband mail server belum dikonfigurasi untuk Outgoing Email Account yang Anda gunakan. Silahkan pilih outband mail server yang lain atau tambah yang baru untuk Email account tersebut.',
    'LBL_DEFAULT_EMAIL_SIGNATURES' => 'Tanda tangan standar',
    'LBL_EMAIL_SIGNATURES' => 'Tanda-tangan',
    'LBL_SMTPTYPE_GMAIL' => 'Gmail',
    'LBL_SMTPTYPE_YAHOO' => 'Yahoo! Mail',
    'LBL_SMTPTYPE_EXCHANGE' => 'Microsoft Exchange',
    'LBL_SMTPTYPE_OTHER' => 'Other',
    'LBL_EMAIL_SPACER_MAIL_SERVER' => '[ Remot Folder ]',
    'LBL_EMAIL_SPACER_LOCAL_FOLDER' => '[ SuiteCRM Folder ]',
    'LBL_EMAIL_SUBJECT' => 'Subjek',
    'LBL_EMAIL_SUCCESS' => 'Sukses',
    'LBL_EMAIL_SUITE_FOLDER' => 'Folder SuiteCRM',
    'LBL_EMAIL_TEMPLATE_EDIT_PLAIN_TEXT' => 'Isi dari template email masih kosong',
    'LBL_EMAIL_TEMPLATES' => 'Template',
    'LBL_EMAIL_TO' => 'Untuk',
    'LBL_EMAIL_VIEW' => 'View',
    'LBL_EMAIL_VIEW_HEADERS' => 'Tampilkan Headers',
    'LBL_EMAIL_VIEW_RAW' => 'Tampilkan Raw Email',
    'LBL_EMAIL_VIEW_UNSUPPORTED' => 'Fitur ini bisa dijalankan jika menggunakan POP3.',
    'LBL_DEFAULT_LINK_TEXT' => 'Teks tautan default.',
    'LBL_EMAIL_YES' => 'Ya',
    'LBL_EMAIL_TEST_OUTBOUND_SETTINGS' => 'Kirim Email untuk test',
    'LBL_EMAIL_TEST_OUTBOUND_SETTINGS_SENT' => 'Test Email telah dikirim',
    'LBL_EMAIL_MESSAGE_NO' => 'Jangan pesan.',
    'LBL_EMAIL_IMPORT_SUCCESS' => 'Import Berhasil',
    'LBL_EMAIL_IMPORT_FAIL' => 'Import Gagal karena pesan ini telah di-import atau dihapus dari server',

    'LBL_LINK_NONE' => 'Tidak ada',
    'LBL_LINK_ALL' => 'Semua',
    'LBL_LINK_RECORDS' => 'Record',
    'LBL_LINK_SELECT' => 'Select',
    'LBL_LINK_ACTIONS' => 'TINDAKAN',
    'LBL_CLOSE_ACTIVITY_HEADER' => 'Memastikan',
    'LBL_CLOSE_ACTIVITY_CONFIRM' => 'Apakah Anda ingin menutup #modul# ini?',
    'LBL_INVALID_FILE_EXTENSION' => 'Ekstensi file tidak valid',

    'ERR_AJAX_LOAD' => 'Sebuah kesalahan telah terjadi:',
    'ERR_AJAX_LOAD_FAILURE' => 'Ada kesalahan saat memproses permintaan kamu, silahkan coba lagi di lain waktu.',
    'ERR_AJAX_LOAD_FOOTER' => 'Jika kesalahan ini berlanjut, mintalah administrator Anda menonaktifkan Ajax untuk modul ini',
    'ERR_DECIMAL_SEP_EQ_THOUSANDS_SEP' => 'Pemisah desimal tidak bisa memakai karakter yang sama dengan pemisah ribuan. \\n\\n  Silahkan diubah nilainya.',
    'ERR_DELETE_RECORD' => 'Nomor Record harus ditentukan untuk menghapus kontak.',
    'ERR_EXPORT_DISABLED' => 'Exports Tidak Diaktifkan.',
    'ERR_EXPORT_TYPE' => 'Error saat mengekspor ',
    'ERR_INVALID_EMAIL_ADDRESS' => 'alamat Email tidak valid.',
    'ERR_INVALID_FILE_REFERENCE' => 'Referensi file tidak valid',
    'ERR_NO_HEADER_ID' => 'Fitur ini tidak tersedia di theme ini.',
    'ERR_NOT_ADMIN' => 'Tidak memiliki akses untuk administrasi.',
    'ERR_UNAUTHORIZED_PAGE_ACCESS' => 'Anda tidak diizinkan mengakses halaman ini. Silakan hubungi administrator sistem Anda.',
    'ERR_UNAUTHORIZED_PAGE_ACCESS_TO_HOME_PAGE' => 'Anda tidak diizinkan mengakses halaman ini. Mengarahkan kembali ke Beranda...',
    'ERR_MISSING_REQUIRED_FIELDS' => 'Field yang dibutuhkan tidak ada:',
    'ERR_INVALID_REQUIRED_FIELDS' => 'Field yang dibutuhkan salah:',
    'ERR_INVALID_VALUE' => 'Nilai tidak valid:',
    'ERR_NO_SUCH_FILE' => 'File tidak ada di dalam sistem',
    'ERR_NO_SINGLE_QUOTE' => 'Tidak bisa menggunakan tanda petik tunggal untuk ',
    'ERR_NOTHING_SELECTED' => 'Silahkan memilih sebelum melanjutkan.',
    'ERR_SELF_REPORTING' => 'Pengguna tidak bisa melapor ke dirinya sendiri.',
    'ERR_SQS_NO_MATCH_FIELD' => 'Tidak ada yang cocok untuk field: ',
    'ERR_SQS_NO_MATCH' => 'Tidak Cocok',
    'ERR_ADDRESS_KEY_NOT_SPECIFIED' => 'Mohon dibuat spesifik \'key\' index di displayParams attribute untuk definisi  Meta-Data',
    'ERR_EXISTING_PORTAL_USERNAME' => 'Error: Nama portal tersebut sudah di-assign ke kontak lain.',
    'ERR_COMPATIBLE_PRECISION_VALUE' => 'Nilai field tidak kompatibel dengan nilai presisi',
    'ERR_EXTERNAL_API_SAVE_FAIL' => 'Kesalahan terjadi ketika mencoba untuk menyimpan ke akun eksternal.',
    'ERR_NO_DB' => 'Tidak bisa terhubung ke database. Silakan merujuk ke suitecrm.log untuk rincian (0).',
    'ERR_DB_FAIL' => 'Kegagalan database Silakan merujuk ke suitecrm.log untuk rinciannya.',
    'ERR_DB_VERSION' => 'SuiteCRM {0} File Dapat Digunakan Hanya Dengan Database SuiteCRM {1}.',

    'LBL_ACCOUNT' => 'Akun',
    'LBL_ACCOUNTS' => 'Akun',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
    'LBL_ACCUMULATED_HISTORY_BUTTON_KEY' => 'H',
    'LBL_ACCUMULATED_HISTORY_BUTTON_LABEL' => 'Lihat Ringkasan',
    'LBL_ACCUMULATED_HISTORY_BUTTON_TITLE' => 'View Summary',
    'LBL_ADD_BUTTON' => 'Add',
    'LBL_ADD_DOCUMENT' => 'Tambah Dokumen',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_KEY' => 'L',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL' => 'Tambah ke Daftar Sasaran',
    'LBL_ADD_TO_PROSPECT_LIST_BUTTON_LABEL_ACCOUNTS_CONTACTS' => 'Tambahkan Kontak ke Daftar Target',
    'LBL_ADDITIONAL_DETAILS_CLOSE_TITLE' => 'Klik untuk Menutup',
    'LBL_ADDITIONAL_DETAILS' => 'Rincian Tambahan',
    'LBL_ADMIN' => 'Admin',
    'LBL_ALT_HOT_KEY' => '',
    'LBL_ARCHIVE' => 'Arsip',
    'LBL_ASSIGNED_TO_USER' => 'Menugaskan ke Pengguna',
    'LBL_ASSIGNED_TO' => 'Ditugaskan kepada:',
    'LBL_BACK' => 'Back',
    'LBL_BILLING_ADDRESS' => 'Alamat Tagihan',
    'LBL_QUICK_CREATE' => 'Buat ',
    'LBL_BROWSER_TITLE' => 'SuiteCRM - Open Source CRM',
    'LBL_BUGS' => 'Bugs',
    'LBL_BY' => 'Oleh',
    'LBL_CALLS' => 'Calls',
    'LBL_CAMPAIGNS_SEND_QUEUED' => 'Kirim Antrian Pesan Kampanye',
    'LBL_CAMPAIGNS_SEND_NEXT_BATCH' => 'Send Next Batch of Queued Emails',
    'LBL_SENT_NEXT_BATCH' => 'Batch sent successfully',
    'LBL_SUBMIT_BUTTON_LABEL' => 'Kirim',
    'LBL_CASE' => 'Case',
    'LBL_CASES' => 'Cases',
    'LBL_CHANGE_PASSWORD' => 'Ganti kata sandi',
    'LBL_CHARSET' => 'UTF-8',
    'LBL_CHARTS' => 'Charts',
    'LBL_QUICK_CHARTS' => 'Bagan Cepat',
    'LBL_QUICK_HISTORY' => 'Linimasa',
    'LBL_CHECKALL' => 'Periksa semua',
    'LBL_CITY' => 'City',
    'LBL_CLEAR_BUTTON_LABEL' => 'Clear',
    'LBL_CLEAR_BUTTON_TITLE' => 'Clear',
    'LBL_CLEARALL' => 'Bersihkan Semua',
    'LBL_CLOSE_BUTTON_TITLE' => 'Close',
    'LBL_CLOSE_AND_CREATE_BUTTON_LABEL' => 'Tutup dan Buat Baru',
    'LBL_CLOSE_AND_CREATE_BUTTON_TITLE' => 'Close and Create New',
    'LBL_CLOSE_AND_CREATE_BUTTON_KEY' => 'C',
    'LBL_OPEN_ITEMS' => 'Buka Item',
    'LBL_COMPOSE_EMAIL_BUTTON_KEY' => 'L',
    'LBL_COMPOSE_EMAIL_BUTTON_LABEL' => 'Tulis Email',
    'LBL_COMPOSE_EMAIL_BUTTON_TITLE' => 'Menulis Email',
    'LBL_SEARCH_DROPDOWN_YES' => 'Ya',
    'LBL_SEARCH_DROPDOWN_NO' => 'No',
    'LBL_CONTACT_LIST' => 'Daftar Kontak',
    'LBL_CONTACT' => 'Contact',
    'LBL_CONTACTS' => 'Contacts',
    'LBL_CONTRACT' => 'Kontrak',
    'LBL_CONTRACTS' => 'Contracts',
    'LBL_COUNTRY' => 'Country:',
    'LBL_CREATE_BUTTON_LABEL' => 'Buat',
    'LBL_CREATED_BY_USER' => 'Dibuat oleh Pengguna',
    'LBL_CREATED_BY' => 'Created By',
    'LBL_CREATED_USER' => 'Dibuat oleh Pengguna',
    'LBL_CREATED' => 'Dibuat oleh',
    'LBL_CURRENT_USER_FILTER' => 'Barang-barang Saya',
    'LBL_CURRENCY' => 'Currency:',
    'LBL_DOCUMENTS' => 'Dokumen',
    'LBL_DATE_ENTERED' => 'Date Created:',
    'LBL_DATE_MODIFIED' => 'Date Modified:',
    'LBL_EDIT_BUTTON' => 'Sunting',
    'LBL_DUPLICATE_BUTTON' => 'Duplicate',
    'LBL_DELETE_BUTTON' => 'Delete',
    'LBL_DELETE' => 'Delete',
    'LBL_DELETED' => 'Deleted',
    'LBL_LIMIT' => 'Limit: ',
    'LBL_DIRECT_REPORTS' => 'Laporan langsung',
    'LBL_DONE_BUTTON_LABEL' => 'Done',
    'LBL_DONE_BUTTON_TITLE' => 'Done',
    'LBL_FAVORITES' => 'Favorit',
    'LBL_VCARD' => 'vCard',
    'LBL_EMPTY_VCARD' => 'Silahkan pilih vCard',
    'LBL_EMPTY_REQUIRED_VCARD' => 'vCard tidak memiliki semua yang diperlukan untuk modul ini. Silakan merujuk ke suitecrm.log untuk rincian.',
    'LBL_VCARD_ERROR_FILESIZE' => 'Berkas yang diunggah melebihi batas ukuran 30000 byte yang ditentukan dalam bentuk HTML.',
    'LBL_VCARD_ERROR_DEFAULT' => 'Terjadi kesalahan saat mengunggah berkas vCard. Silakan merujuk ke suitecrm.log untuk rinciannya.',
    'LBL_IMPORT_VCARD' => 'Impor vCard:',
    'LBL_IMPORT_VCARD_BUTTON_LABEL' => 'Impor vCard',
    'LBL_IMPORT_VCARD_BUTTON_TITLE' => 'Import vCard',
    'LBL_VIEW_BUTTON' => 'View',
    'LBL_EMAIL_PDF_BUTTON_LABEL' => 'Email sebagai PDF',
    'LBL_EMAIL_PDF_BUTTON_TITLE' => 'Email as PDF',
    'LBL_EMAILS' => 'Email',
    'LBL_EMPLOYEES' => 'Karyawan',
    'LBL_ENTER_DATE' => 'Tanggal Masuk',
    'LBL_EXPORT' => 'Ekspor',
    'LBL_FAVORITES_FILTER' => 'Favorit Saya',
    'LBL_GO_BUTTON_LABEL' => 'Pergi',
    'LBL_HIDE' => 'Tersembunyi',
    'LBL_HISTORY' => 'History',
    'LBL_NEW' => 'New',
    'LBL_ID' => 'ID',
    'LBL_IMPORT' => 'Impor',
    'LBL_IMPORT_STARTED' => 'Proses Impor Dimulai: ',
    'LBL_LAST_VIEWED' => 'Dilihat Terakhir',
    'LBL_LAST_VIEWED_NO_RESULT' => 'No Recently Viewed Items',
    'LBL_LEADS' => 'Leads',
    'LBL_LESS' => 'kurang',
    'LBL_CAMPAIGN' => 'Campaign:',
    'LBL_CAMPAIGNS' => 'Campaigns',
    'LBL_CAMPAIGNLOG' => 'Log Kampanye',
    'LBL_CAMPAIGN_CONTACT' => 'Campaigns',
    'LBL_CAMPAIGN_ID' => 'campaign_id',
    'LBL_CAMPAIGN_NONE' => 'Tidak ada',
    'LBL_CAMPAIGN_CHARTS' => 'Campaign Charts',
    'LBL_EMAIL_MARKETING_CHARTS' => 'Email Marketing Charts',
    'LBL_MESSAGE_QUEUE_TITLE' => 'Message Queue',
    'LBL_CAMPAIGN_SEND_STATUS' => 'Campaign Send Status',
    'LBL_EMAIL_MARKETING_SEND_STATUS' => 'Email Marketing Send Status',
    'LBL_CAMPAIGN_RESPONSE_BY_RECIPIENT_ACTIVITY' => 'Campaign Response By Recipient Activity',
    'LBL_EMAIL_MARKETING_RESPONSE_BY_RECIPIENT_ACTIVITY' => 'Email Marketing Response By Recipient Activity',
    'LBL_LOG_ENTRIES_TARGETED_TITLE' => 'Sent/Attempted',
    'LBL_LOG_ENTRIES_SEND_ERROR_TITLE' => 'Bounced Messages, Other',
    'LBL_LOG_ENTRIES_BOUNCED_TITLE' => 'Bounced Messages',
    'LBL_LOG_ENTRIES_INVALID_EMAIL_TITLE' => 'Bounced Messages, Invalid Email',
    'LBL_LOG_ENTRIES_LINK_TITLE' => 'Klik-thru link',
    'LBL_LOG_ENTRIES_VIEWED_TITLE' => 'Viewed Message',
    'LBL_LOG_ENTRIES_REMOVED_TITLE' => 'Opted Out',
    'LBL_LOG_ENTRIES_LEAD_TITLE' => 'Leads Created',
    'LBL_CAMPAIGN_LEAD_SUBPANEL_TITLE' => 'Leads',
    'LBL_OPPORTUNITY_SUBPANEL_TITLE' => 'Opportunities',
    'LBL_LOG_ENTRIES_CONTACT_TITLE' => 'Contacts Created',
    'LBL_LOG_ENTRIES_BLOCKED_TITLE' => 'Suppressed/Blocked',
    'LBL_THEME' => 'Bahasa:',
    'LBL_FOUND_IN_RELEASE' => 'Ditemukan di Release',
    'LBL_FIXED_IN_RELEASE' => 'Diperbaiki di Release',
    'LBL_IN_EVERYWHERE' => 'In Everywhere',
    'LBL_LIST_ACCOUNT_NAME' => 'Nama Akun',
    'LBL_LIST_ASSIGNED_USER' => 'User',
    'LBL_LIST_CONTACT_NAME' => 'Nama Kontak',
    'LBL_LIST_CONTACT_ROLE' => 'Peran Kontak',
    'LBL_LIST_DATE_ENTERED' => 'Tanggal Dibuat',
    'LBL_LIST_EMAIL' => 'Surel',
    'LBL_LIST_NAME' => 'Nama ',
    'LBL_LIST_OF' => 'dari',
    'LBL_LIST_PHONE' => 'Phone',
    'LBL_LIST_RELATED_TO' => 'Terkait dengan',
    'LBL_LIST_USER_NAME' => 'Nama Pengguna',
    'LBL_LISTVIEW_NO_SELECTED' => 'Silahkan pilih setidaknya 1 record untuk melanjutkan.',
    'LBL_LISTVIEW_TWO_REQUIRED' => 'Silahkan pilih setidaknya 2 record untuk melanjutkan.',
    'LBL_LISTVIEW_OPTION_SELECTED' => 'Record Terpilih',
    'LBL_LISTVIEW_SELECTED_OBJECTS' => 'Terpilih: ',

    'LBL_LOCALE_NAME_EXAMPLE_FIRST' => 'Budiman',
    'LBL_LOCALE_NAME_EXAMPLE_LAST' => 'Suryagantara',
    'LBL_LOCALE_NAME_EXAMPLE_SALUTATION' => 'Dr.',
    'LBL_LOCALE_NAME_EXAMPLE_TITLE' => 'Kode Monyet Luar Biasa',
    'LBL_COPY' => 'Salin',
    'LBL_CANCEL' => 'Batal',
    'LBL_SNOOZE' => 'Snooze',
    'LBL_SNOOZE_INLINE_CONFIRM' => 'Snooze? ({{preferences.snooze_alert_timer|enum:snooze_alert_timer_simple}})',
    'LBL_DISMISS' => 'Dismiss',
    'LBL_DISMISS_INLINE_CONFIRM' => 'Dismiss?',
    'LBL_DISMISS_ALL_INLINE_CONFIRM' => 'Dismiss All?',
    'NTC_DISMISS_CONFIRMATION' => 'Are you sure you want to dismiss this alert?',
    'NTC_DISMISS_ALL_CONFIRMATION' => 'Are you sure you want to dismiss all alerts?',
    'LBL_ALERT_DISMISS_SUCCESS' => 'Alert dismissed successfully',
    'LBL_ALERT_DISMISS_ERROR' => 'Error while trying to dismiss alert',
    'LBL_ALERT_DISMISS_ALL_SUCCESS' => 'Alerts dismissed successfully',
    'LBL_DISMISS_ALL' => 'Dismiss All',
    'LBL_VERIFY' => 'Memeriksa',
    'LBL_RESEND' => 'Kirim ulang',
    'LBL_RECORD_DOES_NOT_EXIST' => 'Error retrieving record. This record may be deleted or you may not be authorized to view it.',
    'LBL_PROFILE' => 'Profil',
    'LBL_PROFILE_EDIT' => 'Edit Profile',
    'LBL_MAILMERGE' => 'Menggabungkan surat',
    'LBL_MASS_UPDATE' => 'Update Masal',
    'LBL_NO_MASS_UPDATE_FIELDS_AVAILABLE' => 'Tidak ada bidang yang tersedia untuk massa operasi pembaruan',
    'LBL_OPT_OUT_FLAG_PRIMARY' => 'Opt out Email Utama',
    'LBL_OPT_IN_FLAG_PRIMARY' => 'Memilih Email Utama',
    'LBL_MEETINGS' => 'Meetings',
    'LBL_MEETING_GO_BACK' => 'Kembali ke pertemuan',
    'LBL_MEMBERS' => 'Anggota',
    'LBL_MEMBER_OF' => 'Anggota dari',
    'LBL_MODIFIED_BY_USER' => 'Modified by User',
    'LBL_MODIFIED_USER' => 'Modified by User',
    'LBL_MODIFIED' => 'Diubah oleh',
    'LBL_MODIFIED_NAME' => 'Modifikasi berdasarkan Nama',
    'LBL_MORE' => 'Lebih',
    'LBL_MY_ACCOUNT' => 'Pengaturan Saya',
    'LBL_NAME' => 'Nama ',
    'LBL_NEW_BUTTON_KEY' => 'N',
    'LBL_NEW_BUTTON_LABEL' => 'Buat [Alt+N]',
    'LBL_NEW_BUTTON_TITLE' => 'Create',
    'LBL_EDIT' => 'Sunting',
    'LBL_NEXT_BUTTON_LABEL' => 'Next',
    'LBL_NONE' => '--Kosong--',
    'LBL_NOTES' => 'Notes',
    'LBL_OPPORTUNITIES' => 'Opportunities',
    'LBL_OPPORTUNITY_NAME' => 'Nama Peluang',
    'LBL_OPPORTUNITY' => 'Opportunity',
    'LBL_OR' => 'Atau',
    'LBL_PANEL_OVERVIEW' => 'Informasi account',
    'LBL_PANEL_ASSIGNMENT' => 'OTHER',
    'LBL_PANEL_ADVANCED' => 'INFORMASI LEBIH LANJUT',
    'LBL_PARENT_TYPE' => 'Tipe Parent',
    'LBL_PERCENTAGE_SYMBOL' => '%',
    'LBL_POSTAL_CODE' => 'Postal Code:',
    'LBL_PRIMARY_ADDRESS_CITY' => 'Alamat Kota utama:',
    'LBL_PRIMARY_ADDRESS_COUNTRY' => 'Primary Address Country:',
    'LBL_PRIMARY_ADDRESS_POSTALCODE' => 'Alamat Kode Pos utama:',
    'LBL_PRIMARY_ADDRESS_STATE' => 'Alamat negara utama:',
    'LBL_PRIMARY_ADDRESS_STREET_2' => 'Primary Address Street 2:',
    'LBL_PRIMARY_ADDRESS_STREET_3' => 'Primary Address Street 3:',
    'LBL_PRIMARY_ADDRESS_STREET' => 'Primary Alamat Jalan:',
    'LBL_PRIMARY_ADDRESS' => 'Primary Alamat:',

    'LBL_PROSPECTS' => 'Prospek',
    'LBL_PRODUCTS' => 'Produk',
    'LBL_PROJECT_TASKS' => 'Project Tasks',
    'LBL_PROJECTS' => 'Projects',
    'LBL_QUOTES' => 'Quotes',

    'LBL_RELATED' => 'Terkait',
    'LBL_RELATED_RECORDS' => 'Record terkait',
    'LBL_REMOVE' => 'Remove',
    'LBL_REPORTS_TO' => 'Laporan Untuk',
    'LBL_REQUIRED_SYMBOL' => '*',
    'LBL_REQUIRED_TITLE' => 'Menandakan Field yang diperlukan',
    'LBL_EMAIL_DONE_BUTTON_LABEL' => 'Done',
    'LBL_FULL_FORM_BUTTON_KEY' => 'L',
    'LBL_FULL_FORM_BUTTON_LABEL' => 'Formulir Lengkap',
    'LBL_FULL_FORM_BUTTON_TITLE' => 'Full Form',
    'LBL_SAVE_NEW_BUTTON_LABEL' => 'Simpan & Buat Baru',
    'LBL_SAVE_NEW_BUTTON_TITLE' => 'Save & Create New',
    'LBL_SAVE_OBJECT' => 'Simpan {0}',
    'LBL_SEARCH_BUTTON_KEY' => 'C',
    'LBL_SEARCH_BUTTON_LABEL' => 'Cari',
    'LBL_SEARCH_BUTTON_TITLE' => 'Search',
    'LBL_FILTER' => 'Menyaring',
    'LBL_CLEAR_FILTER' => 'Hapus Filter',
    'LBL_FILTER_MODULES' => 'Filter Modules',
    'LBL_SEARCH' => 'Search',
    'LBL_SEARCH_ALT' => '',
    'LBL_SEARCH_MORE' => 'lebih',
    'LBL_UPLOAD_IMAGE_FILE_INVALID' => 'Format file salah, hanya file gambar yang bisa diupload.',
    'LBL_SELECT_BUTTON_KEY' => 'T',
    'LBL_SELECT_BUTTON_LABEL' => 'Select',
    'LBL_SELECT_BUTTON_TITLE' => 'Select',
    'LBL_BROWSE_DOCUMENTS_BUTTON_LABEL' => 'Jelajahi Dokumen',
    'LBL_BROWSE_DOCUMENTS_BUTTON_TITLE' => 'Jelajahi Dokumen',
    'LBL_SELECT_CONTACT_BUTTON_KEY' => 'T',
    'LBL_SELECT_CONTACT_BUTTON_LABEL' => 'Pilih Kontak',
    'LBL_SELECT_CONTACT_BUTTON_TITLE' => 'Select Contact',
    'LBL_SELECT_REPORTS_BUTTON_LABEL' => 'Pilih dari Laporan',
    'LBL_SELECT_REPORTS_BUTTON_TITLE' => 'Pilih Laporan',
    'LBL_SELECT_USER_BUTTON_KEY' => 'U',
    'LBL_SELECT_USER_BUTTON_LABEL' => 'Pilih Pemakai',
    'LBL_SELECT_USER_BUTTON_TITLE' => 'Select User',
    // Clear buttons take up too many keys, lets default the relate and collection ones to be empty
    'LBL_ACCESSKEY_CLEAR_RELATE_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_RELATE_TITLE' => 'Hapus Pilihan',
    'LBL_ACCESSKEY_CLEAR_RELATE_LABEL' => 'Hapus Pilihan',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_TITLE' => 'Hapus Pilihan',
    'LBL_ACCESSKEY_CLEAR_COLLECTION_LABEL' => 'Hapus Pilihan',
    'LBL_ACCESSKEY_SELECT_FILE_KEY' => 'F',
    'LBL_ACCESSKEY_SELECT_FILE_TITLE' => 'Pilih File',
    'LBL_ACCESSKEY_SELECT_FILE_LABEL' => 'Select File',
    'LBL_ACCESSKEY_CLEAR_FILE_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_FILE_TITLE' => 'Hapus File',
    'LBL_ACCESSKEY_CLEAR_FILE_LABEL' => 'Hapus File',

    'LBL_ACCESSKEY_SELECT_USERS_KEY' => 'U',
    'LBL_ACCESSKEY_SELECT_USERS_TITLE' => 'Select User',
    'LBL_ACCESSKEY_SELECT_USERS_LABEL' => 'Select User',
    'LBL_ACCESSKEY_CLEAR_USERS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_USERS_TITLE' => 'Hapus Pengguna',
    'LBL_ACCESSKEY_CLEAR_USERS_LABEL' => 'Hapus Pengguna',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_KEY' => 'A',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_TITLE' => 'Pilih Acccount',
    'LBL_ACCESSKEY_SELECT_ACCOUNTS_LABEL' => 'Select Account',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_TITLE' => 'Hapus Akun',
    'LBL_ACCESSKEY_CLEAR_ACCOUNTS_LABEL' => 'Hapus Akun',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_KEY' => 'M',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_TITLE' => 'Pilih Kampanye',
    'LBL_ACCESSKEY_SELECT_CAMPAIGNS_LABEL' => 'Pilih Kampanye',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_TITLE' => 'Hapus Kampanye',
    'LBL_ACCESSKEY_CLEAR_CAMPAIGNS_LABEL' => 'Hapus Kampanye',
    'LBL_ACCESSKEY_SELECT_CONTACTS_KEY' => 'C',
    'LBL_ACCESSKEY_SELECT_CONTACTS_TITLE' => 'Select Contact',
    'LBL_ACCESSKEY_SELECT_CONTACTS_LABEL' => 'Select Contact',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_TITLE' => 'Hapus Kontak',
    'LBL_ACCESSKEY_CLEAR_CONTACTS_LABEL' => 'Hapus Kontak',
    'LBL_ACCESSKEY_SELECT_TEAMSET_KEY' => 'Z',
    'LBL_ACCESSKEY_SELECT_TEAMSET_TITLE' => 'Pilih Tim',
    'LBL_ACCESSKEY_SELECT_TEAMSET_LABEL' => 'Pilih Tim',
    'LBL_ACCESSKEY_CLEAR_TEAMS_KEY' => ' ',
    'LBL_ACCESSKEY_CLEAR_TEAMS_TITLE' => 'Hapus Tim',
    'LBL_ACCESSKEY_CLEAR_TEAMS_LABEL' => 'Hapus Tim',
    'LBL_SERVER_RESPONSE_RESOURCES' => 'Resources yang digunakan untuk membuat halaman ini (queries, files)',
    'LBL_SERVER_RESPONSE_TIME_SECONDS' => 'detik.',
    'LBL_SERVER_RESPONSE_TIME' => 'Waktu Respon Server:',
    'LBL_SERVER_MEMORY_BYTES' => 'byte',
    'LBL_SERVER_MEMORY_USAGE' => 'Penggunaan Memori Server: {0} ({1})',
    'LBL_SERVER_MEMORY_LOG_MESSAGE' => 'Penggunaan: - modul: {0} - tindakan: {1}',
    'LBL_SERVER_PEAK_MEMORY_USAGE' => 'Server Puncak Penggunaan Memori: {0} ({1})',
    'LBL_SHIPPING_ADDRESS' => 'Alamat Pengiriman',
    'LBL_SHOW' => 'Tampilkan',
    'LBL_STATE' => 'Negara:',
    'LBL_STATUS_UPDATED' => 'Status Anda untuk acara ini belum diperbaharui!',
    'LBL_STATUS' => 'Status:',
    'LBL_STREET' => 'Jalan',
    'LBL_SUBJECT' => 'Subject',

    'LBL_INBOUNDEMAIL_ID' => 'ID email masuk',

    'LBL_ALL_SCHEDULERS' => 'All Schedulers',
    'LBL_LEGACY_SCHEDULERS' => 'Legacy Schedulers',
    'LBL_SCHEDULERS' => 'Schedulers',
    'LBL_RUN_LEGACY_SCHEDULERS' => 'Running Legacy Schedulers',
    'LBL_LEGACY_SCHEDULERS_RUN_SUCCESSFULLY' => 'Legacy Schedulers run successfully!',
    'LBL_RUN_SCHEDULERS' => 'Running Schedulers',
    'LBL_LEGACY_SCHEDULER_FAILED' => 'Not all Schedulers were successful. See Logs.',
    'LBL_PASSED' => 'Passed',
    'LBL_FAILED' => 'Failed',

    'LBL_SCENARIO_SALES' => 'Sales',
    'LBL_SCENARIO_MARKETING' => 'Marketing',
    'LBL_SCENARIO_FINANCE' => 'Finance',
    'LBL_SCENARIO_SERVICE' => 'Pelayanan',
    'LBL_SCENARIO_PROJECT' => 'Proyek manajemen',

    'LBL_SCENARIO_SALES_DESCRIPTION' => 'Skenario ini memudahkan pengelolaan item penjualan',
    'LBL_SCENARIO_MAKETING_DESCRIPTION' => 'Skenario ini memudahkan pengelolaan pemasaran barang',
    'LBL_SCENARIO_FINANCE_DESCRIPTION' => 'Skenario ini memudahkan pengelolaan barang-barang yang terkait dengan keuangan',
    'LBL_SCENARIO_SERVICE_DESCRIPTION' => 'Skenario ini memudahkan pengelolaan terkait barang-barang layanan',
    'LBL_SCENARIO_PROJECT_DESCRIPTION' => 'Skenario ini meniru pengelolaan terkait proyek barang',

    'LBL_SYNC' => 'Sinkronisasi',
    'LBL_TABGROUP_ALL' => 'All',
    'LBL_TABGROUP_ACTIVITIES' => 'Activities',
    'LBL_TABGROUP_COLLABORATION' => 'Kolaborasi',
    'LBL_TABGROUP_MARKETING' => 'Marketing',
    'LBL_TABGROUP_OTHER' => 'Other',
    'LBL_TABGROUP_SALES' => 'Sales',
    'LBL_TABGROUP_SUPPORT' => 'Mendukung',
    'LBL_TASKS' => 'Tasks',
    'LBL_THOUSANDS_SYMBOL' => 'K',
    'LBL_TRACK_EMAIL_BUTTON_LABEL' => 'Arsip Email [Alt+K]',
    'LBL_TRACK_EMAIL_BUTTON_TITLE' => 'Archive Email',
    'LBL_TOO_MANY_ADDRESSES' => 'You have selected too many email addresses.',
    'LBL_NO_ADDRESSES_SELECTED' => 'Please select an address to send to.',
    'LBL_NOT_ALL_SENT' => 'Not all Emails sent. See logs for more info.',
    'LBL_NOT_VALID_TARGETS' => 'No targets validated to send to.',
    'LBL_ALL_EMAILS_SENT' => 'All test Emails sent successfully',
    'LBL_UNDELETE_BUTTON_LABEL' => 'Batal hapus',
    'LBL_UNDELETE_BUTTON_TITLE' => 'Batal hapus',
    'LBL_UNDELETE_BUTTON' => 'Batal hapus',
    'LBL_UNDELETE' => 'Batal hapus',
    'LBL_UNSYNC' => 'Unsync',
    'LBL_UPDATE' => 'Memperbarui',
    'LBL_USER_LIST' => 'Daftar Pemakai',
    'LBL_USERS' => 'Users',
    'LBL_VERIFY_EMAIL_ADDRESS' => 'Melakukan cek email entry yang sudah ada...',
    'LBL_VERIFY_PORTAL_NAME' => 'Melakukan cek nama portal yang sudah ada...',
    'LBL_VIEW_IMAGE' => 'lihat',
    'LBL_CREATE_PORTAL_USER_FAILED' => 'Gagal membuat pengguna portal',
    'LBL_CREATE_PORTAL_USER_SUCCESS' => 'Dibuat pengguna portal',

    'LNK_ABOUT' => 'Tentang',
    'LNK_ADVANCED_FILTER' => 'Penyaringan Lanjutan',
    'LNK_BASIC_FILTER' => 'Penyaring Cepat',
    'LBL_ADVANCED_SEARCH' => 'Penyaringan Lanjutan',
    'LBL_QUICK_FILTER' => 'Penyaring Cepat',
    'LBL_BASIC_FILTER' => 'Filter Dasar',
    'LBL_QUICK' => 'Cepat',
    'LNK_SEARCH_NONFTS_VIEW_ALL' => 'Tampilkan Semua',
    'LNK_CLOSE' => 'Close',
    'LBL_MODIFY_CURRENT_FILTER' => 'Modifikasi filter saat ini',
    'LNK_SAVED_VIEWS' => 'Pilihan Layout',
    'LNK_DELETE' => 'Delete',
    'LNK_EDIT' => 'Sunting',
    'LNK_GET_LATEST' => 'Dapatkan terbaru',
    'LNK_GET_LATEST_TOOLTIP' => 'Ganti dengan versi terakhir',
    'LNK_HELP' => 'Bantuan',
    'LNK_CREATE' => 'Create',
    'LNK_LIST_END' => 'Akhir',
    'LNK_LIST_NEXT' => 'Next',
    'LNK_LIST_PREVIOUS' => 'Sebelumnya',
    'LNK_LIST_RETURN' => 'Kembali ke Daftar',
    'LNK_LIST_START' => 'Mulai',
    'LNK_LOAD_SIGNED' => 'Tanda',
    'LNK_LOAD_SIGNED_TOOLTIP' => 'Ganti dengan dokumen bertanda',
    'LNK_PRINT' => 'Print',
    'LNK_BACKTOTOP' => 'Kembali ke atas',
    'LNK_REMOVE' => 'Remove',
    'LNK_RESUME' => 'Kembalikan',
    'LNK_VIEW_CHANGE_LOG' => 'Lihat Log Perubahan',
    'LBL_CHANGE_LOG' => 'Change Log',

    'NTC_CLICK_BACK' => 'Klik button Back pada browser dan perbaiki penyebab error.',
    'NTC_DATE_FORMAT' => '(yyyy-mm-dd)',
    'NTC_DELETE_CONFIRMATION_MULTIPLE' => 'Anda yakin mau menghapus record yang dipilih?',
    'NTC_SEND_QUEUED_CAMPAIGN_EMAILS' => 'Send Next Batch of Queued Campaign Emails?',
    'NTC_SNOOZE_CONFIRMATION' => 'Are you sure you want to snooze?',
    'NTC_TEMPLATE_IS_USED' => 'Template ini digunakan oleh setidaknya satu record pemasaran. Anda yakin ingin menghapus?',
    'NTC_TEMPLATES_IS_USED' => 'Berikut pola yang digunakan dalam pemasaran catatan email. Apakah kamu yakin kamu ingin menghapus mereka?' . PHP_EOL,
    'NTC_DELETE_CONFIRMATION' => 'Are you sure you want to delete this record?',
    'NTC_ABORT_CONFIRMATION' => 'Are you sure you want to abort?',
    'NTC_SCHEDULE_CONFIRMATION' => "When Scheduled, The Sending Process will begin once the Scheduled Run Date has been reached.",
    'NTC_DELETE_TEST_ENTRIES' => 'Scheduling will Delete Test Entries.',
    'NTC_DELETE_TEST_ENTRIES_CONFIRMATION' => 'Are you sure you want to delete test entries?',
    'NTC_PROCEED' => 'Would you like to proceed?',
    'NTC_UNSCHEDULE_CONFIRMATION' => 'Unscheduling will set the Status to "Draft".',
    'NTC_UNSCHEDULE_CONFIRMATION_OTHER' => 'The Sending Process will no longer begin, unless Re-Scheduled.',
    'NTC_DELETE_CONFIRMATION_NUM' => 'Anda yakin ingin menghapus ',
    'NTC_UPDATE_CONFIRMATION_NUM' => 'Anda yakin ingin memperbaharui ',
    'NTC_DELETE_SELECTED_RECORDS' => ' Record terpilih ?',
    'NTC_LOGIN_MESSAGE' => 'Masukkan nama Pengguna dan Password:',
    'NTC_NO_ITEMS_DISPLAY' => 'none',
    'NTC_REMOVE_CONFIRMATION' => 'Anda yakin ingin menghapus relasi ini?',
    'NTC_REQUIRED' => 'Indicates required field',
    'NTC_TIME_FORMAT' => '(24:00)',
    'NTC_WELCOME' => 'Selamat Datang',
    'NTC_YEAR_FORMAT' => '(yyyy)',
    'WARN_UNSAVED_CHANGES' => 'Kamu akan meninggalkan tentang catatan ini untuk tanpa menyimpan perubahan yang telah kamu buat untuk catatan. Apakah kamu yakin kamu ingin untuk memandu arah dari catatan ini?',
    'ERROR_NO_RECORD' => 'Error mengakses record.  Record ini mungkin telah dihapus atau Anda tidak memiliki hak akses untuk melihatnya.',
    'LBL_TEMPLATE_CONFIRMATION' => 'Apply new Email Template? (This will override your current email body and subject field)',
    'WARN_BROWSER_VERSION_WARNING' => '<b>Peringatan:</b> browser kamu versi ini tidak lagi didukung atau anda menggunakan browser yang tidak didukung.<p></p>berikut versi browser yang direkomendasikan:<p></p><ul><li>Internet Explorer 10 (tampilan kompatibilitas tidak didukung)<li>Firefox 32.0<li>Safari 5.1<li>Chrome 37</ul>',
    'WARN_BROWSER_IE_COMPATIBILITY_MODE_WARNING' => '<b>Peringatan:</b> browser kamu di IE tampilan kecocokan yang tidak didukung.',
    'ERROR_TYPE_NOT_VALID' => 'Error. Tipe ini tidak valid.',
    'ERROR_NO_BEAN' => 'Gagal mendapatkan kacang.',
    'LBL_DUP_MERGE' => 'Mencari Duplikat',
    'LBL_MANAGE_SUBSCRIPTIONS' => 'Mengelola Langganan',
    'LBL_MANAGE_SUBSCRIPTIONS_FOR' => 'Mengatur langganan untuk ',
    // Ajax status strings
    'LBL_LOADING' => 'Memuat ...',
    'LBL_SEARCHING' => 'Mencari...',
    'LBL_SAVING_LAYOUT' => 'Menyimpan Layout ...',
    'LBL_SAVED_LAYOUT' => 'Layout telah disimpan.',
    'LBL_SAVED' => 'tersimpan',
    'LBL_SAVING' => 'Sedang menyimpan',
    'LBL_DISPLAY_COLUMNS' => 'Tampilkan kolom',
    'LBL_HIDE_COLUMNS' => 'Menyembunyikan Kolom',
    'LBL_COLUMNS' => 'Kolom',
    'LBL_SEARCH_CRITERIA' => 'Kriteria pencarian',
    'LBL_SAVED_VIEWS' => 'Tampilan Tersimpan',
    'LBL_PROCESSING_REQUEST' => 'Memproses...',
    'LBL_REQUEST_PROCESSED' => 'Done',
    'LBL_AJAX_FAILURE' => 'Ajax Gagal',
    'LBL_MERGE_DUPLICATES' => 'Gabung',
    'LBL_SAVED_FILTER_SHORTCUT' => 'Filter saya',
    'LBL_SEARCH_POPULATE_ONLY' => 'Lakukan pencarian dengan menggunakan form pencarian di atas.',
    'LBL_DETAILVIEW' => 'Tampilan Detail',
    'LBL_LISTVIEW' => 'Tampilan daftar',
    'LBL_EDITVIEW' => 'Edit View',
    'LBL_BILLING_STREET' => 'Jalan:',
    'LBL_SHIPPING_STREET' => 'Jalan:',
    'LBL_SEARCHFORM' => 'Formulir Pencarian',
    'LBL_SAVED_SEARCH_ERROR' => 'Silahkan sediakan nama untuk tampilan ini.',
    'LBL_DISPLAY_LOG' => 'Log Tampilan',
    'ERROR_JS_ALERT_SYSTEM_CLASS' => 'Sistem',
    'ERROR_JS_ALERT_TIMEOUT_TITLE' => 'Sesi Timeout',
    'ERROR_JS_ALERT_TIMEOUT_MSG_1' => 'Session ada telah timeout selama 2 menit. Silahkan simpan apa yang Anda kerjakan.',
    'ERROR_JS_ALERT_TIMEOUT_MSG_2' => 'Session Anda telah timed out.',
    'MSG_JS_ALERT_MTG_REMINDER_AGENDA' => "\nAgenda: ",
    'MSG_JS_ALERT_MTG_REMINDER_MEETING' => 'Meeting',
    'MSG_JS_ALERT_MTG_REMINDER_CALL' => 'Call',
    'MSG_JS_ALERT_MTG_REMINDER_TIME' => 'Waktu: ',
    'MSG_JS_ALERT_MTG_REMINDER_LOC' => 'Lokasi: ',
    'MSG_JS_ALERT_MTG_REMINDER_DESC' => 'Deskripsi',
    'MSG_JS_ALERT_MTG_REMINDER_STATUS' => 'Status:',
    'MSG_JS_ALERT_MTG_REMINDER_RELATED_TO' => 'Berhubungan dengan: ',
    'MSG_JS_ALERT_MTG_REMINDER_CALL_MSG' => "\nClick OK to view this call or click Cancel to dismiss this message.",
    'MSG_JS_ALERT_MTG_REMINDER_MEETING_MSG' => "\nClick OK to view this meeting or click Cancel to dismiss this message.",
    'MSG_JS_ALERT_MTG_REMINDER_NO_EVENT_NAME' => 'Peristiwa',
    'MSG_JS_ALERT_MTG_REMINDER_NO_DESCRIPTION' => 'Acara tidak disetel.',
    'MSG_JS_ALERT_MTG_REMINDER_NO_LOCATION' => 'Lokasi tidak diatur.',
    'MSG_JS_ALERT_MTG_REMINDER_NO_START_DATE' => 'Tanggal mulai tidak ditentukan.',
    'MSG_LIST_VIEW_NO_RESULTS_BASIC' => 'Tidak ada hasil yang ditemukan.',
    'MSG_LIST_VIEW_NO_RESULTS_CHANGE_CRITERIA' => 'Tidak ada hasil yang ditemukan... Mungkin ubah kriteria pencarian Anda dan coba lagi?',
    'MSG_LIST_VIEW_NO_RESULTS' => 'Tidak ada hasil yang ditemukan untuk <item1>',
    'MSG_LIST_VIEW_NO_RESULTS_SUBMSG' => 'Buat <item1> sebagai <item2> baru',
    'MSG_LIST_VIEW_CHANGE_SEARCH' => 'atau ubah kriteria pencarian Anda',
    'MSG_EMPTY_LIST_VIEW_NO_RESULTS' => 'Anda saat ini tidak memiliki catatan yang tersimpan. <item2> atau <item3> satu sekarang.',

    // contextMenu strings
    'LBL_ADD_TO_FAVORITES' => 'Tambah ke Fovorit Saya',
    'LBL_CREATE_CONTACT' => 'Buat Kontak',
    'LBL_CREATE_CASE' => 'Create Case',
    'LBL_CREATE_NOTE' => 'Buat Catatan',
    'LBL_CREATE_OPPORTUNITY' => 'Buat Peluang',
    'LBL_SCHEDULE_CALL' => 'Jadwal Panggilan',
    'LBL_SCHEDULE_MEETING' => 'Jadwal Rapat',
    'LBL_CREATE_TASK' => 'Buat Tugas',
    //web to lead
    'LBL_GENERATE_WEB_TO_LEAD_FORM' => 'Buat Form',
    'LBL_SAVE_WEB_TO_LEAD_FORM' => 'Simpan Formulir Web',
    'LBL_AVAILABLE_FIELDS' => 'Field yang tersedia',
    'LBL_FIRST_FORM_COLUMN' => 'Kolom Form Pertama',
    'LBL_SECOND_FORM_COLUMN' => 'Kolom Formulir Kedua',
    'LBL_ASSIGNED_TO_REQUIRED' => 'Bidang wajib tidak ada: Ditugaskan ke',
    'LBL_RELATED_CAMPAIGN_REQUIRED' => 'Bidang wajib tidak ada: Kampanye terkait',
    'LBL_TYPE_OF_PERSON_FOR_FORM' => 'Formulir web untuk dibuat ',
    'LBL_TYPE_OF_PERSON_FOR_FORM_DESC' => 'Mengirimkan formulir ini akan tercipta ',

    'LBL_ADD_ALL_LEAD_FIELDS' => 'Tambah Semua Field',
    'LBL_RESET_ALL_LEAD_FIELDS' => 'Setel ulang semua Bidang',
    'LBL_REMOVE_ALL_LEAD_FIELDS' => 'Hapus Semua Fields',
    'LBL_NEXT_BTN' => 'Next',
    'LBL_ONLY_IMAGE_ATTACHMENT' => 'Hanya attachment bertipe image yang bisa ditambahkan',
    'LBL_TRAINING' => 'Community Forum',
    'ERR_MSSQL_DB_CONTEXT' => 'Berubah konteks database ke',
    'ERR_MSSQL_WARNING' => 'Peringatan',

    //Meta-Data framework
    'ERR_CANNOT_CREATE_METADATA_FILE' => 'Error: File [[file]] tidak ditemukan.  Tidak dapat membuatnya karena file HTML terkait tidak bisa ditemukan.',
    'ERR_CANNOT_FIND_MODULE' => 'Error: Module [module] tidak ada.',
    'LBL_ALT_ADDRESS' => 'Alamat Lainnya:',
    'ERR_SMARTY_UNEQUAL_RELATED_FIELD_PARAMETERS' => 'Error: Jumlah argumen yang tidak sama untuk \'key\' dan \'copy\' element di array displayParams.',

    /* MySugar Framework (for Home and Dashboard) */
    'LBL_DASHLET_CONFIGURE_GENERAL' => 'Umum',
    'LBL_DASHLET_CONFIGURE_FILTERS' => 'Filter',
    'LBL_DASHLET_CONFIGURE_MY_ITEMS_ONLY' => 'Hanya Item Saya',
    'LBL_DASHLET_CONFIGURE_TITLE' => 'Title',
    'LBL_DASHLET_CONFIGURE_DISPLAY_ROWS' => 'Menampilkan baris',

    // MySugar status strings
    'LBL_MAX_DASHLETS_REACHED' => 'Anda telah mencapai jumlah Dashlet SuiteCRM maksimum dari yang telah ditetapkan oleh administrator Anda. Hapus Dashlet SuiteCRM untuk menambahkan lebih banyak.',
    'LBL_ADDING_DASHLET' => 'Menambahkan SuiteCRM Dashlet...',
    'LBL_ADDED_DASHLET' => 'SuiteCRM Dashlet Ditambahkan',
    'LBL_REMOVE_DASHLET_CONFIRM' => 'Yakin ingin menghapus Dashlet SuiteCRM ini?',
    'LBL_REMOVING_DASHLET' => 'Menghapus SuiteCRM Dashlet...',
    'LBL_REMOVED_DASHLET' => 'SuiteCRM Dashlet removed',
    'LBL_MAX_DASHLET_COLUMNS' => "Maximum of %s columns can be displayed.",
    'LBL_RETRIEVING_XML_DATA' => "There was a problem retrieving the XML data:\n",

    // MySugar Menu Options

    'LBL_LOADING_PAGE' => 'Memuat halaman, mohon tunggu...',

    'LBL_RELOAD_PAGE' => 'Silakan <a href="javascript: window.lokasi hotel ini.reload()">reload window</a> untuk menggunakan ini alat yang berguna Dashlet.',
    'LBL_ADD_DASHLETS' => 'Tambah SuiteCRM Dashlets',
    'LBL_CLOSE_DASHLETS' => 'Close',
    'LBL_OPTIONS' => 'Options',
    'LBL_1_COLUMN' => '1 Kolom',
    'LBL_2_COLUMN' => '2 Kolom',
    'LBL_3_COLUMN' => '3 Kolom',
    'LBL_PAGE_NAME' => 'Nama Halaman',

    'LBL_SEARCH_RESULTS' => 'Search Results',
    'LBL_SEARCH_MODULES' => 'Modul',
    'LBL_SEARCH_TOOLS' => 'Alat',
    'LBL_SEARCH_HELP_TITLE' => 'Tips Pencarian',
    /* End MySugar Framework strings */

    'LBL_NO_IMAGE' => 'Tidak ada gambar',

    'LBL_MODULE' => 'Modul',

    //adding a label for address copy from left
    'LBL_COPY_ADDRESS_FROM_LEFT' => 'Salin alamat dari kiri:',
    'LBL_SAVE_AND_CONTINUE' => 'Simpan dan Lanjutkan',

    'LBL_SEARCH_HELP_TEXT' => '<p><br /><strong>Multiselect controls</strong></p><ul><li>Kik pada suatu nilai untuk mendapatkan atribut.</li><li>Ctrl-klik&nbsp;to&nbsp;untuk memilih lebih dari satu. Pengguna Mac gunakan CMD-click.</li><li>Untuk memilih semua nilai di antara 2 atributTo select all values between two attributes,&nbsp; Pertama-tama klik value yang pertama value&nbsp;lalu shift-click value terakhir.</li></ul><p><strong>Pencarian lanjutan & Pilihan Layout</strong><br><br>Menggunakan <b>Pencarian Tersimpan & pilihan Layout</b> , Anda bisa menyimpan sekumpulan parameter pencarian dan/atau mengkustomisasi layout List View dengan tujuan di kemudian hari dapat secara cepat mendapatkan hasil pencarian yang diinginkan. Anda bisa menyimpan kustomisasi dan layout pencarian dalam jumlah tak terbatas. Semua Pencarian Tersimpan akan muncul di list Pencarian Tersimpan, dengan Pencarian Tersimpan yang terakhir dipakai akan muncul di baris paling atas. <br><br>Untuk mengubah layout List View, gunakan kotak Hide Columns dan Display Columns untuk memilih field apa saja yang muncul di hasil pencarian. Contohnya Anda bisa menampilkan atau menyembunyikan rincian seperti nama, user yang ditugaskan, dan tim yang ditugaskan pada hasil pencarian. Untuk menambah sebuah kolom pada List View, pilihkan field dari list Hide Columns dan gunakan panah kiri untuk memindahkan ke Display Column List. Untuk memindahkan sebuah kolom dari List View, pilihlah dari list Display Columns dan gunakan panah kanan untuk memindahkannya ke list Hide Columns. <br><br>Jika Anda menyimpan pengaturan layout, Anda bisa menggunakannya lagi kapanpun untuk mendapatkan hasil pencarian dengan field yang diinginkan.<br><br>Untuk menyimpan dan memperbaharui pencarian dan/atau layout :<ol><li>Masukkan nama dari hasil pencarian di field <b>Save this search as</b> field dan klik <b>Save</b>.The name now displays in the Saved Searches list adjacent to the <b>Clear</b> button.</li><li>To view a saved search, pilihlah dari list Saved Searches. Hasil pencarian akan ditampilkan di List View.</li><li>Untuk memperbaharui nilai dari Pencarian Tersimpan, pilihlah dari list, masukkan kriteria pencarian yang baru dan/atau pilihan layout di Advanced Search, pilihlah dari list Saved Searches, klik <b>Delete</b> di sebelah <b>Modify Current Search</b>, lalu klik  <b>OK</b> untuk konfirmasi penghapusan.</li></ol>',

    //resource management
    'ERR_QUERY_LIMIT' => 'Error: Limit query $limit telah tercapai untuk $module module.',
    'ERROR_NOTIFY_OVERRIDE' => 'Error: ResourceObserver->notify() perlu ditimpa.',

    //tracker labels
    'ERR_MONITOR_FILE_MISSING' => 'Error: Tidak bisa membuat monitor karena file metadata kosong atau file tidak ada.',
    'ERR_MONITOR_NOT_CONFIGURED' => 'Error: Tidak ada monitor yang dibuat untuk nama yang diminta',
    'ERR_UNDEFINED_METRIC' => 'Error: Tidak bisa mengisi  value untuk undefined metric',
    'ERR_STORE_FILE_MISSING' => 'Error: Tidak bisa menemukan Store implementation file',

    'LBL_MONITOR_ID' => 'ID Monitor',
    'LBL_USER_ID' => 'ID Pengguna',
    'LBL_MODULE_NAME' => 'Nama Modul',
    'LBL_ITEM_ID' => 'Id item',
    'LBL_ITEM_SUMMARY' => 'Ringkasan Item',
    'LBL_ACTION' => 'Tindakan',
    'LBL_SESSION_ID' => 'Id sesi',
    'LBL_BREADCRUMBSTACK_CREATED' => 'BreadCrumbStack telah dibuat untuk Pengguna dengan ID {0}',
    'LBL_VISIBLE' => 'Rekam Terlihat',
    'LBL_DATE_LAST_ACTION' => 'Tanggal Terakhir Aktivitas',

    //jc:#12287 - For javascript validation messages
    'MSG_IS_NOT_BEFORE' => 'bukan sebelum',
    'MSG_IS_MORE_THAN' => 'lebih dari',
    'MSG_SHOULD_BE' => 'seharusnya',
    'MSG_OR_GREATER' => 'atau lebih besar',

    'LBL_LIST' => 'Daftar',
    'LBL_CREATE_BUG' => 'Membuat Bug',

    'LBL_OBJECT_IMAGE' => 'Gambar Obyek',
    //jchi #12300
    'LBL_MASSUPDATE_DATE' => 'Pilih Tanggal',

    'LBL_VALIDATE_RANGE' => 'tidak berada dalam range yang valid',
    'LBL_CHOOSE_START_AND_END_DATES' => 'Harap pilih rentang tanggal mulai dan akhir',
    'LBL_CHOOSE_START_AND_END_ENTRIES' => 'Harap pilih entri awal dan akhir',

    //jchi #  20776
    'LBL_DROPDOWN_LIST_ALL' => 'All',

    //Connector
    'ERR_CONNECTOR_FILL_BEANS_SIZE_MISMATCH' => 'Error: Jumlah array dari bean parameter tidak sesuai dengan jumlah array dari  hasilnya. ',
    'ERR_MISSING_MAPPING_ENTRY_FORM_MODULE' => 'Error: Mapping entry untuk modul tidak ditemukan.',
    'ERROR_UNABLE_TO_RETRIEVE_DATA' => 'Error: Tidak bisa mengakses data untuk konektor {0} .  Service mungkin sedang tidak bisa diakses atau konfigurasinya tidak valid. Pesan Error Connector : ({1}).',

    // fastcgi checks
    'LBL_FASTCGI_LOGGING' => 'Untuk USI pengalaman yang optimal, set fastcgi.logging ke 0 dalam php.ini file.',

    //Collection Field
    'LBL_COLLECTION_NAME' => 'Nama ',
    'LBL_COLLECTION_PRIMARY' => 'Primary',
    'ERROR_MISSING_COLLECTION_SELECTION' => 'Bidang wajib kosong',

    //MB -Fixed Bug #32812 -Max
    'LBL_ASSIGNED_TO_NAME' => 'Ditugaskan kepada',
    'LBL_DESCRIPTION' => 'Description',

    'LBL_YESTERDAY' => 'kemarin',
    'LBL_TODAY' => 'hari ini',
    'LBL_TOMORROW' => 'besok',
    'LBL_NEXT_WEEK' => 'minggu depan',
    'LBL_NEXT_MONDAY' => 'senin depan',
    'LBL_NEXT_FRIDAY' => 'jumat depan',
    'LBL_TWO_WEEKS' => 'dua minggu',
    'LBL_NEXT_MONTH' => 'bulan depan',
    'LBL_FIRST_DAY_OF_NEXT_MONTH' => 'hari pertama bulan depan',
    'LBL_THREE_MONTHS' => 'tiga bulan',
    'LBL_SIXMONTHS' => 'enam bulan',
    'LBL_NEXT_YEAR' => 'tahun depan',

    //Datetimecombo fields
    'LBL_HOURS' => 'Hours',
    'LBL_MINUTES' => 'Minutes',
    'LBL_MERIDIEM' => 'Meridiem',
    'LBL_DATE' => 'Tanggal',
    'LBL_DASHLET_CONFIGURE_AUTOREFRESH' => 'Refresh-Otomatis',

    'LBL_DURATION_DAY' => 'hari',
    'LBL_DURATION_HOUR' => 'Jam',
    'LBL_DURATION_MINUTE' => 'menit',
    'LBL_DURATION_DAYS' => 'hari',
    'LBL_DURATION_HOURS' => 'Durasi Jam',
    'LBL_DURATION_MINUTES' => 'Durasi Menit',

    //Calendar widget labels
    'LBL_CHOOSE_MONTH' => 'Pilih bulan',
    'LBL_ENTER_YEAR' => 'Masukkan Tahun',
    'LBL_ENTER_VALID_YEAR' => 'Harap masukkan tahun yang valid',

    //File write error label
    'ERR_FILE_WRITE' => 'Kesalahan: tidak bisa menulis berkas {0}. Silakan periksa sistem dan izin server web.',
    'ERR_FILE_NOT_FOUND' => 'Kesalahan: Tidak dapat memuat berkas {0}. Silakan periksa sistem dan izin server web.',

    'LBL_AND' => 'E',

    // File fields
    'LBL_SEARCH_EXTERNAL_API' => 'Berkas pada Sumber Eksternal',
    'LBL_EXTERNAL_SECURITY_LEVEL' => 'Keamanan',

    //IMPORT SAMPLE TEXT
    'LBL_IMPORT_SAMPLE_FILE_TEXT' => '
"Ini adalah contoh berkas impor yang menyediakan contoh diharapkan isi berkas yang siap untuk di impor."
"Berkas comma-delimited .berkas csv, menggunakan tanda kutip ganda seperti lapangan kualifikasi."

"Judul baris paling atas baris dalam berkas dan berisi label bidang seperti yang kamu lihat dari dalam aplikasi mereka."
"Label-label ini digunakan untuk pemetaan data dalam berkas untuk bidang dalam aplikasi."

"Catatan: nama database juga bisa digunakan pada baris header. Hal ini berguna ketika kamu menggunakan phpMyAdmin atau alat database lain untuk memberikan daftar ekspor data yang impor."
"Agar kolom tidak kritis sebagai proses impor pertandingan data ke dalam bidang yang sesuai berdasarkan baris header."


"Untuk menggunakan berkas ini sebagai pola, lakukan yang berikut:"
"1. Menghapus sampel baris data"
"2. Menghapus bantuan teks yang kamu baca sekarang"
"3. Masukan data kamu sendiri sesuai baris dan kolom"
"4. Simpan berkas ke lokasi yang dikenal pada sistem kamu"
"5. Klik pada opsi Impor dari menu tindakan dalam aplikasi dan pilih berkas untuk mengunggah"   ',
    //define labels to be used for overriding local values during import/export

    'LBL_NOTIFICATIONS_NONE' => 'Tidak ada pemberitahuan terkini',
    'ERR_NOTIFICATIONS_MARK_AS_READ' => 'Error while trying to mark notifications as read',
    'ERR_FIELD_LOGIC_BACKEND_CALCULATION' => 'Error while trying to get the value',
    'LBL_ALT_SORT_DESC' => 'Diurutkan Descending',
    'LBL_ALT_SORT_ASC' => 'Sorted Ascending',
    'LBL_ALT_SORT' => 'Sort',
    'LBL_ALT_SHOW_OPTIONS' => 'Tampilkan Opsi',
    'LBL_ALT_HIDE_OPTIONS' => 'Sembunyikan Pilihan',
    'LBL_ALT_MOVE_COLUMN_LEFT' => 'Pindahkan catatan yang dipilih ke daftar di sebelah kiri',
    'LBL_ALT_MOVE_COLUMN_RIGHT' => 'Pindahkan catatan yang dipilih ke daftar di sebelah kanan',
    'LBL_ALT_MOVE_COLUMN_UP' => 'Pindahkan catatan yang dipilih ke dalam urutan daftar yang ditampilkan',
    'LBL_ALT_MOVE_COLUMN_DOWN' => 'Pindahkan catatan yang dipilih ke bawah dalam urutan daftar yang ditampilkan',
    'LBL_ALT_INFO' => 'Informasi',
    'MSG_DUPLICATE' => 'Catatan {0} yang akan Anda buat mungkin merupakan salinan dari rekaman {0} yang sudah ada. {1} catatan berisi nama yang mirip tercantum di bawah ini.<br>Klik Buat {1} untuk terus membuat {0} baru ini, atau pilih yang ada {0} yang tercantum di bawah ini.',
    'MSG_SHOW_DUPLICATES' => 'Catatan {0} yang akan Anda buat mungkin merupakan salinan dari rekaman {0} yang sudah ada. {1} catatan berisi nama yang mirip tercantum di bawah ini. Klik Simpan untuk terus membuat {0} baru ini, atau klik Batal untuk kembali ke modul tanpa membuat {0}.',
    'LBL_EMAIL_TITLE' => 'alamat surel',
    'LBL_EMAIL_OPT_TITLE' => 'memilih alamat email',
    'LBL_EMAIL_INV_TITLE' => 'alamat email salah',
    'LBL_EMAIL_PRIM_TITLE' => 'Membuat alamat Email utama',
    'LBL_SELECT_ALL_TITLE' => 'Pilih Semua',
    'LBL_SELECT_THIS_ROW_TITLE' => 'Pilih baris ini',

    //for upload errors
    'UPLOAD_ERROR_TEXT' => 'KESALAHAN: Ada kesalahan saat mengunggah. Kesalahan kode: {0} - {1}',
    'UPLOAD_ERROR_TEXT_SIZEINFO' => 'KESALAHAN: Terjadi kesalahan saat mengunggah. Kode kesalahan: {0} - {1}. Unggah_ukuran maks adalah {2} ',
    'UPLOAD_ERROR_HOME_TEXT' => 'KESALAHAN: Terjadi kesalahan saat mengunggah, menghubungi pengelola untuk mendapatkan bantuan.',
    'UPLOAD_MAXIMUM_EXCEEDED' => 'Ukuran pengunggahan ({0} byte) Melebihi Diizinkan Maksimum: {1} byte',
    'UPLOAD_REQUEST_ERROR' => 'Telah terjadi kesalahan Harap segarkan halaman Anda dan coba lagi.',

    //508 used Access Keys
    'LBL_EDIT_BUTTON_KEY' => 'E',
    'LBL_EDIT_BUTTON_LABEL' => 'Sunting',
    'LBL_EDIT_BUTTON_TITLE' => 'Sunting',
    'LBL_DUPLICATE_BUTTON_KEY' => 'U',
    'LBL_DUPLICATE_BUTTON_LABEL' => 'Duplicate',
    'LBL_DUPLICATE_BUTTON_TITLE' => 'Duplicate',
    'LBL_DISABLE_USER_2FA' => 'Disable 2FA',
    'LBL_DELETE_BUTTON_KEY' => 'D',
    'LBL_DELETE_BUTTON_LABEL' => 'Delete',
    'LBL_DELETE_BUTTON_TITLE' => 'Delete',
    'LBL_BULK_ACTION_BUTTON_LABEL' => 'Tindakan Massal',
    'LBL_BULK_ACTION_BUTTON_LABEL_MOBILE' => 'Aksi',
    'LBL_TOO_FEW_SELECTED' => 'Jumlah catatan yang dipilih tidak valid. Pilih minimum {min} catatan.',
    'LBL_TOO_MANY_SELECTED' => 'Jumlah catatan yang dipilih tidak valid. Pilih maksimum {max} catatan.',
    'LBL_SELECT_ALL_NOT_ALLOWED' => 'Pemilihan semua catatan tidak tersedia untuk tindakan ini. Pilih catatan individual.',
    'LBL_MISSING_HANDLER_DATA' => 'Kesalahan tidak terduga. Data penanganan tindakan massal hilang dari respons',
    'LBL_MISSING_HANDLER' => 'Kesalahan tidak terduga. Tidak ada penanganan yang ditetapkan untuk tindakan massal terpilih',
    'LBL_MISSING_HANDLER_DATA_ROUTE' => 'Kesalahan tidak terduga. Rute tindakan massal tidak ditemukan',
    'LBL_ACTION_ERROR' => 'Kesalahan tidak terduga saat melakukan tindakan',
    'LBL_BULK_ACTION_ERROR' => 'Kesalahan tidak terduga saat melakukan Tindakan Massal',
    'LBL_BULK_ACTION_DELETE_SUCCESS' => 'Catatan berhasil dihapus',
    'LBL_BULK_ACTION_MASS_UPDATE_CONFIRMATION' => 'Apakah Anda yakin ingin memperbarui catatan yang dipilih?',
    'LBL_BULK_ACTION_MASS_UPDATE_SUCCESS' => 'Semua catatan berhasil diperbarui',
    'LBL_BULK_ACTION_MASS_UPDATE_PARTIAL_SUCCESS' => 'Keberhasilan parsial. Beberapa catatan tidak diperbarui. periksa log',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_FIELDS' => 'Tidak ada bidang untuk diperbarui',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_RECORDS' => 'Tidak ada catatan untuk diperbarui',
    'LBL_BULK_ACTION_MASS_UPDATE_NO_ACLS' => 'Hak Istimewa Tidak Cukup, Penyimpanan tidak diizinkan',
    'LBL_UNEXPECTED_ERROR' => 'Kesalahan tidak terduga. Tidak dapat menyelesaikan tindakan.',
    'LBL_RECORD_DELETE_SUCCESS' => 'Catatan berhasil dihapus',
    'LBL_RECORD_DELETE_ALL_SUCCESS' => 'Records deleted successfully',
    'LBL_RECORD_SNOOZE_SUCCESS' => 'Notification Snoozed',
    'LBL_ERROR_SAVING' => 'Kesalahan terjadi saat menyimpan catatan',
    'LBL_SAVE_BUTTON_KEY' => 'S',
    'LBL_SAVE_BUTTON_LABEL' => 'Save',
    'LBL_NEW_EM_SURVEY' => 'New Survey Email',
    'LBL_NEW_EM_TRANSACTIONAL' => 'New Transactional Email',
    'LBL_NEW_EM_MARKETING' => 'New Marketing Email',
    'LBL_NEW_SURVEY' => 'New Survey',
    'LBL_WEB_TO_LEAD' => 'New Web to Person Form',
    'LBL_TYPE' => 'Type',
    'LBL_DATE_START' => 'Date Start',
    'LBL_SEND_DATE' => 'Send Date',
    'LBL_SCHEDULE_BUTTON_LABEL' => 'Susunan acara',
    'LBL_UNABLE_TO_UNSCHEDULE' => 'Unable to unschedule as not scheduled',
    'LBL_SAVE_BUTTON_TITLE' => 'Save',
    'LBL_SAVE_CONTINUE_LABEL' => 'Save And Continue',
    'LBL_CANCEL_BUTTON_KEY' => 'X',
    'LBL_CANCEL_BUTTON_LABEL' => 'Batal',
    'LBL_CANCEL_BUTTON_TITLE' => 'Batal',
    'LBL_FIRST_INPUT_EDIT_VIEW_KEY' => '7',
    'LBL_ADV_SEARCH_LNK_KEY' => '8',
    'LBL_FIRST_INPUT_SEARCH_KEY' => '9',

    'ANNUAL_REVENUE_BY_ACCOUNTS' => 'Pendapatan Tahunan Berdasarkan Akun',
    'PIPELINE_BY_SALES_STAGE' => 'Pipeline By Sales Stage',
    'LEADS_BY_SOURCE' => 'Prospek Berdasarkan Sumber',
    'LEADS_BY_STATUS' => 'Prospek Berdasarkan Status',
    'ACCOUNT_TYPES_PER_MONTH' => 'Akun Baru berdasarkan Bulan',

    'ERR_CONNECTOR_NOT_ARRAY' => 'konektor array {0} telah ditetapkan salah atau kosong dan tidak bisa digunakan.',
    'ERR_SUHOSIN' => 'Aliran pengunggahan diblokir oleh Suhosin, mohon tambahkan &quot;upload&quot; ke suhosin.pelaksana.termasuk.daftar putih (Lihat suitecrm.log untuk informasi lebih lanjut)',
    'ERR_BAD_RESPONSE_FROM_SERVER' => 'Tanggapan buruk dari server',
    'LBL_ACCOUNT_PRODUCT_QUOTE_LINK' => 'Kutipan',
    'LBL_ACCOUNT_PRODUCT_SALE_PRICE' => 'Harga Jual',
    'LBL_EMAIL_CHECK_INTERVAL_DOM' => array(
        '-1' => 'Secara Manual',
        '5' => 'Setiap 5 menit',
        '15' => 'Setiap 15 menit',
        '30' => 'Setiap 30 menit',
        '60' => 'Setiap jam',
    ),

    'ERR_A_REMINDER_IS_EMPTY_OR_INCORRECT' => 'Pengingat kosong atau salah.',
    'ERR_REMINDER_IS_NOT_SET_POPUP_OR_EMAIL' => 'Pengingat tidak diatur untuk popup atau email.',
    'ERR_NO_INVITEES_FOR_REMINDER' => 'Tidak ada undangan untuk pengingat.',
    'LBL_DELETE_REMINDER_CONFIRM' => 'Pengingat tidak termasuk setiap undangan yang hadir, apakah kamu ingin menghapus pengingat?',
    'LBL_DELETE_REMINDER' => 'Hapus Pengingat',
    'LBL_OK' => 'Baik',
    'LBL_PROCEED' => 'Lanjutkan',

    'LBL_COLUMNS_FILTER_HEADER_TITLE' => 'Pilih kolom',
    'LBL_COLUMN_CHOOSER' => 'Kolom Chooser',
    'LBL_SAVE_CHANGES_BUTTON_TITLE' => 'Simpan perubahan',
    'LBL_DISPLAYED' => 'Ditampilkan',
    'LBL_HIDDEN' => 'Tersembunyi',
    'ERR_EMPTY_COLUMNS_LIST' => 'Setidaknya, satu elemen dibutuhkan',

    'LBL_FILTER_HEADER_TITLE' => 'Menyaring',

    'LBL_CATEGORY' => 'Category',
    'LBL_LIST_CATEGORY' => 'Category',
    'ERR_FACTOR_TPL_INVALID' => 'Faktor Otentikasi pesan yang tidak sah, silahkan hubungi pengelola kamu.',
    'LBL_SUBTHEMES' => 'Gaya',
    'LBL_SUBTHEME_OPTIONS_DAWN' => 'Fajar',
    'LBL_SUBTHEME_OPTIONS_DAY' => 'Hari',
    'LBL_SUBTHEME_OPTIONS_DUSK' => 'Senja',
    'LBL_SUBTHEME_OPTIONS_NIGHT' => 'Malam',
    'LBL_SUBTHEME_OPTIONS_NOON' => 'Siang',

    'LBL_CONFIRM_DISREGARD_DRAFT_TITLE' => 'Abaikan draf',
    'LBL_CONFIRM_DISREGARD_DRAFT_BODY' => 'Operasi ini akan menghapus email, apakah anda ingin melanjutkan?',
    'LBL_CONFIRM_DISREGARD_EMAIL_TITLE' => 'Keluar dari dialog penulisan',
    'LBL_CONFIRM_DISREGARD_EMAIL_BODY' => 'Dengan meninggalkan dialog penulisan semua informasi yang diisikan akan hilang, apakah Anda ingin melanjutkan?',
    'LBL_CONFIRM_APPLY_EMAIL_TEMPLATE_TITLE' => 'Terapkan Template Email',
    'LBL_CONFIRM_APPLY_EMAIL_TEMPLATE_BODY' => 'Operasi ini akan menimpa Tubuh email dan Subjek bidang, apakah anda ingin melanjutkan?',

    'LBL_CONFIRM_OPT_IN_TITLE' => 'Dikonfirmasi Keikutsertaan',
    'LBL_OPT_IN_TITLE' => 'Keikutsertaan',
    'LBL_CONFIRM_OPT_IN_DATE' => 'Pilihan Sudah Dikonfirmasi di Tanggal',
    'LBL_CONFIRM_OPT_IN_SENT_DATE' => 'Pilihan Sudah Dikonfirmasi di Tanggal Terkirim',
    'LBL_CONFIRM_OPT_IN_FAIL_DATE' => 'Pilihan Terkonfirmasi pada Tanggal Yang Gagal',
    'LBL_CONFIRM_OPT_IN_TOKEN' => 'Konfirmasi Token Keikutsertaan',
    'ERR_OPT_IN_TPL_NOT_SET' => 'Pilihan di pola Email belum terkonfigurasi. Silakan atur di pengaturan email.',
    'ERR_OPT_IN_RELATION_INCORRECT' => 'Pilihan diperlukan untuk menghubungkan email ke Akun/Kontak/Petunjuk/Target',

    'LBL_SECURITYGROUP_NONINHERITABLE' => 'Grup yang Tidak Berhak',
    'LBL_PRIMARY_GROUP' => "Grup Utama",

    // footer
    'LBL_SUITE_TOP' => 'Kembali ke atas',
    'LBL_SUITE_SUPERCHARGED' => 'Supercharged oleh SuiteCRM',
    'LBL_SUITE_POWERED_BY' => 'Didukung oleh SugarCRM',
    'LBL_SUITE_DESC1' => 'SuiteCRM yang telah ditulis dan disusun oleh <a href="https://salesagility.com">SalesAgility</a>. Program ini disediakan sebagaimana adanya, tanpa jaminan. Berlisensi di bawah AGPLv3.',
    'LBL_SUITE_DESC2' => 'Program ini adalah perangkat lunak bebas: anda dapat menyebarluaskannya dan/atau memodifikasinya di bawah ketentuan lisensi umum GNU affero publik versi 3 seperti yang diterbitkan oleh dasar perangkat lunak bebas, termasuk tambahan izin yang diatur dalam kode sumber header.',
    'LBL_SUITE_DESC3' => 'SuiteCRM adalah merek dagang SalesAgility Ltd. Semua nama perusahaan dan produk lain mungkin merupakan merek dagang dari masing-masing perusahaan yang terkait dengannya.',
    'LBL_GENERATE_PASSWORD_BUTTON_TITLE' => 'Setel Ulang Kata Sandi',
    'LBL_SEND_CONFIRM_OPT_IN_EMAIL' => 'Kirim Pilihan Konfirmasi ke Email',
    'LBL_CONFIRM_OPT_IN_ONLY_FOR_PERSON' => 'Konfirmasi Pilihan di Surel dikirim hanya untuk Akun/Kontak/Petunjuk/Prospek',
    'LBL_CONFIRM_OPT_IN_IS_DISABLED' => 'Pengiriman Konfirmasi Pilihan di Surel dinonaktifkan, aktifkan Konfirmasi Pilihan di Setelan Surel atau hubungi pengelola anda.',
    'LBL_CONTACT_HAS_NO_PRIMARY_EMAIL' => 'Pengiriman Konfirmasi Pilihan di Surel tidak memungkinkan karena Kontak bukan merupakan Alamat Surel Utama',
    'LBL_CONFIRM_EMAIL_SENDING_FAILED' => 'Pengiriman Konfirmasi Pilihan di Surel gagal',
    'LBL_CONFIRM_EMAIL_SENT' => 'Konfrimasi Pilihan di Surel berhasil terkirim',

    'LBL_SEND_TEST_EMAIL' => 'Send Test Email',
    'LBL_SEND_TEST_EMAIL_DESC' => 'Please select the Email Addresses / User(s) and/or Target List(s) to send to.',
    'LBL_EMAIL_SENT_SUCCESSFULLY' => 'Email sent successfully',
    'LBL_PROSPECT_LIST_NAME' => 'Target Lists',

    //List View Column Selector Modal
    'LBL_COLUMN_SELECTOR_DISPLAYED_COLS' => 'DITAMPILKAN',
    'LBL_COLUMN_SELECTOR_HIDDEN_COLS' => 'DISEMBUNYIKAN',
    'LBL_COLUMN_SELECTOR_CLOSE_BUTTON' => 'Close',
    'LBL_COLUMN_SELECTOR_SAVE_BUTTON' => 'Simpan Perubahan',
    'LBL_COLUMN_SELECTOR_MODAL_TITLE' => 'Pilih Kolom',

    // Two-Factor Authentication
    'LBL_ENTER_AUTH_APP_2FA_CODE' => 'Please enter the verification code from your authenticator app',
    'LBL_ENABLE_2FA_LABEL' => 'Enable Two-Factor Authentication',
    'LBL_BACKUP_CODES' => 'Recovery/Backup Codes',
    'LBL_BACKUP_CODES_INFO' => 'Backup codes are one time passcodes to use when you are unable to verify via your Authenticator app.',
    'LBL_BACKUP_CODES_WARN' => ' WARNING: These codes are only generated once. Please copy BEFORE verifying as these will not be displayed again.',
    'LBL_PROBLEMS_GENERATING_CODE' => 'Problems generating the code?',
    'LBL_BACKUP_CODES_FALLBACK_INSTRUCTIONS' => 'Use one of the backup codes (it expires after being used)',
    'LBL_OTP_SETUP' => 'Use a OTP (one time password) authenticator on your mobile or computer to enable 2FA (Two-Factor Authentication)',
    'LBL_QR_CODE_HELP' => "If you haven't already, please download an Authenticator Application (such as FreeOTP or Google Authenticator). Use that app to scan the QR code.",
    'LBL_USE_SECRET' => "Unable to scan the QR Code?",
    'LBL_USE_SECRET_DESC' => "If you are unable to scan the QR code, please enter the secret below manually into your authenticator app.",
    'LBL_HIDE_SECRET' => "Hide TOTP Secret",
    'LBL_2FA_LOGIN_CANCEL' => 'Two Factor Authentication cancelled',

    'LBL_FACTOR_AUTH_DISABLE' => 'Two Factor Authentication was Disabled',
    'LBL_FACTOR_AUTH_SUCCESS' => 'Two Factor Authentication was Successful',
    'LBL_FACTOR_AUTH_FAIL' => "Two Factor Authentication failed. Try again.",

    'LBL_VERIFY_2FA' => 'Verify Code',
    'LBL_TWO_FACTOR_AUTH' => 'Two Factor Authentication',
    'LBL_TWO_FACTOR_AUTH_APP_METHOD' => 'Authenticator app',
    'LBL_TWO_FACTOR_AUTH_APP_METHOD_DESCRIPTION' => 'Use an authentication app to generate 2-factor authentication codes when prompted',
    'LBL_ENABLE' => 'Enable',
    'LBL_ENABLED' => 'Enabled',
    'LBL_DISABLE' => 'Disable',
    'LBL_GENERATED' => 'Generated',
    'LBL_REGENERATE_CODES' => 'Regenerate',
    'LBL_REGENERATED_BACKUP_CODES' => 'Backup Codes Regenerated'

);

$app_list_strings['moduleList']['Library'] = 'Perpustakaan';
$app_list_strings['moduleList']['EmailAddresses'] = 'Alamat Surel';
$app_list_strings['project_priority_default'] = 'Medium';
$app_list_strings['project_priority_options'] = array(
    'High' => 'High',
    'Medium' => 'Medium',
    'Low' => 'Low',
);

//GDPR lawful basis options
$app_list_strings['lawful_basis_dom'] = array(
    '' => '',
    'consent' => 'Persetujuan',
    'contract' => 'Kontrak',
    'legal_obligation' => 'Kewajiban hukum',
    'protection_of_interest' => 'Perlindungan terhadap kepentingan',
    'public_interest' => 'Kepentingan umum',
    'legitimate_interest' => 'Kepentingan yang sah',
    'withdrawn' => 'Dicabut',
);
//End GDPR lawful basis options

//GDPR lawful basis source options
$app_list_strings['lawful_basis_source_dom'] = array(
    '' => '',
    'website' => 'Situs',
    'phone' => 'Phone',
    'given_to_user' => 'Diberikan kepada Pengguna',
    'email' => 'Email',
    'third_party' => 'Pihak Ketiga',
);
//End GDPR lawful basis source options

$app_list_strings['moduleList']['KBDocuments'] = 'Berbasis Pengetahuan';

$app_list_strings['countries_dom'] = array(
    '' => '',
    'ABU DHABI' => 'ABU DHABI',
    'ADEN' => 'ADEN',
    'AFGHANISTAN' => 'AFGHANISTAN',
    'ALBANIA' => 'ALBANIA',
    'ALGERIA' => 'ALJAZAIR',
    'AMERICAN SAMOA' => 'AMERICAN SAMOA',
    'ANDORRA' => 'ANDORRA',
    'ANGOLA' => 'ANGOLA',
    'ANTARCTICA' => 'ANTARCTICA',
    'ANTIGUA' => 'ANTIGUA',
    'ARGENTINA' => 'ARGENTINA',
    'ARMENIA' => 'ARMENIA',
    'ARUBA' => 'ARUBA',
    'AUSTRALIA' => 'AUSTRALIA',
    'AUSTRIA' => 'AUSTRIA',
    'AZERBAIJAN' => 'AZERBAIJAN',
    'BAHAMAS' => 'BAHAMAS',
    'BAHRAIN' => 'BAHRAIN',
    'BANGLADESH' => 'BANGLADESH',
    'BARBADOS' => 'BARBADOS',
    'BELARUS' => 'BELARUS',
    'BELGIUM' => 'BELGIUM',
    'BELIZE' => 'BELIZE',
    'BENIN' => 'BENIN',
    'BERMUDA' => 'BERMUDA',
    'BHUTAN' => 'BHUTAN',
    'BOLIVIA' => 'BOLIVIA',
    'BOSNIA' => 'BOSNIA',
    'BOTSWANA' => 'BOTSWANA',
    'BOUVET ISLAND' => 'BOUVET ISLAND',
    'BRAZIL' => 'BRAZIL',
    'BRITISH ANTARCTICA TERRITORY' => 'INGGRIS ANTARTIKA WILAYAH',
    'BRITISH INDIAN OCEAN TERRITORY' => 'BRITISH INDIAN OCEAN TERRITORY',
    'BRITISH VIRGIN ISLANDS' => 'KEPULAUAN VIRGIN INGGRIS',
    'BRITISH WEST INDIES' => 'BRITISH INDIES BARAT',
    'BRUNEI' => 'BRUNEI',
    'BULGARIA' => 'BULGARIA',
    'BURKINA FASO' => 'BURKINA FASO',
    'BURUNDI' => 'BURUNDI',
    'CAMBODIA' => 'CAMBODIA',
    'CAMEROON' => 'CAMEROON',
    'CANADA' => 'CANADA',
    'CANAL ZONE' => 'DAERAH TERUSAN',
    'CANARY ISLAND' => 'PULAU CANARY',
    'CAPE VERDI ISLANDS' => 'PULAU VERDE CAPE',
    'CAYMAN ISLANDS' => 'PULAU CAYMAN',
    'CHAD' => 'CHAD',
    'CHANNEL ISLAND UK' => 'PULAU CHANNEL Inggris',
    'CHILE' => 'CHILE',
    'CHINA' => 'CHINA',
    'CHRISTMAS ISLAND' => 'PULAU NATAL',
    'COCOS (KEELING) ISLAND' => 'COCOS (KEELING) PULAU',
    'COLOMBIA' => 'COLOMBIA',
    'COMORO ISLANDS' => 'PULAU COMORO',
    'CONGO' => 'CONGO',
    'CONGO KINSHASA' => 'CONGO KINSHASA',
    'COOK ISLANDS' => 'PULAU COOK',
    'COSTA RICA' => 'COSTA RICA',
    'CROATIA' => 'CROATIA',
    'CUBA' => 'CUBA',
    'CURACAO' => 'CURACAO',
    'CYPRUS' => 'SIPRUS',
    'CZECH REPUBLIC' => 'CZECH REPUBLIC',
    'DAHOMEY' => 'DAHOMEY',
    'DENMARK' => 'DENMARK',
    'DJIBOUTI' => 'DJIBOUTI',
    'DOMINICA' => 'DOMINICA',
    'DOMINICAN REPUBLIC' => 'DOMINICAN REPUBLIC',
    'DUBAI' => 'DUBAI',
    'ECUADOR' => 'ECUADOR',
    'EGYPT' => 'MESIR',
    'EL SALVADOR' => 'EL SALVADOR',
    'EQUATORIAL GUINEA' => 'EQUATORIAL GUINEA',
    'ESTONIA' => 'ESTONIA',
    'ETHIOPIA' => 'ETHIOPIA',
    'FAEROE ISLANDS' => 'KEPULAUAN FAEROE',
    'FALKLAND ISLANDS' => 'PULAU FALKLAND',
    'FIJI' => 'FIJI',
    'FINLAND' => 'FINLAND',
    'FRANCE' => 'PERANCIS',
    'FRENCH GUIANA' => 'GUYANA PERANCIS',
    'FRENCH POLYNESIA' => 'POLINESIA PERANCIS',
    'GABON' => 'GABON',
    'GAMBIA' => 'GAMBIA',
    'GEORGIA' => 'GEORGIA',
    'GERMANY' => 'JERMAN',
    'GHANA' => 'GHANA',
    'GIBRALTAR' => 'GIBRALTAR',
    'GREECE' => 'GREECE',
    'GREENLAND' => 'GREENLAND',
    'GUADELOUPE' => 'GUADELOUPE',
    'GUAM' => 'GUAM',
    'GUATEMALA' => 'GUATEMALA',
    'GUINEA' => 'GUINEA',
    'GUYANA' => 'GUYANA',
    'HAITI' => 'HAITI',
    'HONDURAS' => 'HONDURAS',
    'HONG KONG' => 'HONG KONG',
    'HUNGARY' => 'HONGARIA',
    'ICELAND' => 'ISLANDIA',
    'IFNI' => 'IFNI',
    'INDIA' => 'INDIA',
    'INDONESIA' => 'INDONESIA',
    'IRAN' => 'IRAN',
    'IRAQ' => 'IRAQ',
    'IRELAND' => 'IRELAND',
    'ISRAEL' => 'ISRAEL',
    'ITALY' => 'ITALY',
    'IVORY COAST' => 'PANTAI GADING',
    'JAMAICA' => 'JAMAICA',
    'JAPAN' => 'JEPANG',
    'JORDAN' => 'JORDAN',
    'KAZAKHSTAN' => 'KAZAKHSTAN',
    'KENYA' => 'KENYA',
    'KOREA' => 'KOREA',
    'KOREA, SOUTH' => 'KOREA SELATAN',
    'KUWAIT' => 'KUWAIT',
    'KYRGYZSTAN' => 'Kirgizstan',
    'LAOS' => 'LAOS',
    'LATVIA' => 'LATVIA',
    'LEBANON' => 'LIBANON',
    'LEEWARD ISLANDS' => 'PULAU LEEWARD',
    'LESOTHO' => 'LESOTHO',
    'LIBYA' => 'LIBYA',
    'LIECHTENSTEIN' => 'LIECHTENSTEIN',
    'LITHUANIA' => 'LITHUANIA',
    'LUXEMBOURG' => 'LUXEMBOURG',
    'MACAO' => 'MACAO',
    'MACEDONIA' => 'MACEDONIA',
    'MADAGASCAR' => 'MADAGASKAR',
    'MALAWI' => 'MALAWI',
    'MALAYSIA' => 'MALAYSIA',
    'MALDIVES' => 'MALADEWA',
    'MALI' => 'MALI',
    'MALTA' => 'MALTA',
    'MARTINIQUE' => 'MARTINIK',
    'MAURITANIA' => 'MAURITANIA',
    'MAURITIUS' => 'MAURITIUS',
    'MELANESIA' => 'MELANESIA',
    'MEXICO' => 'MEKSIKO',
    'MOLDOVIA' => 'MOLDOVIA',
    'MONACO' => 'MONACO',
    'MONGOLIA' => 'MONGOLIA',
    'MOROCCO' => 'MAROKO',
    'MOZAMBIQUE' => 'MOZAMBIK',
    'MYANAMAR' => 'MYANMAR',
    'NAMIBIA' => 'NAMIBIA',
    'NEPAL' => 'NEPAL',
    'NETHERLANDS' => 'BELANDA',
    'NETHERLANDS ANTILLES' => 'ANTILLEN BELANDA',
    'NETHERLANDS ANTILLES NEUTRAL ZONE' => 'BELANDA ANTILLES ZONA NEUTRAL',
    'NEW CALADONIA' => 'CALADONIA BARU',
    'NEW HEBRIDES' => 'HEBRIDES BARU',
    'NEW ZEALAND' => 'SELANDIA BARU',
    'NICARAGUA' => 'NICARAGUA',
    'NIGER' => 'NIGER',
    'NIGERIA' => 'NIGERIA',
    'NORFOLK ISLAND' => 'PULAU NORFOLK',
    'NORWAY' => 'NORWAYGIA',
    'OMAN' => 'OMAN',
    'OTHER' => 'OTHER',
    'PACIFIC ISLAND' => 'KEPULAUAN PASIFIK',
    'PAKISTAN' => 'PAKISTAN',
    'PANAMA' => 'PANAMA',
    'PAPUA NEW GUINEA' => 'PAPUA NUGINI',
    'PARAGUAY' => 'PARAGUAY',
    'PERU' => 'PERU',
    'PHILIPPINES' => 'PHILIPPINA',
    'POLAND' => 'POLANDIA',
    'PORTUGAL' => 'PORTUGAL',
    'PORTUGUESE TIMOR' => 'TIMOR TIMUR',
    'PUERTO RICO' => 'PUERTO RICO',
    'QATAR' => 'QATAR',
    'REPUBLIC OF BELARUS' => 'REPUBLIK BELARUS',
    'REPUBLIC OF SOUTH AFRICA' => 'REPUBLIK AFRIKA SELATAN',
    'REUNION' => 'REUNION',
    'ROMANIA' => 'ROMANIA',
    'RUSSIA' => 'RUSSIA',
    'RWANDA' => 'RWANDA',
    'RYUKYU ISLANDS' => 'PULAU RYUKYU',
    'SABAH' => 'SABAH',
    'SAN MARINO' => 'SAN MARINO',
    'SAUDI ARABIA' => 'ARAB SAUDI',
    'SENEGAL' => 'SENEGAL',
    'SERBIA' => 'SERBIA',
    'SEYCHELLES' => 'SEYCHELLES',
    'SIERRA LEONE' => 'SIERRA LEONE',
    'SINGAPORE' => 'SINGAPORE',
    'SLOVAKIA' => 'SLOVAKIA',
    'SLOVENIA' => 'SLOVENIA',
    'SOMALILIAND' => 'SOMALILIAND',
    'SOUTH AFRICA' => 'SOUTH AFRICA',
    'SOUTH YEMEN' => 'SOUTH YEMEN',
    'SPAIN' => 'SPANYOL',
    'SPANISH SAHARA' => 'SPANISH SAHARA',
    'SRI LANKA' => 'SRI LANKA',
    'ST. KITTS AND NEVIS' => 'ST. KITTS AND NEVIS',
    'ST. LUCIA' => 'ST. LUCIA',
    'SUDAN' => 'SUDAN',
    'SURINAM' => 'SURINAM',
    'SW AFRICA' => 'AFRIKA BARAT DAYA',
    'SWAZILAND' => 'SWAZILAND',
    'SWEDEN' => 'SWEDIA',
    'SWITZERLAND' => 'SWITZERLAND',
    'SYRIA' => 'SYRIA',
    'TAIWAN' => 'TAIWAN',
    'TAJIKISTAN' => 'TAJIKISTAN',
    'TANZANIA' => 'TANZANIA',
    'THAILAND' => 'THAILAND',
    'TONGA' => 'TONGA',
    'TRINIDAD' => 'TRINIDAD',
    'TUNISIA' => 'TUNISIA',
    'TURKEY' => 'TURKI',
    'UGANDA' => 'UGANDA',
    'UKRAINE' => 'UKRAINA',
    'UNITED ARAB EMIRATES' => 'UNI EMIRAT ARAB',
    'UNITED KINGDOM' => 'INGGRIS',
    'URUGUAY' => 'URUGUAY',
    'US PACIFIC ISLAND' => 'PULAU PASIFIK AS',
    'US VIRGIN ISLANDS' => 'PULAU VIRGIN AS',
    'USA' => 'AMERIKA SERIKAT',
    'UZBEKISTAN' => 'UZBEKISTAN',
    'VANUATU' => 'VANUATU',
    'VATICAN CITY' => 'KOTA VATIKAN',
    'VENEZUELA' => 'VENEZUELA',
    'VIETNAM' => 'VIETNAM',
    'WAKE ISLAND' => 'PULAU WAKE',
    'WEST INDIES' => 'INDIES BARAT',
    'WESTERN SAHARA' => 'WESTERN SAHARA',
    'YEMEN' => 'YAMAN',
    'ZAIRE' => 'ZAIRE',
    'ZAMBIA' => 'ZAMBIA',
    'ZIMBABWE' => 'ZIMBABWE',
);

$app_list_strings['charset_dom'] = array(
    'BIG-5' => 'BIG-5 (Taiwan und Hong Kong)',
    /*'CP866'     => 'CP866', // ms-dos Cyrillic */
    /*'CP949'     => 'CP949 (Microsoft Korean)', */
    'CP1251' => 'CP1251 (MS Cyrillisch)',
    'CP1252' => 'CP1252 (MS Westeuropa & US)',
    'EUC-CN' => 'EUC-CN (Cina Sederhana GB2312)',
    'EUC-JP' => 'EUC-JP (Unix Japanisch)',
    'EUC-KR' => 'EUC-KR (Koreanisch)',
    'EUC-TW' => 'EUC-TW (Taiwanesisch)',
    'ISO-2022-JP' => 'ISO-2022-JP (Japanisch)',
    'ISO-2022-KR' => 'ISO-2022-KR (Koreanisch)',
    'ISO-8859-1' => 'ISO-8859-1 (Westeuropa und US)',
    'ISO-8859-2' => 'ISO-8859-2 (Zentral- und Osteuropa)',
    'ISO-8859-3' => 'ISO-8859-3 (Latin 3)',
    'ISO-8859-4' => 'ISO-8859-4 (Latin 4)',
    'ISO-8859-5' => 'ISO-8859-5 (Cyrillic)',
    'ISO-8859-6' => 'ISO-8859-6 (bahasa Arab)',
    'ISO-8859-7' => 'ISO-8859-7 (bahasa Yunani)',
    'ISO-8859-8' => 'ISO-8859-8 (bahasa Ibrani)',
    'ISO-8859-9' => 'ISO-8859-9 (Latin 5)',
    'ISO-8859-10' => 'ISO-8859-10 (Latin 6)',
    'ISO-8859-13' => 'ISO-8859-13 (Latin 7)',
    'ISO-8859-14' => 'ISO-8859-14 (Latin 8)',
    'ISO-8859-15' => 'ISO-8859-15 (Latin 9)',
    'KOI8-R' => 'KOI8-R (Cyrillic Russian)',
    'KOI8-U' => 'KOI8-U (Cyrillic Ukranian)',
    'SJIS' => 'SJIS (MS Jepang)',
    'UTF-8' => 'UTF-8',
);

$app_list_strings['timezone_dom'] = array(

    'Africa/Algiers' => 'Afrika / Aljir',
    'Africa/Luanda' => 'Afrika / Aljir',
    'Africa/Porto-Novo' => 'Afrika/Porto-Novo',
    'Africa/Gaborone' => 'Afrika/Gaborone',
    'Africa/Ouagadougou' => 'Afrika/Ouagadougou',
    'Africa/Bujumbura' => 'Afrika/Bujumbura',
    'Africa/Douala' => 'Afrika/Douala',
    'Atlantic/Cape_Verde' => 'Atlantik/Cape Verde',
    'Africa/Bangui' => 'Afrika/Bangui',
    'Africa/Ndjamena' => 'Afrika/Ndjamena',
    'Indian/Comoro' => 'India/Comoro',
    'Africa/Kinshasa' => 'Afrika/Kinshasa',
    'Africa/Lubumbashi' => 'Afrika/Lubumbashi',
    'Africa/Brazzaville' => 'Afrika/Brazzaville',
    'Africa/Abidjan' => 'Afrika/Abidjan',
    'Africa/Djibouti' => 'Afrika/Djibouti',
    'Africa/Cairo' => 'Afrika/Cairo',
    'Africa/Malabo' => 'Afrika/Malabo',
    'Africa/Asmera' => 'Afrika/Asmera',
    'Africa/Addis_Ababa' => 'Afrika/Addis Ababa',
    'Africa/Libreville' => 'Afrika/Libreville',
    'Africa/Banjul' => 'Afrika/Banjul',
    'Africa/Accra' => 'Afrika/Accra',
    'Africa/Conakry' => 'Afrika/Conakry',
    'Africa/Bissau' => 'Afrika/Bissau',
    'Africa/Nairobi' => 'Afrika/Nairobi',
    'Africa/Maseru' => 'Afrika/Maseru',
    'Africa/Monrovia' => 'Afrika/Monrovia',
    'Africa/Tripoli' => 'Afrika / Tripoli',
    'Indian/Antananarivo' => 'India/Antananarivo',
    'Africa/Blantyre' => 'Afrika/Blantyre',
    'Africa/Bamako' => 'Afrika/Bamako',
    'Africa/Nouakchott' => 'Afrika/Nouakchott',
    'Indian/Mauritius' => 'India/Mauritius',
    'Indian/Mayotte' => 'India/Mayotte',
    'Africa/Casablanca' => 'Afrika/Casablanka',
    'Africa/El_Aaiun' => 'Afrika/El Aaiun',
    'Africa/Maputo' => 'Afrika/Maputo',
    'Africa/Windhoek' => 'Afrika/Windhoek',
    'Africa/Niamey' => 'Afrika/Niamey',
    'Africa/Lagos' => 'Afrika/Lagos',
    'Indian/Reunion' => 'India/Reunion',
    'Africa/Kigali' => 'Afrika/Kigali',
    'Atlantic/St_Helena' => 'Atlantik/St. Helena',
    'Africa/Sao_Tome' => 'Afrika/Sao Tome',
    'Africa/Dakar' => 'Afrika/Dakar',
    'Indian/Mahe' => 'India/Mahe',
    'Africa/Freetown' => 'Afrika/Freetown',
    'Africa/Mogadishu' => 'Afrika/Mogadishu',
    'Africa/Johannesburg' => 'Afrika/Johannesburg',
    'Africa/Khartoum' => 'Afrika/Khartoum',
    'Africa/Mbabane' => 'Afrika/Mbabane',
    'Africa/Dar_es_Salaam' => 'Afrika/Dar es Salam',
    'Africa/Lome' => 'Africa/Lome',
    'Africa/Tunis' => 'Africa/Tunis',
    'Africa/Kampala' => 'Africa/Kampala',
    'Africa/Lusaka' => 'Africa/Lusaka',
    'Africa/Harare' => 'Africa/Harare',
    'Antarctica/Casey' => 'Antartika/Casey',
    'Antarctica/Davis' => 'Antartika/Davis',
    'Antarctica/Mawson' => 'Antartika/Mawson',
    'Indian/Kerguelen' => 'India/Kerguelen',
    'Antarctica/DumontDUrville' => 'Antartika/DumontDUrville',
    'Antarctica/Syowa' => 'Antartika/Syowa',
    'Antarctica/Vostok' => 'Antartika/Vostok',
    'Antarctica/Rothera' => 'Antartika/Rothera',
    'Antarctica/Palmer' => 'Antartika/Palmer',
    'Antarctica/McMurdo' => 'Antartika/McMurdo',
    'Asia/Kabul' => 'Asia/Kabul',
    'Asia/Yerevan' => 'Asia/Yerevan',
    'Asia/Baku' => 'Asia/Baku',
    'Asia/Bahrain' => 'Asia/Bahrain',
    'Asia/Dhaka' => 'Asia/Dhaka',
    'Asia/Thimphu' => 'Asia/Thimphu',
    'Indian/Chagos' => 'India/Chagos',
    'Asia/Brunei' => 'Asia/Brunai Darussalam',
    'Asia/Rangoon' => 'Asia/Rangoon',
    'Asia/Phnom_Penh' => 'Asia/Phnom Penh',
    'Asia/Beijing' => 'Asia/Beijing',
    'Asia/Harbin' => 'Asia/Harbin',
    'Asia/Shanghai' => 'Asia/Shanghai',
    'Asia/Chongqing' => 'Asia/Chongqing',
    'Asia/Urumqi' => 'Asia/Urumqi',
    'Asia/Kashgar' => 'Asia/Kashgar',
    'Asia/Hong_Kong' => 'Asia/Hong Kong',
    'Asia/Taipei' => 'Asia/Taipei',
    'Asia/Macau' => 'Asia/Makau',
    'Asia/Nicosia' => 'Asia/Nicosia',
    'Asia/Tbilisi' => 'Asia/Tbilisi',
    'Asia/Dili' => 'Asia/Dili',
    'Asia/Calcutta' => 'Asia/Kalkuta',
    'Asia/Jakarta' => 'Asia/Jakarta',
    'Asia/Pontianak' => 'Asia/Pontianak',
    'Asia/Makassar' => 'Asia/Makassar',
    'Asia/Jayapura' => 'Asia/Jayapura',
    'Asia/Tehran' => 'Asia/Teheran',
    'Asia/Baghdad' => 'Asia/Baghdad',
    'Asia/Jerusalem' => 'Asia/Yerusalem',
    'Asia/Tokyo' => 'Asia/Tokyo',
    'Asia/Amman' => 'Asia/Amman',
    'Asia/Almaty' => 'Asia/Almaty',
    'Asia/Qyzylorda' => 'Asia/Qyzylorda',
    'Asia/Aqtobe' => 'Asia/Aqtobe',
    'Asia/Aqtau' => 'Asia/Aqtau',
    'Asia/Oral' => 'Asia/Oral',
    'Asia/Bishkek' => 'Asia/Bishkek',
    'Asia/Seoul' => 'Asia/Seoul',
    'Asia/Pyongyang' => 'Asia/Pyongyang',
    'Asia/Kuwait' => 'Asia/Kuwait',
    'Asia/Vientiane' => 'Asia/Vientiane',
    'Asia/Beirut' => 'Asia/Beirut',
    'Asia/Kuala_Lumpur' => 'Asia/Kuala Lumpur',
    'Asia/Kuching' => 'Asia/Kuching',
    'Indian/Maldives' => 'India/Maladewa',
    'Asia/Hovd' => 'Asia/Hovd',
    'Asia/Ulaanbaatar' => 'Asia/Ulaanbaatar',
    'Asia/Choibalsan' => 'Asia/Choibalsan',
    'Asia/Katmandu' => 'Asia/Kathmandu',
    'Asia/Muscat' => 'Asia/Muscat',
    'Asia/Karachi' => 'Asia/Karachi',
    'Asia/Gaza' => 'Asia/Gaza',
    'Asia/Manila' => 'Asia/Manila',
    'Asia/Qatar' => 'Asia/Qatar',
    'Asia/Riyadh' => 'Asia/Riyadh',
    'Asia/Singapore' => 'Asia/Singapura',
    'Asia/Colombo' => 'Asia/Kolombo',
    'Asia/Damascus' => 'Asia/Damaskus',
    'Asia/Dushanbe' => 'Asia/Dushanbe',
    'Asia/Bangkok' => 'Asia/Bangkok',
    'Asia/Ashgabat' => 'Asia/Ashgabat',
    'Asia/Dubai' => 'Asia/Dubai',
    'Asia/Samarkand' => 'Asia/Samarkan',
    'Asia/Tashkent' => 'Asia/Tashken',
    'Asia/Saigon' => 'Asia/Saigon',
    'Asia/Aden' => 'Asia/Aden',
    'Australia/Darwin' => 'Australia/Darwin',
    'Australia/Perth' => 'Australia/Perth',
    'Australia/Brisbane' => 'Australia/Brisbane',
    'Australia/Lindeman' => 'Australia/Lindeman',
    'Australia/Adelaide' => 'Australia/Adelaide',
    'Australia/Hobart' => 'Australia/Hobart',
    'Australia/Currie' => 'Australia/Currie',
    'Australia/Melbourne' => 'Australia/Melbourne',
    'Australia/Sydney' => 'Australia/Sydney',
    'Australia/Broken_Hill' => 'Australia/Broken Hill',
    'Indian/Christmas' => 'India/Christmas',
    'Pacific/Rarotonga' => 'Pasifik/Rarotonga',
    'Indian/Cocos' => 'India/Cocos',
    'Pacific/Fiji' => 'Pasifik/Fiji',
    'Pacific/Gambier' => 'Pasifik/Gambier',
    'Pacific/Marquesas' => 'Pasifik/Marquesas',
    'Pacific/Tahiti' => 'Pasifik/Tahiti',
    'Pacific/Guam' => 'Pasifik/Guam',
    'Pacific/Tarawa' => 'Pasifik/Tarawa',
    'Pacific/Enderbury' => 'Pasifik/Enderbury',
    'Pacific/Kiritimati' => 'Pasifik/Kiritimati',
    'Pacific/Saipan' => 'Pasifik/Saipan',
    'Pacific/Majuro' => 'Pasifik/Majuro',
    'Pacific/Kwajalein' => 'Pasifik/Kwajalein',
    'Pacific/Truk' => 'Pasifik/Truk',
    'Pacific/Pohnpei' => 'Pasifik/Pohnpei',
    'Pacific/Kosrae' => 'Pasifik/Kosrae',
    'Pacific/Nauru' => 'Pasifik/Nauru',
    'Pacific/Noumea' => 'Pasifik/Noumea',
    'Pacific/Auckland' => 'Pasifik/Auckland',
    'Pacific/Chatham' => 'Pasifik/Chatham',
    'Pacific/Niue' => 'Pasifik/Niue',
    'Pacific/Norfolk' => 'Pasifik/Norfolk',
    'Pacific/Palau' => 'Pasifik/Palau',
    'Pacific/Port_Moresby' => 'Pasifik/Port Moresby',
    'Pacific/Pitcairn' => 'Pasifik/Pitcairn',
    'Pacific/Pago_Pago' => 'Pasifik/Pago Pago',
    'Pacific/Apia' => 'Pasifik/Apia',
    'Pacific/Guadalcanal' => 'Pasifik/Guadalcanal',
    'Pacific/Fakaofo' => 'Pasifik/Fakaofo',
    'Pacific/Tongatapu' => 'Pasifik/Tongatapu',
    'Pacific/Funafuti' => 'Pasifik/Funafuti',
    'Pacific/Johnston' => 'Pasifik/Johnston',
    'Pacific/Midway' => 'Pasifik/Midway',
    'Pacific/Wake' => 'Pasifik/Wake',
    'Pacific/Efate' => 'Pasifik/Efate',
    'Pacific/Wallis' => 'Pasifik/Wallis',
    'Europe/London' => 'Eropa/London',
    'Europe/Dublin' => 'Eropa/Dublin',
    'WET' => 'WET',
    'CET' => 'CET',
    'MET' => 'MET',
    'EET' => 'EET',
    'Europe/Tirane' => 'Eropa/Tirane',
    'Europe/Andorra' => 'Eropa/Andora',
    'Europe/Vienna' => 'Eropa/Viena',
    'Europe/Minsk' => 'Eropa/Minsk',
    'Europe/Brussels' => 'Eropa/Brusel',
    'Europe/Sofia' => 'Eropa/Sofia',
    'Europe/Prague' => 'Eropa/Pragu',
    'Europe/Copenhagen' => 'Eropa/Kopenhagen',
    'Atlantic/Faeroe' => 'Atlantik/Faeroe',
    'America/Danmarkshavn' => 'Amerika/Danmarkshavn',
    'America/Scoresbysund' => 'Amerika/Scoresbysund',
    'America/Godthab' => 'Amerika/Godthab',
    'America/Thule' => 'Amerika/Thule',
    'Europe/Tallinn' => 'Eropa/Talin',
    'Europe/Helsinki' => 'Eropa/Helsinki',
    'Europe/Paris' => 'Eropa/Paris',
    'Europe/Berlin' => 'Eropa/Berlin',
    'Europe/Gibraltar' => 'Eropa/Gibraltar',
    'Europe/Athens' => 'Eropa/Athena',
    'Europe/Budapest' => 'Eropa/Budapest',
    'Atlantic/Reykjavik' => 'Atlantik/Reykjavik',
    'Europe/Rome' => 'Eropa/Roma',
    'Europe/Riga' => 'Eropa/Riga',
    'Europe/Vaduz' => 'Eropa/Vaduz',
    'Europe/Vilnius' => 'Eropa/Vilnius',
    'Europe/Luxembourg' => 'Eropa/Luksemburg',
    'Europe/Malta' => 'Eropa/Malta',
    'Europe/Chisinau' => 'Eropa/Chisinau',
    'Europe/Monaco' => 'Eropa/Monako',
    'Europe/Amsterdam' => 'Eropa/Amsterdam',
    'Europe/Oslo' => 'Eropa/Oslo',
    'Europe/Warsaw' => 'Eropa/Warsawa',
    'Europe/Lisbon' => 'Eropa/Lisbon',
    'Atlantic/Azores' => 'Atlantik/Azores',
    'Atlantic/Madeira' => 'Atlantik/Madeira',
    'Europe/Bucharest' => 'Eropa/Bucharest',
    'Europe/Kaliningrad' => 'Eropa/Kaliningrad',
    'Europe/Moscow' => 'Eropa/Mosko',
    'Europe/Samara' => 'Eropa/Samara',
    'Asia/Yekaterinburg' => 'Asia/Yekaterinburg',
    'Asia/Omsk' => 'Asia/Omsk',
    'Asia/Novosibirsk' => 'Asia/Novosibirsk',
    'Asia/Krasnoyarsk' => 'Asia/Krasnoyarsk',
    'Asia/Irkutsk' => 'Asia/Irkutsk',
    'Asia/Yakutsk' => 'Asia/Yakutsk',
    'Asia/Vladivostok' => 'Asia/Vladivostok',
    'Asia/Sakhalin' => 'Asia/Sakhalin',
    'Asia/Magadan' => 'Asia/Magadan',
    'Asia/Kamchatka' => 'Asia/Kamchatka',
    'Asia/Anadyr' => 'Asia/Anadyr',
    'Europe/Belgrade' => 'Eropa/Belgrade',
    'Europe/Madrid' => 'Eropa/Madrid',
    'Africa/Ceuta' => 'Afrika/Ceuta',
    'Atlantic/Canary' => 'Atlantik/Canary',
    'Europe/Stockholm' => 'Eropa/Stockholm',
    'Europe/Zurich' => 'Eropa/Zurich',
    'Europe/Istanbul' => 'Eropa/Istanbul',
    'Europe/Kiev' => 'Eropa/Kiev',
    'Europe/Uzhgorod' => 'Eropa/Uzhgorod',
    'Europe/Zaporozhye' => 'Eropa/Zaporozhye',
    'Europe/Simferopol' => 'Eropa/Simferopol',
    'America/New_York' => 'Amerika/New York',
    'America/Chicago' => 'Amerika/Chicago',
    'America/North_Dakota/Center' => 'Amerika/North Dakota/Center',
    'America/Denver' => 'Amerika/Denver',
    'America/Los_Angeles' => 'Amerika/Los Angeles',
    'America/Juneau' => 'Amerika/Juneau',
    'America/Yakutat' => 'Amerika/Yakutat',
    'America/Anchorage' => 'Amerika/Anchorage',
    'America/Nome' => 'Amerika/Nome',
    'America/Adak' => 'Amerika/Adak',
    'Pacific/Honolulu' => 'Pasifik/Honolulu',
    'America/Phoenix' => 'Amerika/Phoenix',
    'America/Boise' => 'Amerika/Boise',
    'America/Indiana/Indianapolis' => 'Amerika/Indiana/Indianapolis',
    'America/Indiana/Marengo' => 'Amerika/Indiana/Marengo',
    'America/Indiana/Knox' => 'Amerika/Indiana/Knox',
    'America/Indiana/Vevay' => 'Amerika/Indiana/Vevay',
    'America/Kentucky/Louisville' => 'Amerika/Kentucky/Louisville',
    'America/Kentucky/Monticello' => 'Amerika/Kentucky/Monticello',
    'America/Detroit' => 'Amerika/Detroit',
    'America/Menominee' => 'Amerika/Menominee',
    'America/St_Johns' => 'Amerika/St. Johns',
    'America/Goose_Bay' => 'Amerika/Goose_Bay',
    'America/Halifax' => 'Amerika/Halifax',
    'America/Glace_Bay' => 'Amerika/Glace Bay',
    'America/Montreal' => 'Amerika/Montreal',
    'America/Toronto' => 'Amerika/Toronto',
    'America/Thunder_Bay' => 'Amerika/Thunder Bay',
    'America/Nipigon' => 'Amerika/Nipigon',
    'America/Rainy_River' => 'Amerika/Rainy River',
    'America/Winnipeg' => 'Amerika/Winnipeg',
    'America/Regina' => 'Amerika/Regina',
    'America/Swift_Current' => 'Amerika/Swift Current',
    'America/Edmonton' => 'Amerika/Edmonton',
    'America/Vancouver' => 'Amerika/Vancouver',
    'America/Dawson_Creek' => 'Amerika/Dawson Creek',
    'America/Pangnirtung' => 'Amerika/Pangnirtung',
    'America/Iqaluit' => 'Amerika/Iqaluit',
    'America/Coral_Harbour' => 'Amerika/Coral Harbour',
    'America/Rankin_Inlet' => 'Amerika/Rankin Inlet',
    'America/Cambridge_Bay' => 'Amerika/Cambridge Bay',
    'America/Yellowknife' => 'Amerika/Yellowknife',
    'America/Inuvik' => 'Amerika/Inuvik',
    'America/Whitehorse' => 'Amerika/Whitehorse',
    'America/Dawson' => 'Amerika/Dawson',
    'America/Cancun' => 'Amerika/Cancun',
    'America/Merida' => 'Amerika/Merida',
    'America/Monterrey' => 'Amerika/Monterrey',
    'America/Mexico_City' => 'Amerika/Mexico City',
    'America/Chihuahua' => 'Amerika/Chihuahua',
    'America/Hermosillo' => 'Amerika/Hermosillo',
    'America/Mazatlan' => 'Amerika/Mazatlan',
    'America/Tijuana' => 'Amerika/Tijuana',
    'America/Anguilla' => 'Amerika/Anguilla',
    'America/Antigua' => 'Amerika/Antigua',
    'America/Nassau' => 'Amerika/Nassau',
    'America/Barbados' => 'Amerika/Barbados',
    'America/Belize' => 'Amerika/Belize',
    'Atlantic/Bermuda' => 'Atlantik/Bermuda',
    'America/Cayman' => 'Amerika/Cayman',
    'America/Costa_Rica' => 'Amerika/Costa Rica',
    'America/Havana' => 'Amerika/Havana',
    'America/Dominica' => 'Amerika/Dominika',
    'America/Santo_Domingo' => 'Amerika/Santo Domingo',
    'America/El_Salvador' => 'Amerika/El Salvador',
    'America/Grenada' => 'Amerika/Grenada',
    'America/Guadeloupe' => 'Amerika/Guadeloupe',
    'America/Guatemala' => 'Amerika/Guatemala',
    'America/Port-au-Prince' => 'Amerika/Port-au-Prince',
    'America/Tegucigalpa' => 'Amerika/Tegucigalpa',
    'America/Jamaica' => 'Amerika/Jamaika',
    'America/Martinique' => 'Amerika/Martinik',
    'America/Montserrat' => 'Amerika/Montserrat',
    'America/Managua' => 'Amerika/Managua',
    'America/Panama' => 'Amerika/Panama',
    'America/Puerto_Rico' => 'Amerika/Puerto_Rico',
    'America/St_Kitts' => 'Amerika/St_Kitts',
    'America/St_Lucia' => 'Amerika/St_Lucia',
    'America/Miquelon' => 'Amerika/Miquelon',
    'America/St_Vincent' => 'Amerika/St. Vincent',
    'America/Grand_Turk' => 'Amerika/Grand Turk',
    'America/Tortola' => 'Amerika/Tortola',
    'America/St_Thomas' => 'Amerika/St. Thomas',
    'America/Argentina/Buenos_Aires' => 'Amerika/Argentina/Buenos Aires',
    'America/Argentina/Cordoba' => 'Amerika/Argentina/Kordoba',
    'America/Argentina/Tucuman' => 'Amerika/Argentina/Tucuman',
    'America/Argentina/La_Rioja' => 'Amerika/Argentina/La_Rioja',
    'America/Argentina/San_Juan' => 'Amerika/Argentina/San_Juan',
    'America/Argentina/Jujuy' => 'Amerika/Argentina/Jujuy',
    'America/Argentina/Catamarca' => 'Amerika/Argentina/Catamarca',
    'America/Argentina/Mendoza' => 'Amerika/Argentina/Mendoza',
    'America/Argentina/Rio_Gallegos' => 'Amerika/Argentina/Rio Gallegos',
    'America/Argentina/Ushuaia' => 'Amerika/Argentina/Ushuaia',
    'America/Aruba' => 'Amerika/Aruba',
    'America/La_Paz' => 'Amerika/La Paz',
    'America/Noronha' => 'Amerika/Noronha',
    'America/Belem' => 'Amerika/Belem',
    'America/Fortaleza' => 'Amerika/Fortaleza',
    'America/Recife' => 'Amerika/Recife',
    'America/Araguaina' => 'Amerika/Araguaina',
    'America/Maceio' => 'Amerika/Maceio',
    'America/Bahia' => 'Amerika/Bahia',
    'America/Sao_Paulo' => 'Amerika/Sao Paulo',
    'America/Campo_Grande' => 'Amerika/Campo Grande',
    'America/Cuiaba' => 'Amerika/Cuiaba',
    'America/Porto_Velho' => 'Amerika/Porto_Velho',
    'America/Boa_Vista' => 'Amerika/Boa Vista',
    'America/Manaus' => 'Amerika/Manaus',
    'America/Eirunepe' => 'Amerika/Eirunepe',
    'America/Rio_Branco' => 'Amerika/Rio Branco',
    'America/Santiago' => 'Amerika/Santiago',
    'Pacific/Easter' => 'Pasifik/Easter',
    'America/Bogota' => 'Amerika/Bogota',
    'America/Curacao' => 'Amerika/Curacao',
    'America/Guayaquil' => 'Amerika/Guayaquil',
    'Pacific/Galapagos' => 'Pasifik/Galapagos',
    'Atlantic/Stanley' => 'Atlantik/Stanley',
    'America/Cayenne' => 'Amerika/Cayenne',
    'America/Guyana' => 'Amerika/Guyana',
    'America/Asuncion' => 'Amerika/Asuncion',
    'America/Lima' => 'Amerika/Lima',
    'Atlantic/South_Georgia' => 'Atlantik/South Georgia',
    'America/Paramaribo' => 'Amerika/Paramaribo',
    'America/Port_of_Spain' => 'Amerika/Port-of-Spain',
    'America/Montevideo' => 'Amerika/Montevideo',
    'America/Caracas' => 'Amerika/Caracas',
);

$app_list_strings['eapm_list'] = array(
    'Sugar' => 'SuiteCRM',
    'WebEx' => 'WebEx',
    'GoToMeeting' => 'Sedang Rapat',
    'IBMSmartCloud' => 'SmartCloud IBM',
    'Google' => 'Google',
    'Box' => 'Box.net',
    'Facebook' => 'Facebook',
    'Twitter' => 'Twitter',
);
$app_list_strings['eapm_list_import'] = array(
    'Google' => 'Google Contacts',
);
$app_list_strings['eapm_list_documents'] = array(
    'Google' => 'Google Drive',
);
$app_list_strings['token_status'] = array(
    1 => 'Permintaan',
    2 => 'Akses',
    3 => 'Tidak Valid',
);

$app_list_strings ['emailTemplates_type_list'] = array(
    '' => '',
    'campaign' => 'Campaign',
    'email' => 'Surel',
    'event' => 'Acara',
);

$app_list_strings ['emailTemplates_type_list_campaigns'] = array(
    '' => '',
    'campaign' => 'Campaign',
);

$app_list_strings ['emailTemplates_type_list_no_workflow'] = array(
    '' => '',
    'campaign' => 'Campaign',
    'email' => 'Surel',
    'event' => 'Peristiwa',
    'system' => 'Sistem',
);

// knowledge base
$app_list_strings['moduleList']['AOK_KnowledgeBase'] = 'Berbasis Pengetahuan';
$app_list_strings['moduleList']['AOK_Knowledge_Base_Categories'] = 'Kategori - KB';
$app_list_strings['aok_status_list']['Draft'] = 'Draft';
$app_list_strings['aok_status_list']['Expired'] = 'Expired';
$app_list_strings['aok_status_list']['In_Review'] = 'In Review';
//$app_list_strings['aok_status_list']['Published'] = 'Published';
$app_list_strings['aok_status_list']['published_private'] = 'Privasi';
$app_list_strings['aok_status_list']['published_public'] = 'Umum';

$app_list_strings['moduleList']['FP_events'] = 'Acara';
$app_list_strings['moduleList']['FP_Event_Locations'] = 'Lokasi';

//events
$app_list_strings['fp_event_invite_status_dom']['Invited'] = 'Diundang';
$app_list_strings['fp_event_invite_status_dom']['Not Invited'] = 'Tidak diundang';
$app_list_strings['fp_event_invite_status_dom']['Attended'] = 'Dihadiri';
$app_list_strings['fp_event_invite_status_dom']['Not Attended'] = 'Tidak hadir';
$app_list_strings['fp_event_status_dom']['Accepted'] = 'Accepted';
$app_list_strings['fp_event_status_dom']['Declined'] = 'Ditolak';
$app_list_strings['fp_event_status_dom']['No Response'] = 'Tidak ada Respon';

$app_strings['LBL_STATUS_EVENT'] = 'Status Undang';
$app_strings['LBL_ACCEPT_STATUS'] = 'Terima Status';
$app_strings['LBL_LISTVIEW_OPTION_CURRENT'] = 'Halaman Ini';
$app_strings['LBL_LISTVIEW_OPTION_ENTIRE'] = 'Semua Record';
$app_strings['LBL_LISTVIEW_NONE'] = 'Tidak Ada';

$app_list_strings['moduleList']['AOP_Case_Events'] = 'Kasus Peristiwa';
$app_list_strings['moduleList']['AOP_Case_Updates'] = 'Pembaharuan Kasus';
$app_strings['LBL_AOP_EMAIL_REPLY_DELIMITER'] = '========== Silahkan balas diatas garis ini ==========';

//aop
$app_list_strings['case_state_default_key'] = 'Buka';
$app_list_strings['case_state_dom'] =
    array(
        'Open' => 'Buka',
        'Closed' => 'Closed',
    );
$app_list_strings['case_status_default_key'] = 'Open_New';
$app_list_strings['case_status_dom'] =
    array(
        'Open_New' => 'New',
        'Open_Assigned' => 'Assigned',
        'Closed_Closed' => 'Closed',
        'Open_Pending Input' => 'Pending Input',
        'Closed_Rejected' => 'Rejected',
        'Closed_Duplicate' => 'Duplicate',
    );
$app_list_strings['contact_portal_user_type_dom'] =
    array(
        'Single' => 'Pengguna Tunggal',
        'Account' => 'Akun pengguna',
    );
$app_list_strings['dom_email_distribution_for_auto_create'] = array(
    'AOPDefault' => 'Sistem Default',
    'singleUser' => 'Pengguna Tunggal',
    'roundRobin' => 'Round-Robin',
    'leastBusy' => 'Least-busy',
    'random' => 'Acak',
);

//aor
$app_list_strings['moduleList']['AOR_Reports'] = 'Laporan';
$app_list_strings['moduleList']['AOR_Conditions'] = 'Laporan Kondisi';
$app_list_strings['moduleList']['AOR_Charts'] = 'Laporan Grafik';
$app_list_strings['moduleList']['AOR_Fields'] = 'Laporan Bidang';
$app_list_strings['moduleList']['AOR_Scheduled_Reports'] = 'Laporan Terjadwal';
$app_list_strings['aor_operator_list']['Equal_To'] = 'Sama dengan';
$app_list_strings['aor_operator_list']['Not_Equal_To'] = 'Tidak Sama Dengan';
$app_list_strings['aor_operator_list']['Greater_Than'] = 'Lebih besar dari';
$app_list_strings['aor_operator_list']['Less_Than'] = 'Kurang dari';
$app_list_strings['aor_operator_list']['Greater_Than_or_Equal_To'] = 'Lebih Besar Daripada atau Sama Dengan';
$app_list_strings['aor_operator_list']['Less_Than_or_Equal_To'] = 'Kurang Dari atau Sama Dengan';
$app_list_strings['aor_operator_list']['Contains'] = 'Contains';
$app_list_strings['aor_operator_list']['Starts_With'] = 'Mulai Dengan';
$app_list_strings['aor_operator_list']['Ends_With'] = 'Berakhir Dengan';
$app_list_strings['aor_format_options'][''] = '';
$app_list_strings['aor_format_options']['Y-m-d'] = 'Y-m-d';
$app_list_strings['aor_format_options']['m-d-Y'] = 'b-h-T';
$app_list_strings['aor_format_options']['d-m-Y'] = 'h-b-T';
$app_list_strings['aor_format_options']['Y/m/d'] = 'T/b/h';
$app_list_strings['aor_format_options']['m/d/Y'] = 'b/h/T';
$app_list_strings['aor_format_options']['d/m/Y'] = 'd/m/Y';
$app_list_strings['aor_format_options']['Y.m.d'] = 'T.b.h';
$app_list_strings['aor_format_options']['m.d.Y'] = 'b.h.T';
$app_list_strings['aor_format_options']['d.m.Y'] = 'h.b.T';
$app_list_strings['aor_format_options']['Ymd'] = 'Ymd';
$app_list_strings['aor_format_options']['Y-m'] = 'Y-m';
$app_list_strings['aor_format_options']['Y'] = 'Y';
$app_list_strings['aor_condition_operator_list']['And'] = 'And';
$app_list_strings['aor_condition_operator_list']['OR'] = 'OR';
$app_list_strings['aor_condition_type_list']['Value'] = 'Nilai';
$app_list_strings['aor_condition_type_list']['Field'] = 'Nama Field';
$app_list_strings['aor_condition_type_list']['Date'] = 'Date';
$app_list_strings['aor_condition_type_list']['Multi'] = 'Salah satu';
$app_list_strings['aor_condition_type_list']['Period'] = 'Periode';
$app_list_strings['aor_condition_type_list']['CurrentUserID'] = 'Pengguna Saat Ini';
$app_list_strings['aor_date_type_list'][''] = '';
$app_list_strings['aor_date_type_list']['minute'] = 'Minutes';
$app_list_strings['aor_date_type_list']['hour'] = 'Hours';
$app_list_strings['aor_date_type_list']['day'] = 'Days';
$app_list_strings['aor_date_type_list']['week'] = 'Minggu';
$app_list_strings['aor_date_type_list']['month'] = 'Bulan';
$app_list_strings['aor_date_type_list']['business_hours'] = 'Jam kerja';
$app_list_strings['aor_date_options']['now'] = 'Sekarang';
$app_list_strings['aor_date_options']['field'] = 'Bagian Ini';
$app_list_strings['aor_date_operator']['now'] = '';
$app_list_strings['aor_date_operator']['plus'] = '+';
$app_list_strings['aor_date_operator']['minus'] = '-';
$app_list_strings['aor_sort_operator'][''] = '';
$app_list_strings['aor_sort_operator']['ASC'] = 'Ascending';
$app_list_strings['aor_sort_operator']['DESC'] = 'Descending';
$app_list_strings['aor_function_list'][''] = '';
$app_list_strings['aor_function_list']['COUNT'] = 'Hitung';
$app_list_strings['aor_function_list']['MIN'] = 'Minimum';
$app_list_strings['aor_function_list']['MAX'] = 'Maksimum';
$app_list_strings['aor_function_list']['SUM'] = 'Tambahkan';
$app_list_strings['aor_function_list']['AVG'] = 'Rata-rata';
$app_list_strings['aor_total_options'][''] = '';
$app_list_strings['aor_total_options']['COUNT'] = 'Hitung';
$app_list_strings['aor_total_options']['SUM'] = 'Tambahkan';
$app_list_strings['aor_total_options']['AVG'] = 'Rata-rata';
$app_list_strings['aor_chart_types']['bar'] = 'Grafik Balok';
$app_list_strings['aor_chart_types']['line'] = 'Grafik Garis';
$app_list_strings['aor_chart_types']['pie'] = 'Grafik Pie';
$app_list_strings['aor_chart_types']['radar'] = 'Grafik Radar';
$app_list_strings['aor_chart_types']['stacked_bar'] = 'Tumpukan Balok';
$app_list_strings['aor_chart_types']['grouped_bar'] = 'Balok Kelompok';
$app_list_strings['aor_scheduled_report_schedule_types']['monthly'] = 'Monthly';
$app_list_strings['aor_scheduled_report_schedule_types']['weekly'] = 'Weekly';
$app_list_strings['aor_scheduled_report_schedule_types']['daily'] = 'Harian';
$app_list_strings['aor_scheduled_reports_status_dom']['active'] = 'Active';
$app_list_strings['aor_scheduled_reports_status_dom']['inactive'] = 'Inactive';
$app_list_strings['aor_email_type_list']['Email Address'] = 'Surel';
$app_list_strings['aor_email_type_list']['Specify User'] = 'User';
$app_list_strings['aor_email_type_list']['Users'] = 'Users';
$app_list_strings['aor_assign_options']['all'] = 'Semua Pengguna';
$app_list_strings['aor_assign_options']['role'] = 'Semua Pengguna dalam Tugas';
$app_list_strings['aor_assign_options']['security_group'] = 'SEMUA Pengguna di Grup Keamanan';
$app_list_strings['date_time_period_list']['today'] = 'Today';
$app_list_strings['date_time_period_list']['yesterday'] = 'Kemarin';
$app_list_strings['date_time_period_list']['this_week'] = 'Minggu Ini';
$app_list_strings['date_time_period_list']['last_week'] = 'Minggu terakhir';
$app_list_strings['date_time_period_list']['last_month'] = 'Last Month';
$app_list_strings['date_time_period_list']['this_month'] = 'This Month';
$app_list_strings['date_time_period_list']['this_quarter'] = 'Caturwulan Ini';
$app_list_strings['date_time_period_list']['last_quarter'] = 'Caturwulan Terakhir';
$app_list_strings['date_time_period_list']['this_year'] = 'Tahun Ini';
$app_list_strings['date_time_period_list']['last_year'] = 'Tahun Lalu';
$app_strings['LBL_CRON_ON_THE_MONTHDAY'] = '-';
$app_strings['LBL_CRON_ON_THE_WEEKDAY'] = 'di';
$app_strings['LBL_CRON_AT'] = 'pada';
$app_strings['LBL_CRON_RAW'] = 'Melanjutkan';
$app_strings['LBL_CRON_MIN'] = 'Menit';
$app_strings['LBL_CRON_HOUR'] = 'Jam';
$app_strings['LBL_CRON_DAY'] = 'Day';
$app_strings['LBL_CRON_MONTH'] = 'Bulan';
$app_strings['LBL_CRON_DOW'] = 'DOW';
$app_strings['LBL_CRON_DAILY'] = 'Harian';
$app_strings['LBL_CRON_WEEKLY'] = 'Weekly';
$app_strings['LBL_CRON_MONTHLY'] = 'Monthly';

//aos
$app_list_strings['moduleList']['AOS_Contracts'] = 'Contracts';
$app_list_strings['moduleList']['AOS_Invoices'] = 'Faktur';
$app_list_strings['moduleList']['AOS_PDF_Templates'] = 'Template PDF';
$app_list_strings['moduleList']['AOS_Product_Categories'] = 'Kategori - Produk';
$app_list_strings['moduleList']['AOS_Products'] = 'Products';
$app_list_strings['moduleList']['AOS_Products_Quotes'] = 'Item baris';
$app_list_strings['moduleList']['AOS_Line_Item_Groups'] = 'Garis Item Kelompok';
$app_list_strings['moduleList']['AOS_Quotes'] = 'Quotes';
$app_list_strings['aos_quotes_type_dom'][''] = '';
$app_list_strings['aos_quotes_type_dom']['Analyst'] = 'Analyst';
$app_list_strings['aos_quotes_type_dom']['Competitor'] = 'Competitor';
$app_list_strings['aos_quotes_type_dom']['Customer'] = 'Customer';
$app_list_strings['aos_quotes_type_dom']['Integrator'] = 'Integrator';
$app_list_strings['aos_quotes_type_dom']['Investor'] = 'Investor';
$app_list_strings['aos_quotes_type_dom']['Partner'] = 'Partner';
$app_list_strings['aos_quotes_type_dom']['Press'] = 'Press';
$app_list_strings['aos_quotes_type_dom']['Prospect'] = 'Prospect';
$app_list_strings['aos_quotes_type_dom']['Reseller'] = 'Reseller';
$app_list_strings['aos_quotes_type_dom']['Other'] = 'Other';
$app_list_strings['template_ddown_c_list'][''] = '';
$app_list_strings['quote_stage_dom']['Draft'] = 'Draft';
$app_list_strings['quote_stage_dom']['Negotiation'] = 'Negosiasi';
$app_list_strings['quote_stage_dom']['Delivered'] = 'Terkirim';
$app_list_strings['quote_stage_dom']['On Hold'] = 'Ditahan';
$app_list_strings['quote_stage_dom']['Confirmed'] = 'Konfirmasi';
$app_list_strings['quote_stage_dom']['Closed Accepted'] = 'Berakhir Diterima';
$app_list_strings['quote_stage_dom']['Closed Lost'] = 'Closed Lost';
$app_list_strings['quote_stage_dom']['Closed Dead'] = 'Berakhir Tidak Dilanjutkan';
$app_list_strings['quote_term_dom']['Net 15'] = 'Nett 15';
$app_list_strings['quote_term_dom']['Net 30'] = 'Nett 30';
$app_list_strings['quote_term_dom'][''] = '';
$app_list_strings['approval_status_dom']['Approved'] = 'Disetujui';
$app_list_strings['approval_status_dom']['Not Approved'] = 'Tidak Disetujui';
$app_list_strings['approval_status_dom'][''] = '';
$app_list_strings['vat_list']['0.0'] = '0%';
$app_list_strings['vat_list']['5.0'] = '5%';
$app_list_strings['vat_list']['7.5'] = '7.5%';
$app_list_strings['vat_list']['17.5'] = '17.5%';
$app_list_strings['vat_list']['20.0'] = '20%';
$app_list_strings['discount_list']['Percentage'] = 'Pct';
$app_list_strings['discount_list']['Amount'] = 'Jumlah';
$app_list_strings['aos_invoices_type_dom'][''] = '';
$app_list_strings['aos_invoices_type_dom']['Analyst'] = 'Analyst';
$app_list_strings['aos_invoices_type_dom']['Competitor'] = 'Competitor';
$app_list_strings['aos_invoices_type_dom']['Customer'] = 'Customer';
$app_list_strings['aos_invoices_type_dom']['Integrator'] = 'Integrator';
$app_list_strings['aos_invoices_type_dom']['Investor'] = 'Investor';
$app_list_strings['aos_invoices_type_dom']['Partner'] = 'Partner';
$app_list_strings['aos_invoices_type_dom']['Press'] = 'Press';
$app_list_strings['aos_invoices_type_dom']['Prospect'] = 'Prospect';
$app_list_strings['aos_invoices_type_dom']['Reseller'] = 'Reseller';
$app_list_strings['aos_invoices_type_dom']['Other'] = 'Other';
$app_list_strings['invoice_status_dom']['Paid'] = 'Dibayar';
$app_list_strings['invoice_status_dom']['Unpaid'] = 'Belum Dibayar';
$app_list_strings['invoice_status_dom']['Cancelled'] = 'Dibatalkan';
$app_list_strings['invoice_status_dom'][''] = '';
$app_list_strings['quote_invoice_status_dom']['Not Invoiced'] = 'Tidak Tertagih';
$app_list_strings['quote_invoice_status_dom']['Invoiced'] = 'Tertagih';
$app_list_strings['product_code_dom']['XXXX'] = 'XXXX';
$app_list_strings['product_code_dom']['YYYY'] = 'YYYY';
$app_list_strings['product_category_dom']['Laptops'] = 'Laptop';
$app_list_strings['product_category_dom']['Desktops'] = 'Desktop';
$app_list_strings['product_category_dom'][''] = '';
$app_list_strings['product_type_dom']['Good'] = 'Bagus';
$app_list_strings['product_type_dom']['Service'] = 'Pelayanan';
$app_list_strings['product_quote_parent_type_dom']['AOS_Quotes'] = 'Quotes';
$app_list_strings['product_quote_parent_type_dom']['AOS_Invoices'] = 'Faktur';
$app_list_strings['product_quote_parent_type_dom']['AOS_Contracts'] = 'Contracts';
$app_list_strings['pdf_template_type_dom']['AOS_Quotes'] = 'Quotes';
$app_list_strings['pdf_template_type_dom']['AOS_Invoices'] = 'Faktur';
$app_list_strings['pdf_template_type_dom']['AOS_Contracts'] = 'Contracts';
$app_list_strings['pdf_template_type_dom']['Accounts'] = 'Akun';
$app_list_strings['pdf_template_type_dom']['Contacts'] = 'Contacts';
$app_list_strings['pdf_template_type_dom']['Leads'] = 'Leads';
$app_list_strings['pdf_template_sample_dom'][''] = '';
$app_list_strings['contract_status_list']['Not Started'] = 'Not Started';
$app_list_strings['contract_status_list']['In Progress'] = 'In Progress';
$app_list_strings['contract_status_list']['Signed'] = 'Ditandatangani';
$app_list_strings['contract_type_list']['Type'] = 'Tipe';
$app_strings['LBL_PRINT_AS_PDF'] = 'Cetak sebagai PDF [Alt+P]';
$app_strings['LBL_SELECT_TEMPLATE'] = 'Silakan Pilih sebuah Template';
$app_strings['LBL_NO_TEMPLATE'] = 'ERROR\nTidak ditemukan pola.\nSilakan buat pola di modul pola PDF';

//aow
$app_list_strings['moduleList']['AOW_WorkFlow'] = 'Alur kerja';
$app_list_strings['moduleList']['AOW_Conditions'] = 'Kondisi Alur Kerja';
$app_list_strings['moduleList']['AOW_Processed'] = 'Proses Audit';
$app_list_strings['moduleList']['AOW_Actions'] = 'Tindakan Alur Kerja';
$app_list_strings['aow_status_list']['Active'] = 'Active';
$app_list_strings['aow_status_list']['Inactive'] = 'Inactive';
$app_list_strings['aow_operator_list']['Equal_To'] = 'Sama dengan';
$app_list_strings['aow_operator_list']['Not_Equal_To'] = 'Tidak Sama Dengan';
$app_list_strings['aow_operator_list']['Greater_Than'] = 'Lebih besar dari';
$app_list_strings['aow_operator_list']['Less_Than'] = 'Kurang dari';
$app_list_strings['aow_operator_list']['Greater_Than_or_Equal_To'] = 'Lebih Besar Daripada atau Sama Dengan';
$app_list_strings['aow_operator_list']['Less_Than_or_Equal_To'] = 'Kurang Dari atau Sama Dengan';
$app_list_strings['aow_operator_list']['Contains'] = 'Contains';
$app_list_strings['aow_operator_list']['Starts_With'] = 'Mulai Dengan';
$app_list_strings['aow_operator_list']['Ends_With'] = 'Berakhir Dengan';
$app_list_strings['aow_operator_list']['is_null'] = 'Null';
$app_list_strings['aow_process_status_list']['Complete'] = 'Complete';
$app_list_strings['aow_process_status_list']['Running'] = 'Berjalan';
$app_list_strings['aow_process_status_list']['Pending'] = 'Pending';
$app_list_strings['aow_process_status_list']['Failed'] = 'Failed';
$app_list_strings['aow_condition_operator_list']['And'] = 'And';
$app_list_strings['aow_condition_operator_list']['OR'] = 'OR';
$app_list_strings['aow_condition_type_list']['Value'] = 'Value';
$app_list_strings['aow_condition_type_list']['Field'] = 'Field';
$app_list_strings['aow_condition_type_list']['Any_Change'] = 'Perubahan';
$app_list_strings['aow_condition_type_list']['SecurityGroup'] = 'Di Grup Keamanan';
$app_list_strings['aow_condition_type_list']['Date'] = 'Date';
$app_list_strings['aow_condition_type_list']['Multi'] = 'Salah satu';
$app_list_strings['aow_action_type_list']['Value'] = 'Value';
$app_list_strings['aow_action_type_list']['Field'] = 'Field';
$app_list_strings['aow_action_type_list']['Date'] = 'Date';
$app_list_strings['aow_action_type_list']['Round_Robin'] = 'Round Robin';
$app_list_strings['aow_action_type_list']['Least_Busy'] = 'Sedikit Sibuk';
$app_list_strings['aow_action_type_list']['Random'] = 'Acak';
$app_list_strings['aow_rel_action_type_list']['Value'] = 'Value';
$app_list_strings['aow_rel_action_type_list']['Field'] = 'Field';
$app_list_strings['aow_date_type_list'][''] = '';
$app_list_strings['aow_date_type_list']['minute'] = 'Minutes';
$app_list_strings['aow_date_type_list']['hour'] = 'Hours';
$app_list_strings['aow_date_type_list']['day'] = 'Days';
$app_list_strings['aow_date_type_list']['week'] = 'Weeks';
$app_list_strings['aow_date_type_list']['month'] = 'Months';
$app_list_strings['aow_date_type_list']['year'] = 'Tahun';
$app_list_strings['aow_date_type_list']['business_hours'] = 'Jam kerja';
$app_list_strings['aow_date_options']['now'] = 'Sekarang';
$app_list_strings['aow_date_options']['today'] = 'Today';
$app_list_strings['aow_date_options']['field'] = 'Bagian Ini';
$app_list_strings['aow_date_operator']['now'] = '';
$app_list_strings['aow_date_operator']['plus'] = '+';
$app_list_strings['aow_date_operator']['minus'] = '-';
$app_list_strings['aow_assign_options']['all'] = 'Semua Pengguna';
$app_list_strings['aow_assign_options']['role'] = 'Semua Pengguna dalam Tugas';
$app_list_strings['aow_assign_options']['security_group'] = 'SEMUA Pengguna di Grup Keamanan';
$app_list_strings['aow_email_type_list']['Email Address'] = 'Surel';
$app_list_strings['aow_email_type_list']['Record Email'] = 'Rekam Email';
$app_list_strings['aow_email_type_list']['Related Field'] = 'Bidang Terkait';
$app_list_strings['aow_email_type_list']['Specify User'] = 'User';
$app_list_strings['aow_email_type_list']['Users'] = 'Users';
$app_list_strings['aow_email_to_list']['to'] = 'To';
$app_list_strings['aow_email_to_list']['cc'] = 'Cc';
$app_list_strings['aow_email_to_list']['bcc'] = 'Bcc';
$app_list_strings['aow_run_on_list']['All_Records'] = 'Semua Rekaman';
$app_list_strings['aow_run_on_list']['New_Records'] = 'Rekaman Baru';
$app_list_strings['aow_run_on_list']['Modified_Records'] = 'Rekaman Yang Sudah Dimodifikasi';
$app_list_strings['aow_run_when_list']['Always'] = 'Selalu';
$app_list_strings['aow_run_when_list']['On_Save'] = 'Hanya Di Simpan';
$app_list_strings['aow_run_when_list']['In_Scheduler'] = 'Hanya Di Penjadwal';

//gant
$app_list_strings['moduleList']['AM_ProjectTemplates'] = 'Proyek - Contoh';
$app_list_strings['moduleList']['AM_TaskTemplates'] = 'Template Tugas Proyek';
$app_list_strings['relationship_type_list']['FS'] = 'Selesaikan untuk Memulai';
$app_list_strings['relationship_type_list']['SS'] = 'Mulai untuk Memulai';
$app_list_strings['duration_unit_dom']['Days'] = 'Days';
$app_list_strings['duration_unit_dom']['Hours'] = 'Hours';
$app_strings['LBL_GANTT_BUTTON_LABEL'] = 'Lihat Gantt';
$app_strings['LBL_DETAIL_BUTTON_LABEL'] = 'Lihat Detil';
$app_strings['LBL_CREATE_PROJECT'] = 'Buat Proyek';

//gmaps
$app_strings['LBL_MAP'] = 'Peta';

$app_strings['LBL_JJWG_MAPS_LNG'] = 'Garis Bujur';
$app_strings['LBL_JJWG_MAPS_LAT'] = 'Garis Lintang';
$app_strings['LBL_JJWG_MAPS_GEOCODE_STATUS'] = 'Status Geokode';
$app_strings['LBL_JJWG_MAPS_ADDRESS'] = 'Alamat';

$app_list_strings['moduleList']['jjwg_Maps'] = 'Peta';
$app_list_strings['moduleList']['jjwg_Markers'] = 'Penanda - Peta';
$app_list_strings['moduleList']['jjwg_Areas'] = 'Area - Peta';
$app_list_strings['moduleList']['jjwg_Address_Cache'] = 'Alamat Cache - Peta';

$app_list_strings['moduleList']['jjwp_Partners'] = 'Partners JJWP';

$app_list_strings['map_unit_type_list']['mi'] = 'Mil';
$app_list_strings['map_unit_type_list']['km'] = 'Kilometer';

$app_list_strings['map_module_type_list']['Accounts'] = 'Akun';
$app_list_strings['map_module_type_list']['Contacts'] = 'Contacts';
$app_list_strings['map_module_type_list']['Cases'] = 'Cases';
$app_list_strings['map_module_type_list']['Leads'] = 'Leads';
$app_list_strings['map_module_type_list']['Meetings'] = 'Meetings';
$app_list_strings['map_module_type_list']['Opportunities'] = 'Opportunities';
$app_list_strings['map_module_type_list']['Project'] = 'Projects';
$app_list_strings['map_module_type_list']['Prospects'] = 'Targets';

$app_list_strings['map_relate_type_list']['Accounts'] = 'Akun';
$app_list_strings['map_relate_type_list']['Contacts'] = 'Contact';
$app_list_strings['map_relate_type_list']['Cases'] = 'Case';
$app_list_strings['map_relate_type_list']['Leads'] = 'Pengantar';
$app_list_strings['map_relate_type_list']['Meetings'] = 'Meeting';
$app_list_strings['map_relate_type_list']['Opportunities'] = 'Opportunity';
$app_list_strings['map_relate_type_list']['Project'] = 'Project';
$app_list_strings['map_relate_type_list']['Prospects'] = 'Target';

$app_list_strings['marker_image_list']['accident'] = 'Kecelakaan';
$app_list_strings['marker_image_list']['administration'] = 'Administration';
$app_list_strings['marker_image_list']['agriculture'] = 'Pertanian';
$app_list_strings['marker_image_list']['aircraft_small'] = 'Pesawat Kecil';
$app_list_strings['marker_image_list']['airplane_tourism'] = 'Pesawat Wisata';
$app_list_strings['marker_image_list']['airport'] = 'Bandara';
$app_list_strings['marker_image_list']['amphitheater'] = 'Amphitheater';
$app_list_strings['marker_image_list']['apartment'] = 'Apartemen';
$app_list_strings['marker_image_list']['aquarium'] = 'Akuarium';
$app_list_strings['marker_image_list']['arch'] = 'Busur';
$app_list_strings['marker_image_list']['atm'] = 'Atm';
$app_list_strings['marker_image_list']['audio'] = 'Audio';
$app_list_strings['marker_image_list']['bank'] = 'Bank';
$app_list_strings['marker_image_list']['bank_euro'] = 'Bank Euro';
$app_list_strings['marker_image_list']['bank_pound'] = 'Bank Pond';
$app_list_strings['marker_image_list']['bar'] = 'Bar';
$app_list_strings['marker_image_list']['beach'] = 'Pantai';
$app_list_strings['marker_image_list']['beautiful'] = 'Cantik';
$app_list_strings['marker_image_list']['bicycle_parking'] = 'Tempat Parkir Sepeda';
$app_list_strings['marker_image_list']['big_city'] = 'Kota Besar';
$app_list_strings['marker_image_list']['bridge'] = 'Jembatan';
$app_list_strings['marker_image_list']['bridge_modern'] = 'Jembatan Modern';
$app_list_strings['marker_image_list']['bus'] = 'Bus';
$app_list_strings['marker_image_list']['cable_car'] = 'Kereta Gantung';
$app_list_strings['marker_image_list']['car'] = 'Mobil';
$app_list_strings['marker_image_list']['car_rental'] = 'Mobil Sewa';
$app_list_strings['marker_image_list']['carrepair'] = 'Bengkel';
$app_list_strings['marker_image_list']['castle'] = 'Istana';
$app_list_strings['marker_image_list']['cathedral'] = 'Katedral';
$app_list_strings['marker_image_list']['chapel'] = 'Kapel';
$app_list_strings['marker_image_list']['church'] = 'Gereja';
$app_list_strings['marker_image_list']['city_square'] = 'Alun-alun';
$app_list_strings['marker_image_list']['cluster'] = 'Gugusan';
$app_list_strings['marker_image_list']['cluster_2'] = 'Gugusan 2';
$app_list_strings['marker_image_list']['cluster_3'] = 'Gugusan 3';
$app_list_strings['marker_image_list']['cluster_4'] = 'Gugusan 4';
$app_list_strings['marker_image_list']['cluster_5'] = 'Gugusan 5';
$app_list_strings['marker_image_list']['coffee'] = 'Kopi';
$app_list_strings['marker_image_list']['community_centre'] = 'Pusat Komunitas';
$app_list_strings['marker_image_list']['company'] = 'Perusahaan';
$app_list_strings['marker_image_list']['conference'] = 'Conference';
$app_list_strings['marker_image_list']['construction'] = 'Construction';
$app_list_strings['marker_image_list']['convenience'] = 'Kenyamanan';
$app_list_strings['marker_image_list']['court'] = 'Pengadilan';
$app_list_strings['marker_image_list']['cruise'] = 'Kapal Pesiar';
$app_list_strings['marker_image_list']['currency_exchange'] = 'Penukaran Mata Uang';
$app_list_strings['marker_image_list']['customs'] = 'Bea Cukai';
$app_list_strings['marker_image_list']['cycling'] = 'Bersepeda';
$app_list_strings['marker_image_list']['dam'] = 'Bendungan';
$app_list_strings['marker_image_list']['dentist'] = 'Dokter Gigi';
$app_list_strings['marker_image_list']['deptartment_store'] = 'Pusat Perbelanjaan';
$app_list_strings['marker_image_list']['disability'] = 'Penyandang Cacat';
$app_list_strings['marker_image_list']['disabled_parking'] = 'Parkir Penyandang Cacat';
$app_list_strings['marker_image_list']['doctor'] = 'Dokter';
$app_list_strings['marker_image_list']['dog_leash'] = 'Tali Anjing';
$app_list_strings['marker_image_list']['down'] = 'Bawah';
$app_list_strings['marker_image_list']['down_left'] = 'Kiri Bawah';
$app_list_strings['marker_image_list']['down_right'] = 'Kanan Bawah';
$app_list_strings['marker_image_list']['down_then_left'] = 'Bawah Kemudian Kiri';
$app_list_strings['marker_image_list']['down_then_right'] = 'Bawah Kemudian Kanan';
$app_list_strings['marker_image_list']['drugs'] = 'Obat-obatan';
$app_list_strings['marker_image_list']['elevator'] = 'Tangga Berjalan';
$app_list_strings['marker_image_list']['embassy'] = 'Kedutaan Besar';
$app_list_strings['marker_image_list']['expert'] = 'Ahli';
$app_list_strings['marker_image_list']['factory'] = 'Pabrik';
$app_list_strings['marker_image_list']['falling_rocks'] = 'Batu Berjatuhan';
$app_list_strings['marker_image_list']['fast_food'] = 'Makanan Cepat Saji';
$app_list_strings['marker_image_list']['festival'] = 'Festival';
$app_list_strings['marker_image_list']['fjord'] = 'Fjord';
$app_list_strings['marker_image_list']['forest'] = 'Hutan';
$app_list_strings['marker_image_list']['fountain'] = 'Air Mancur';
$app_list_strings['marker_image_list']['friday'] = 'Friday';
$app_list_strings['marker_image_list']['garden'] = 'Kebun';
$app_list_strings['marker_image_list']['gas_station'] = 'Stasiun Gas';
$app_list_strings['marker_image_list']['geyser'] = 'Mata Air Panas';
$app_list_strings['marker_image_list']['gifts'] = 'Hadiah';
$app_list_strings['marker_image_list']['gourmet'] = 'Gourmet';
$app_list_strings['marker_image_list']['grocery'] = 'Grosir';
$app_list_strings['marker_image_list']['hairsalon'] = 'Salon Rambut';
$app_list_strings['marker_image_list']['helicopter'] = 'Helikopter';
$app_list_strings['marker_image_list']['highway'] = 'Jalan Tol';
$app_list_strings['marker_image_list']['historical_quarter'] = 'Tempat Bersejarah';
$app_list_strings['marker_image_list']['home'] = 'Home';
$app_list_strings['marker_image_list']['hospital'] = 'Rumah Sakit';
$app_list_strings['marker_image_list']['hostel'] = 'Hostel';
$app_list_strings['marker_image_list']['hotel'] = 'Hotel';
$app_list_strings['marker_image_list']['hotel_1_star'] = 'Hotel Bintang 1';
$app_list_strings['marker_image_list']['hotel_2_stars'] = 'Hotel Bintang 2';
$app_list_strings['marker_image_list']['hotel_3_stars'] = 'Hotel Bintang 3';
$app_list_strings['marker_image_list']['hotel_4_stars'] = 'Hotel Bintang 4';
$app_list_strings['marker_image_list']['hotel_5_stars'] = 'Hotel Bintang 5';
$app_list_strings['marker_image_list']['info'] = 'Info';
$app_list_strings['marker_image_list']['justice'] = 'Peradilan';
$app_list_strings['marker_image_list']['lake'] = 'Danau';
$app_list_strings['marker_image_list']['laundromat'] = 'Laundromat';
$app_list_strings['marker_image_list']['left'] = 'Ke Kiri';
$app_list_strings['marker_image_list']['left_then_down'] = 'Ke Kiri kemudian Kebawah';
$app_list_strings['marker_image_list']['left_then_up'] = 'Ke Kiri Kemudian Angkat';
$app_list_strings['marker_image_list']['library'] = 'Perpustakaan';
$app_list_strings['marker_image_list']['lighthouse'] = 'Mercusuar';
$app_list_strings['marker_image_list']['liquor'] = 'Minuman Keras';
$app_list_strings['marker_image_list']['lock'] = 'Kunci';
$app_list_strings['marker_image_list']['main_road'] = 'Jalan Utama';
$app_list_strings['marker_image_list']['massage'] = 'Pesan';
$app_list_strings['marker_image_list']['mobile_phone_tower'] = 'Menara Ponsel';
$app_list_strings['marker_image_list']['modern_tower'] = 'Tower Modern';
$app_list_strings['marker_image_list']['monastery'] = 'Biara';
$app_list_strings['marker_image_list']['monday'] = 'Monday';
$app_list_strings['marker_image_list']['monument'] = 'Monumen';
$app_list_strings['marker_image_list']['mosque'] = 'Mesjid';
$app_list_strings['marker_image_list']['motorcycle'] = 'Sepeda Motor';
$app_list_strings['marker_image_list']['museum'] = 'Musium';
$app_list_strings['marker_image_list']['music_live'] = 'Live Music';
$app_list_strings['marker_image_list']['oil_pump_jack'] = 'Pompa Minyak';
$app_list_strings['marker_image_list']['pagoda'] = 'Pagoda';
$app_list_strings['marker_image_list']['palace'] = 'Keraton';
$app_list_strings['marker_image_list']['panoramic'] = 'Panorama';
$app_list_strings['marker_image_list']['park'] = 'Parkir';
$app_list_strings['marker_image_list']['park_and_ride'] = 'Parkir Dan Mengendarai';
$app_list_strings['marker_image_list']['parking'] = 'Tempat Parkir';
$app_list_strings['marker_image_list']['photo'] = 'Photo';
$app_list_strings['marker_image_list']['picnic'] = 'Piknik';
$app_list_strings['marker_image_list']['places_unvisited'] = 'Tempat Yang Belum Dikunjungi';
$app_list_strings['marker_image_list']['places_visited'] = 'Tempat Yang Telah Dikunjungi';
$app_list_strings['marker_image_list']['playground'] = 'Tempat Bermain';
$app_list_strings['marker_image_list']['police'] = 'Polisi';
$app_list_strings['marker_image_list']['port'] = 'Pelabuhan';
$app_list_strings['marker_image_list']['postal'] = 'Pos';
$app_list_strings['marker_image_list']['power_line_pole'] = 'Tiang Listrik';
$app_list_strings['marker_image_list']['power_plant'] = 'Pembangkit Listrik';
$app_list_strings['marker_image_list']['power_substation'] = 'Gardu Daya';
$app_list_strings['marker_image_list']['public_art'] = 'Seni Publik';
$app_list_strings['marker_image_list']['rain'] = 'Hujan';
$app_list_strings['marker_image_list']['real_estate'] = 'Perumahan';
$app_list_strings['marker_image_list']['regroup'] = 'Susun Ulang';
$app_list_strings['marker_image_list']['resort'] = 'Resort';
$app_list_strings['marker_image_list']['restaurant'] = 'Restoran';
$app_list_strings['marker_image_list']['restaurant_african'] = 'Restoran Afrika';
$app_list_strings['marker_image_list']['restaurant_barbecue'] = 'Restoran Barbekyu';
$app_list_strings['marker_image_list']['restaurant_buffet'] = 'Restoran Prasmanan';
$app_list_strings['marker_image_list']['restaurant_chinese'] = 'Restoran Tiongkok';
$app_list_strings['marker_image_list']['restaurant_fish'] = 'Restoran Ikan';
$app_list_strings['marker_image_list']['restaurant_fish_chips'] = 'Restoran Keripik Ikan';
$app_list_strings['marker_image_list']['restaurant_gourmet'] = 'Restoran Gourmet';
$app_list_strings['marker_image_list']['restaurant_greek'] = 'Restoran Yunani';
$app_list_strings['marker_image_list']['restaurant_indian'] = 'Restoran India';
$app_list_strings['marker_image_list']['restaurant_italian'] = 'Restoran Italia';
$app_list_strings['marker_image_list']['restaurant_japanese'] = 'Restoran Jepang';
$app_list_strings['marker_image_list']['restaurant_kebab'] = 'Restoran Kebab';
$app_list_strings['marker_image_list']['restaurant_korean'] = 'Restoran Korea';
$app_list_strings['marker_image_list']['restaurant_mediterranean'] = 'Restoran Mediterania';
$app_list_strings['marker_image_list']['restaurant_mexican'] = 'Restoran Meksiko';
$app_list_strings['marker_image_list']['restaurant_romantic'] = 'Restoran Romantis';
$app_list_strings['marker_image_list']['restaurant_thai'] = 'Restoran Thailand';
$app_list_strings['marker_image_list']['restaurant_turkish'] = 'Restoran Turki';
$app_list_strings['marker_image_list']['right'] = 'Kanan';
$app_list_strings['marker_image_list']['right_then_down'] = 'Kanan Kemudian Bawah';
$app_list_strings['marker_image_list']['right_then_up'] = 'Kanan Kemudian Atas';
$app_list_strings['marker_image_list']['saturday'] = 'Saturday';
$app_list_strings['marker_image_list']['school'] = 'Sekolah';
$app_list_strings['marker_image_list']['shopping_mall'] = 'Mall';
$app_list_strings['marker_image_list']['shore'] = 'Pantai';
$app_list_strings['marker_image_list']['sight'] = 'Pemandangan';
$app_list_strings['marker_image_list']['small_city'] = 'Kota Kecil';
$app_list_strings['marker_image_list']['snow'] = 'Salju';
$app_list_strings['marker_image_list']['spaceport'] = 'Landasan Kapal Angkasa';
$app_list_strings['marker_image_list']['speed_100'] = 'Kecepatan 100';
$app_list_strings['marker_image_list']['speed_110'] = 'Kecepatan 110';
$app_list_strings['marker_image_list']['speed_120'] = 'Kecepatan 120';
$app_list_strings['marker_image_list']['speed_130'] = 'Kecepatan 130';
$app_list_strings['marker_image_list']['speed_20'] = 'Kecepatan 20';
$app_list_strings['marker_image_list']['speed_30'] = 'Kecepatan 30';
$app_list_strings['marker_image_list']['speed_40'] = 'Kecepatan 40';
$app_list_strings['marker_image_list']['speed_50'] = 'Kecepatan 50';
$app_list_strings['marker_image_list']['speed_60'] = 'Kecepatan 60';
$app_list_strings['marker_image_list']['speed_70'] = 'Kecepatan 70';
$app_list_strings['marker_image_list']['speed_80'] = 'Kecepatan 80';
$app_list_strings['marker_image_list']['speed_90'] = 'Kecepatan 90';
$app_list_strings['marker_image_list']['speed_hump'] = 'Pukulan Cepat';
$app_list_strings['marker_image_list']['stadium'] = 'Stadion';
$app_list_strings['marker_image_list']['statue'] = 'Patung';
$app_list_strings['marker_image_list']['steam_train'] = 'Kereta Uap';
$app_list_strings['marker_image_list']['stop'] = 'Berhenti';
$app_list_strings['marker_image_list']['stoplight'] = 'Lampu Lalu Lintas';
$app_list_strings['marker_image_list']['subway'] = 'Kereta Bawah Tanah';
$app_list_strings['marker_image_list']['sun'] = 'Minggu';
$app_list_strings['marker_image_list']['sunday'] = 'Sunday';
$app_list_strings['marker_image_list']['supermarket'] = 'Swalayan';
$app_list_strings['marker_image_list']['synagogue'] = 'Sinagoga';
$app_list_strings['marker_image_list']['tapas'] = 'Tapas';
$app_list_strings['marker_image_list']['taxi'] = 'Taksi';
$app_list_strings['marker_image_list']['taxiway'] = 'Jalur Taksi';
$app_list_strings['marker_image_list']['teahouse'] = 'Kedai Teh';
$app_list_strings['marker_image_list']['telephone'] = 'Telepon';
$app_list_strings['marker_image_list']['temple_hindu'] = 'Candi Hindu';
$app_list_strings['marker_image_list']['terrace'] = 'Teras';
$app_list_strings['marker_image_list']['text'] = 'Tulisan';
$app_list_strings['marker_image_list']['theater'] = 'Teater';
$app_list_strings['marker_image_list']['theme_park'] = 'Taman Hiburan';
$app_list_strings['marker_image_list']['thursday'] = 'Thursday';
$app_list_strings['marker_image_list']['toilets'] = 'Toilet';
$app_list_strings['marker_image_list']['toll_station'] = 'Stasiun Tol';
$app_list_strings['marker_image_list']['tower'] = 'Menara';
$app_list_strings['marker_image_list']['traffic_enforcement_camera'] = 'Penegakan Lalu Lintas Kamera';
$app_list_strings['marker_image_list']['train'] = 'Kereta Api';
$app_list_strings['marker_image_list']['tram'] = 'Trem';
$app_list_strings['marker_image_list']['truck'] = 'Truk';
$app_list_strings['marker_image_list']['tuesday'] = 'Tuesday';
$app_list_strings['marker_image_list']['tunnel'] = 'Terowongan';
$app_list_strings['marker_image_list']['turn_left'] = 'Belok Kiri';
$app_list_strings['marker_image_list']['turn_right'] = 'Belok Kanan';
$app_list_strings['marker_image_list']['university'] = 'Universitas';
$app_list_strings['marker_image_list']['up'] = 'Atas';
$app_list_strings['marker_image_list']['up_left'] = 'Kiri Atas';
$app_list_strings['marker_image_list']['up_right'] = 'Kanan Atas';
$app_list_strings['marker_image_list']['up_then_left'] = 'Atas kemudian ke Kiri';
$app_list_strings['marker_image_list']['up_then_right'] = 'Atas kemudian ke Kanan';
$app_list_strings['marker_image_list']['vespa'] = 'Vespa';
$app_list_strings['marker_image_list']['video'] = 'Video';
$app_list_strings['marker_image_list']['villa'] = 'Vila';
$app_list_strings['marker_image_list']['water'] = 'Air';
$app_list_strings['marker_image_list']['waterfall'] = 'Air Terjun';
$app_list_strings['marker_image_list']['watermill'] = 'Kincir Air';
$app_list_strings['marker_image_list']['waterpark'] = 'Taman Air';
$app_list_strings['marker_image_list']['watertower'] = 'Tower Air';
$app_list_strings['marker_image_list']['wednesday'] = 'Wednesday';
$app_list_strings['marker_image_list']['wifi'] = 'Wifi';
$app_list_strings['marker_image_list']['wind_turbine'] = 'Turbin Angin';
$app_list_strings['marker_image_list']['windmill'] = 'Kincir Angin';
$app_list_strings['marker_image_list']['winery'] = 'Kilang Anggur';
$app_list_strings['marker_image_list']['work_office'] = 'Kantor';
$app_list_strings['marker_image_list']['world_heritage_site'] = 'Situs Warisan Dunia';
$app_list_strings['marker_image_list']['zoo'] = 'Kebun Binatang';

//Reschedule
$app_list_strings['call_reschedule_dom'][''] = '';
$app_list_strings['call_reschedule_dom']['Out of Office'] = 'Keluar Kantor';
$app_list_strings['call_reschedule_dom']['In a Meeting'] = 'Sedang Rapat';

$app_strings['LBL_RESCHEDULE_LABEL'] = 'Menjadwal ulang';
$app_strings['LBL_RESCHEDULE_TITLE'] = 'Harap masukkan informasi penjadwalan ulang';
$app_strings['LBL_RESCHEDULE_DATE'] = 'Tanggal:';
$app_strings['LBL_RESCHEDULE_REASON'] = 'Alasan:';
$app_strings['LBL_RESCHEDULE_ERROR1'] = 'Silakan pilih tanggal yang valid';
$app_strings['LBL_RESCHEDULE_ERROR2'] = 'Silakan pilih alasan';

$app_strings['LBL_RESCHEDULE_PANEL'] = 'Menjadwal ulang';
$app_strings['LBL_RESCHEDULE_HISTORY'] = 'Riwayat Panggilan';
$app_strings['LBL_RESCHEDULE_COUNT'] = 'Percobaan Panggilan';

//SecurityGroups
$app_list_strings['moduleList']['SecurityGroups'] = 'Manajemen Rangkaian Keamanan';
$app_strings['LBL_SECURITYGROUP'] = 'Grup Keamanan';
$app_strings['LBL_ROLE'] = 'Peran';

$app_list_strings['moduleList']['OutboundEmailAccounts'] = 'Outbound Akun Email';
$app_list_strings['moduleList']['ExternalOAuthConnection'] = 'Sambungan OAuth Eksternal';
$app_list_strings['moduleList']['ExternalOAuthProvider'] = 'Penyedia OAuth Eksternal';

//social
$app_strings['FACEBOOK_USER_C'] = 'Facebook';
$app_strings['TWITTER_USER_C'] = 'Twitter';
$app_strings['LBL_PANEL_SOCIAL_FEED'] = 'Detil Umpan Sosial';

$app_strings['LBL_SUBPANEL_FILTER_LABEL'] = 'Menyaring';

$app_strings['LBL_COLLECTION_TYPE'] = 'Type';

$app_strings['LBL_ADD_TAB'] = 'Tambahkan Label';
$app_strings['LBL_EDIT_TAB'] = 'Edit Tab';
$app_strings['LBL_SUITE_DASHBOARD'] = 'DASBOR SUITECRM';
$app_strings['LBL_ENTER_DASHBOARD_NAME'] = 'Masukkan Nama Dasbor:';
$app_strings['LBL_NUMBER_OF_COLUMNS'] = 'Jumlah Kolom:';
$app_strings['LBL_DELETE_DASHBOARD1'] = 'Apakah anda yakin anda ingin menghapus';
$app_strings['LBL_DELETE_DASHBOARD2'] = 'dasbor?';
$app_strings['LBL_ADD_DASHBOARD_PAGE'] = 'Tambahkan Halaman Dasbor';
$app_strings['LBL_DELETE_DASHBOARD_PAGE'] = 'Menghapus Saat Ini Halaman Dashboard';
$app_strings['LBL_RENAME_DASHBOARD_PAGE'] = 'Namai Halaman Dasbor';
$app_strings['LBL_SUITE_DASHBOARD_ACTIONS'] = 'TINDAKAN';

$app_list_strings['collection_temp_list'] = array(
    'Tasks' => 'Tasks',
    'Meetings' => 'Meetings',
    'Calls' => 'Calls',
    'Notes' => 'Notes',
    'Emails' => 'Email'
);

$app_list_strings['moduleList']['TemplateEditor'] = 'Editor Bagian Template';
$app_strings['LBL_CONFIRM_CANCEL_INLINE_EDITING'] = "Anda telah mengklik dari bidang yang sedang Anda sunting tanpa menyimpannya. Klik ok jika Anda dengan senang hati kehilangan perubahan Anda, atau batalkan jika Anda ingin terus pengeditan";
$app_strings['LBL_LOADING_ERROR_INLINE_EDITING'] = "Terjadi kesalahan saat memuat bidang. Sesi Anda mungkin sudah waktunya habis. Silahkan masuk lagi untuk memperbaikinya";

$app_list_strings['moduleList']['AOBH_BusinessHours'] = 'Jam kerja';
$app_list_strings['business_hours_list']['0'] = '12am';
$app_list_strings['business_hours_list']['1'] = '1am';
$app_list_strings['business_hours_list']['2'] = '2am';
$app_list_strings['business_hours_list']['3'] = '3am';
$app_list_strings['business_hours_list']['4'] = '4am';
$app_list_strings['business_hours_list']['5'] = '5am';
$app_list_strings['business_hours_list']['6'] = '6am';
$app_list_strings['business_hours_list']['7'] = '7am';
$app_list_strings['business_hours_list']['8'] = '8am';
$app_list_strings['business_hours_list']['9'] = '9am';
$app_list_strings['business_hours_list']['10'] = '10am';
$app_list_strings['business_hours_list']['11'] = '11am';
$app_list_strings['business_hours_list']['12'] = '12pm';
$app_list_strings['business_hours_list']['13'] = '1pm';
$app_list_strings['business_hours_list']['14'] = '2pm';
$app_list_strings['business_hours_list']['15'] = '3pm';
$app_list_strings['business_hours_list']['16'] = '4pm';
$app_list_strings['business_hours_list']['17'] = '5pm';
$app_list_strings['business_hours_list']['18'] = '6pm';
$app_list_strings['business_hours_list']['19'] = '7pm';
$app_list_strings['business_hours_list']['20'] = '8pm';
$app_list_strings['business_hours_list']['21'] = '9pm';
$app_list_strings['business_hours_list']['22'] = '10pm';
$app_list_strings['business_hours_list']['23'] = '11pm';
$app_list_strings['day_list']['Monday'] = 'Monday';
$app_list_strings['day_list']['Tuesday'] = 'Tuesday';
$app_list_strings['day_list']['Wednesday'] = 'Wednesday';
$app_list_strings['day_list']['Thursday'] = 'Thursday';
$app_list_strings['day_list']['Friday'] = 'Friday';
$app_list_strings['day_list']['Saturday'] = 'Saturday';
$app_list_strings['day_list']['Sunday'] = 'Sunday';
$app_list_strings['pdf_page_size_dom']['A4'] = 'A4';
$app_list_strings['pdf_page_size_dom']['Letter'] = 'Letter';
$app_list_strings['pdf_page_size_dom']['Legal'] = 'Legal';
$app_list_strings['pdf_orientation_dom']['Portrait'] = 'Portrait';
$app_list_strings['pdf_orientation_dom']['Landscape'] = 'Landscape';


$app_list_strings['moduleList']['SurveyResponses'] = 'Tanggapan Survei';
$app_list_strings['moduleList']['Surveys'] = 'Survei';
$app_list_strings['moduleList']['SurveyQuestionResponses'] = 'Tanggapan Pertanyaan Survei';
$app_list_strings['moduleList']['SurveyQuestions'] = 'Pertanyaan Survei';
$app_list_strings['moduleList']['SurveyQuestionOptions'] = 'Pilihan Pertanyaan Survei';
$app_list_strings['survey_status_list']['Draft'] = 'Draft';
$app_list_strings['survey_status_list']['Public'] = 'Umum';
$app_list_strings['survey_status_list']['Closed'] = 'Closed';
$app_list_strings['surveys_question_type']['Text'] = 'Tulisan';
$app_list_strings['surveys_question_type']['Textbox'] = 'Textbox';
$app_list_strings['surveys_question_type']['Checkbox'] = 'Checkbox';
$app_list_strings['surveys_question_type']['Radio'] = 'Radio';
$app_list_strings['surveys_question_type']['Dropdown'] = 'Dropdown';
$app_list_strings['surveys_question_type']['Multiselect'] = 'Multiselect';
$app_list_strings['surveys_question_type']['Matrix'] = 'Matriks';
$app_list_strings['surveys_question_type']['DateTime'] = 'DateTime';
$app_list_strings['surveys_question_type']['Date'] = 'Date';
$app_list_strings['surveys_question_type']['Scale'] = 'Skala';
$app_list_strings['surveys_question_type']['Rating'] = 'Rating';
$app_list_strings['surveys_matrix_options'][0] = 'Puas';
$app_list_strings['surveys_matrix_options'][1] = 'Tidak Puas bahkan dan Tidak Memuaskan';
$app_list_strings['surveys_matrix_options'][2] = 'Tidak Memuaskan';

$app_strings['LBL_OPT_IN_PENDING_EMAIL_NOT_SENT'] = 'Menunggu Konfirmasi ikut serta, Konfirmasi pilih tidak terkirim';
$app_strings['LBL_OPT_IN_PENDING_EMAIL_FAILED'] = 'Konfirmasi pilihan pada pengiriman surel gagal';
$app_strings['LBL_OPT_IN_PENDING_EMAIL_SENT'] = 'Menunggu Konfirmasi ikut serta, Konfirmasi pilih di kirim';
$app_strings['LBL_OPT_IN'] = 'Memilih masuk';
$app_strings['LBL_OPT_IN_CONFIRMED'] = 'Pilihan Dikonfirmasi di';
$app_strings['LBL_OPT_IN_OPT_OUT'] = 'Opted Out';
$app_strings['LBL_OPT_IN_INVALID'] = 'Tidak Valid';

/** @see SugarEmailAddress */
$app_list_strings['email_settings_opt_in_dom'] = array(
    'not-opt-in' => 'Disabled',
    'opt-in' => 'Ikut Serta',
    'confirmed-opt-in' => 'Keikutsertaan Dikonfirmasi'
);

$app_list_strings['email_confirmed_opt_in_dom'] = array(
    'not-opt-in' => 'Tidak diikutsertakan',
    'opt-in' => 'Keikutsertaan',
    'confirmed-opt-in' => 'Dikonfirmasi Keikutsertaan'
);

$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL'] = 'Konfirmasi memilih email telah ditambahkan ke antrean email untuk alamat email %s.
';
$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL_NOT_OPT_IN'] = 'Tidak dapat mengirim email ke alamat email %s, karena mereka tidak ikut serta.';
$app_strings['RESPONSE_SEND_CONFIRM_OPT_IN_EMAIL_MISSING_EMAIL_ADDRESS_ID'] = '%s alamat email tidak memiliki id yang benar. ';

$app_strings['ERR_TWO_FACTOR_FAILED'] = 'Dua faktor yang di autentikasi gagal';
$app_strings['ERR_TWO_FACTOR_CODE_SENT'] = 'Kode Dua Kode Otentikasi terkirim.';
$app_strings['ERR_TWO_FACTOR_CODE_FAILED'] = 'Kode Otentikasi Dua Faktor gagal terkirim.';
$app_strings['LBL_THANKS_FOR_SUBMITTING'] = 'Terima kasih telah mengirimkan minat anda.';

$app_strings['ERR_IP_CHANGE'] = 'Sesi Anda diakhiri karena ada perubahan signifikan pada alamat IP Anda';
$app_strings['ERR_RETURN'] = 'Kembali ke Beranda';


$app_list_strings['oauth2_grant_type_dom'] = array(
    'password' => 'Kata Sandi Disetujui',
    'client_credentials' => 'Kredensial Klien',
    'implicit' => 'Implisit',
    'authorization_code' => 'Kode otorisasi'
);

$app_list_strings['oauth2_duration_units'] = [
    'minute' => 'Menit',
    'hour' => 'Jam',
    'day' => 'days',
    'week' => 'minggu',
    'month' => 'bulan',
];

$app_list_strings['search_controllers'] = [
    'Search' => 'Pencarian (baru)',
    'UnifiedSearch' => 'Global Unified Search (legasi)'
];


$app_strings['LBL_DEFAULT_API_ERROR_TITLE'] = 'Kesalahan API JSON';
$app_strings['LBL_DEFAULT_API_ERROR_DETAIL'] = 'Terjadi kesalahan API JSON.';
$app_strings['LBL_API_EXCEPTION_DETAIL'] = 'Versi API: 8';
$app_strings['LBL_BAD_REQUEST_EXCEPTION_DETAIL'] = 'Pastikan Anda mengisi semua kolom yang diwajibkan';
$app_strings['LBL_EMPTY_BODY_EXCEPTION_DETAIL'] = 'API Json mengharapkan isi permintaan berupa JSON';
$app_strings['LBL_INVALID_JSON_API_REQUEST_EXCEPTION_DETAIL'] = 'Tidak dapat memvalidasi Permintaan Payload Api Json';
$app_strings['LBL_INVALID_JSON_API_RESPONSE_EXCEPTION_DETAIL'] = 'Tidak dapat memvalidasi Respons Payload Api Json';
$app_strings['LBL_MODULE_NOT_FOUND_EXCEPTION_DETAIL'] = 'API Json tidak dapat menemukan sumber daya';
$app_strings['LBL_NOT_ACCEPTABLE_EXCEPTION_DETAIL'] = 'API Json mengharapkan header "Terima" berupa application/vnd.api+json';
$app_strings['LBL_UNSUPPORTED_MEDIA_TYPE_EXCEPTION_DETAIL'] = 'API Json mengharapkan header "Jenis-Konten" berupa application/vnd.api+json';

$app_strings['MSG_BROWSER_NOTIFICATIONS_ENABLED'] = 'Notifikasi desktop telah diaktifkan untuk browser web ini.';
$app_strings['MSG_BROWSER_NOTIFICATIONS_DISABLED'] = 'Notifikasi desktop telah dinonaktifkan untuk browser web ini. Gunakan pengaturan browser untuk mengaktifkannya kembali.';
$app_strings['MSG_BROWSER_NOTIFICATIONS_UNSUPPORTED'] = 'Peramban ini tidak mendukung notifikasi desktop.';

$app_strings['LBL_GOOGLE_SYNC_ERR'] = 'Sinkronisasi Google SuiteCRM - KESALAHAN';
$app_strings['LBL_THERE_WAS_AN_ERR'] = 'Terjadi kesalahan: ';
$app_strings['LBL_CLICK_HERE'] = 'Klik disini';
$app_strings['LBL_TO_CONTINUE'] = ' untuk melanjutkan.';
$app_strings['LBL_OPT_OUT'] = 'Opsi Keluar';
$app_strings['LBL_INVALID_EMAIL'] = 'Tidak Valid';
$app_strings['LBL_PRIMARY'] = 'Primary';
$app_strings['LBL_EMAIL_ADDRESS'] = 'Alamat Surel';

$app_strings['IMAP_HANDLER_ERROR'] = 'KESALAHAN: {error}; kunci: "{key}".';
$app_strings['IMAP_HANDLER_SUCCESS'] = 'OK: pengaturan tes diubah ke "{key}"';
$app_strings['IMAP_HANDLER_ERROR_INVALID_REQUEST'] = 'Permintaan tidak valid, gunakan nilai "{var}".';
$app_strings['IMAP_HANDLER_ERROR_UNKNOWN_BY_KEY'] = 'Kesalahan tidak terduga terjadi, kunci "{key}" tidak tersimpan.';
$app_strings['IMAP_HANDLER_ERROR_NO_TEST_SET'] = 'Pengaturan tes tidak ada.';
$app_strings['IMAP_HANDLER_ERROR_NO_KEY'] = 'Kunci tidak ditemukan.';
$app_strings['IMAP_HANDLER_ERROR_KEY_SAVE'] = 'Kesalahan kunci penyimpanan.';
$app_strings['IMAP_HANDLER_ERROR_UNKNOWN'] = 'Kesalahan tidak diketahui';
$app_strings['LBL_SEARCH_TITLE']                   = 'Search';
$app_strings['LBL_SEARCH_TEXT_FIELD_TITLE_ATTR']   = 'Masukkan Kriteria Pencarian';
$app_strings['LBL_SEARCH_SUBMIT_FIELD_TITLE_ATTR'] = 'Search';
$app_strings['LBL_SEARCH_SUBMIT_FIELD_VALUE']      = 'Search';
$app_strings['LBL_SEARCH_QUERY']                   = 'Kueri pencarian: ';
$app_strings['LBL_SEARCH_RESULTS_PER_PAGE']        = 'Results per module: ';
$app_strings['LBL_SEARCH_ENGINE']                  = 'Mesin: ';
$app_strings['LBL_SEARCH_TOTAL'] = 'Total pencarian: ';
$app_strings['LBL_SEARCH_PREV'] = 'Previous';
$app_strings['LBL_SEARCH_NEXT'] = 'Next';
$app_strings['LBL_SEARCH_PAGE'] = 'Halaman ';
$app_strings['LBL_SEARCH_OF'] = ' dari ';
$app_strings['LBL_INSIGHTS'] = 'Wawasan';
$app_strings['LBL_CHARTS'] = 'Charts';
$app_strings['LBL_CHART_NOT_FOUND'] = 'Bagan tidak ditemukan';
$app_strings['LBL_NO_DATA'] = 'Tidak Ada Data';
$app_strings['LBL_ERROR_FETCHING_METADATA'] = 'Terjadi kesalahan saat mengambil metadata';
$app_strings['LBL_TOTAL'] = 'Total';
$app_strings['LBL_ACTIONS'] = 'Actions';
$app_strings['LBL_SELECT_SUBPANEL_BANNER'] = 'Pilih subpanel yang ingin dilihat';
$app_strings['LBL_SELECT_ITEM'] = 'Pilih item';
$app_strings['LBL_ITEMS_SELECTED'] = 'items selected';
$app_strings['LBL_WIDGET_NOT_FOUND'] = 'Widget tidak ditemukan';
$app_strings['LBL_BAD_CONFIG'] = 'Konfigurasi salah';
$app_strings['LBL_CONFIG_BAD_CONTEXT'] = 'Konfigurasi salah: konteks tidak dikonfigurasi dengan benar';
$app_strings['LBL_CONFIG_NO_CONFIG'] = 'Konfigurasi salah: konfigurasi hilang';
$app_strings['LBL_CONFIG_NO_STATISTICS_KEY'] = 'Konfigurasi salah: kunci statistik hilang';
$app_strings['LBL_STATISTIC_ERROR'] = 'Kesalahan pemuatan statistik';
$app_strings['LBL_STATISTIC_ERROR_DESC'] = 'Kesalahan pemuatan statistik';
$app_strings['LBL_STATISTIC_ERROR_DESC_TOOLTIP'] = 'Kesalahan pemuatan statistik. Hubungi administrator Anda';
$app_strings['LBL_AVERAGE_CLOSED_WON_PER_YEAR'] = 'Kesempatan Menang Rata-rata Per Tahun';
$app_strings['LBL_OPPORTUNITIES_TOTAL'] = 'Nilai Kesempatan Total';
$app_strings['LBL_CASE_TOTAL_DAYS_OPEN'] = 'Total Hari Buka';
$app_strings['LBL_DAYS_OPEN'] = 'Hari Buka';
$app_strings['LBL_DAYS_IN_SALE_STAGE'] = 'DAY(S) THIS OPPORTUNITY HAS BEEN AT THIS SALES STAGE';
$app_strings['LBL_STAT_DAYS'] = 'Hari';
$app_strings['LBL_CLOSED_PER_YEAR'] = 'Tutup Per Tahun';
$app_strings['LBL_WAS_OPEN'] = 'Kasus ini Dibuka Selama';
$app_strings['LBL_HAS_BEEN_OPEN'] = 'Kasus ini telah Dibuka Selama';
$app_strings['LBL_NUMBER_OF_CASES_PER_ACCOUNT'] = 'Jumlah Kasus Per Akun';
$app_strings['LBL_TOTAL_CASES_FOR_THIS_ACCOUNT'] = 'Total Cases For This Account';
$app_strings['LBL_NONE_OUTSTANDING'] = 'Tidak ada';
$app_strings['LBL_VALIDATION_ERROR_REQUIRED'] = 'Bidang wajib diisi tidak ada: {{fields.field.label}}';
$app_strings['LBL_VALIDATION_ERROR_CURRENCY_FORMAT'] = "Format mata uang tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_INT_FORMAT'] = "Format int tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_FLOAT_FORMAT'] = "Format mengambang tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_DATE_FORMAT'] = "Format tanggal tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_DATETIME_FORMAT'] = "Format tanggalwaktu tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_UNSUBSCRIBE_LINK'] = "Non-Transactional Emails must contain an unsubscribe link. Please add an opt out tracker, '{{ unsubscribe_link }}' or select the icon: ";
$app_strings['LBL_VALIDATION_ERROR_REMOVE_UNSUBSCRIBE_LINK'] = "Transactional Emails must NOT contain an unsubscribe link. Please remove '{{ unsubscribe_link }}'";
$app_strings['LBL_VALIDATION_ERROR_EMAIL_FORMAT'] = "Format email tidak valid. Diharapkan: '{{context.expected}}'";
$app_strings['LBL_VALIDATION_ERROR_PHONE_FORMAT'] = "Format telepon tidak valid.";
$app_strings['LBL_VALIDATION_ERROR_MIN'] = "Nilai tidak valid. Nilai harus lebih besar atau sama dengan '{{context.min}}'";
$app_strings['LBL_VALIDATION_ERROR_MAX'] = "Nilai tidak valid. Nilai harus lebih kecil atau sama dengan '{{context.max}}'";
$app_strings['LBL_MULTIPLE_PRIMARY_EMAIL_VALIDATION_ERROR'] = "Only one Valid Email Address should be marked as primary";
$app_strings['LBL_DUPLICATE_EMAIL_VALIDATION_ERROR'] = "Alamat email duplikat tidak diizinkan";
$app_strings['LBL_NO_PRIMARY_EMAIL_VALIDATION_ERROR'] = "One Valid Email Address should be marked as primary";
$app_strings['LBL_NO_EM_ID'] = 'Unable to get Email Marketing ID';
$app_strings['LBL_VALIDATION_ERRORS'] = 'Terjadi kesalahan validasi, tidak dapat menyelesaikan tindakan.';
$app_strings['LBL_LOADING_IN_PROGRESS'] = 'The calculation is currently in progress, please wait a few moments before trying again.';
$app_strings['LBL_SELECT_EMAIL_FOR_TEST'] = 'Please Select Targets/ Users or Enter an Email';
$app_strings['LBL_TYPE_TO_SEARCH'] = 'Ketik untuk mencari...';
$app_strings['LBL_SEARCHING'] = 'mencari...';
$app_strings['LBL_NOT_FOUND'] = 'Tidak ditemukan.';
$app_strings['LBL_SEARCH_ERROR'] = 'Kesalahan dalam pencarian.';
$app_strings['LBL_FOUND'] = 'Ditemukan';
$app_strings['LBL_GET_RECORD_LIST_ERROR'] = 'Terjadi kesalahan saat mengambil catatan';
$app_strings['LBL_NUMBER_OF_RECORDS'] = 'Jumlah Catatan';
$app_strings['LBL_FORWARD_SLASH'] = '/';
$app_strings['LBL_CASES_INSIGHT'] = ' {{fields.cases.value}} ( {{fields.default.value}} )';
$app_strings['LBL_INVOICES_INSIGHT'] = ' {{fields.invoices.value}} ( {{fields.default.value}} )';
$app_strings['LBL_CONTRACT_RENEWAL_TOOLTIP'] = 'Tanggal Pembaruan Kontrak berikutnya';
$app_strings['LBL_INVOICES_OVERDUE_TOOLTIP'] = 'Total Faktur Terlambat';
$app_strings['LBL_ACTIVITIES_NEXT_DATE_TOOLTIP'] = 'Tanggal interaksi berikutnya';
$app_strings['LBL_CAMPAIGN_LAST_RECEIVED_TOOLTIP'] = 'Tanggal Kampanye diterima terbaru';
$app_strings['LBL_OPEN_CASES_COUNT_TOOLTIP'] = 'Total Kasus Dibuka';
$app_strings['LBL_EVENTS_LAST_DATE_TOOLTIP'] = 'Tanggal Acara terbaru';
$app_strings['LBL_HISTORY_LAST_DATE_TOOLTIP'] = 'Tanggal interaksi terbaru';
$app_strings['LBL_OPPORTUNITIES_TOTAL_SUM_TOOLTIP'] = 'Subtotal Kesempatan';
$app_strings['LBL_QUOTES_EXPIRY_TOOLTIP'] = 'Tanggal Batas Waktu Penawaran berikutnya';
$app_strings['LBL_DEFAULT_TOTAL_TOOLTIP'] = 'Total catatan';
$app_strings['LBL_CONTRACT_RENEWAL'] = 'Tanggal Pembaruan';
$app_strings['LBL_INVOICES_OVERDUE'] = 'Total Terlambat';
$app_strings['LBL_ACTIVITIES_NEXT_DATE'] = 'Tanggal Aktifitas Berikutnya';
$app_strings['LBL_CAMPAIGN_LAST_RECEIVED'] = 'Partisipasi Terakhir';
$app_strings['LBL_OPEN_CASES_COUNT'] = 'Kasus Terbuka';
$app_strings['LBL_EVENTS_LAST_DATE'] = 'Acara Dihadiri Terakhir';
$app_strings['LBL_HISTORY_LAST_DATE'] = 'Titiksentuh Terakhir';
$app_strings['LBL_OPPORTUNITIES_TOTAL_SUM'] = 'Nilai Total';
$app_strings['LBL_QUOTES_EXPIRY'] = 'Tanggal Kedaluwarsa Berikutnya';
$app_strings['LBL_DEFAULT_TOTAL'] = 'Total';
$app_strings['AOS_Contracts'] = 'Contracts';
$app_strings['AOS_Quotes'] = 'Quotes';
$app_strings['AOS_Invoices'] = 'Faktur';
$app_strings['LBL_PHOTO'] = 'Photo';
$app_strings['LBL_CASE_UPDATES'] = 'Pembaharuan Kasus';
$app_strings['LBL_CASE_UPDATE_SUBMITTED'] = 'Pembaruan Kasus Dikirim';
$app_strings['LBL_SUMMARY_DEFAULT'] = "{{fields.name.value}}";
$app_strings['LBL_SUMMARY_PERSON'] = "{{fields.salutation.value}} {{fields.first_name.value}} {{fields.last_name.value}}";
$app_strings['LBL_SUMMARY_DOCUMENT'] = "{{fields.document_name.value}}";
$app_strings['LBL_CREATE'] = 'Create';
$app_strings['LBL_CLEAR_FILTER'] = 'Hapus Filter';
$app_strings['LBL_QUICK_FILTERS'] = 'Filter Cepat';
$app_strings['LBL_SAVED_FILTER_SAVED'] = 'Filter berhasil disimpan';
$app_strings['LBL_FILTER_ID_NOT_DEFINED'] = 'Id filter tidak ditentukan';
$app_strings['LBL_GENERIC_CONFIRMATION'] = 'Apakah Anda ingin melanjutkan tindakan ini?';
$app_strings['LBL_SHOW_MORE'] = 'Tampilkan lebih banyak';
$app_strings['LBL_SHOW_LESS'] = 'Tampilkan lebih sedikit';
$app_strings['LBL_LOAD_MORE'] = 'Muat lebih banyak';
$app_strings['LBL_EMPTY'] = '-- Empty --';
$app_strings['LBL_OPERATOR'] = 'Petugas';
$app_strings['LBL_START'] = 'Start';
$app_strings['LBL_END'] = 'Akhir';
$app_strings['LBL_LINE_ITEMS_FIELD_CONFIG'] = 'Konfigurasi buruk';


$app_strings['LBL_ACTION_SUCCESS'] = 'Tindakan berhasil';

$app_strings['LBL_YES'] = 'Ya';
$app_strings['LBL_NO'] = 'No';

$app_list_strings['sort_order'] = [];
$app_list_strings['sort_order']['asc'] = 'Ascending';
$app_list_strings['sort_order']['desc'] = 'Descending';

// Labels used by subpanel unlink relationship process
$app_strings['LBL_LINK'] = 'Tautan';
$app_strings['LBL_LINK_UNLINK'] = 'Link / Unlink';
$app_strings['LBL_SAVE'] = 'Save';
$app_strings['LBL_UNLINK_RECORD'] = 'Batalkan tautan Catatan';
$app_strings['LBL_EDIT_RECORD'] = 'Edit Catatan';
$app_strings['LBL_UNLINK_RELATIONSHIP_CONFIRM'] = 'Apakah Anda yakin ingin melepas tautan rekaman? Hanya tautan hubungan yang akan dilepas. Catatan tidak akan dihapus.';
$app_strings['LBL_UNLINK_RELATIONSHIP_SUCCESS'] = 'Pelepasan tautan catatan berhasil.';
$app_strings['LBL_UNLINK_RELATIONSHIP_FAILED'] = 'Terjadi kesalahan saat melepas tautan catatan.';
$app_strings['LBL_ALL_RECORDS_UNLINKED'] = 'All records unlinked successfully';
$app_strings['LBL_SOME_RECORDS_UNLINKED_FAILED'] = 'There was an issue unlinking some records. See the logs for more.';
$app_strings['LBL_LINK_RELATIONSHIP_SUCCESS'] = 'Penautan hubungan berhasil.';
$app_strings['LBL_LINK_RELATIONSHIP_FAILED'] = 'Terjadi kesalahan saat menautkan Hubungan.';
$app_strings['LBL_MODULE_NOT_FOUND'] = 'Modul tidak ditemukan.';
$app_strings['LBL_RECORD_NOT_FOUND'] = 'Tidak dapat memuat catatan';
$app_strings['LBL_RELATIONSHIP_LOAD_ERROR'] = 'Tidak dapat memuat hubungan';
$app_strings['LBL_NOT_LINKED'] = 'Tidak dapat melepas tautan. Catatan tidak ditautkan';
$app_strings['LBL_ACCESS_DENIED'] = 'Akses Ditolak';
$app_strings['LBL_ADD_RECORDS_TO_TARGET_LIST_SUCCESS'] = 'Catatan berhasil ditambahkan ke daftar target.';
$app_strings['LBL_ADD_RECORDS_TO_TARGET_LIST_FAILED'] = 'Terjadi kesalahan saat menambahkan catatan ke daftar target.';
$app_strings['LBL_ADD_CONTACTS_TO_TARGET_LIST_SUCCESS'] = 'Kontak berhasil ditambahkan ke daftar target.';
$app_strings['LBL_ADD_CONTACTS_TO_TARGET_LIST_FAILED'] = 'Terjadi kesalahan saat menambahkan kontak ke daftar target.';
$app_strings['LBL_CHANGED_TO_TEXT'] = 'diubah menjadi';
$app_strings['LBL_RECORD_CHANGED'] = 'Catatan Diperbarui';
$app_strings['LBL_CREATE'] = "Create";
$app_strings['LBL_USE_ADVANCED_SEARCH'] = 'Gunakan Pencarian Lanjutan';
$app_strings['LBL_USE_BASIC_SEARCH'] = 'Gunakan Pencarian Dasar';
$app_strings['LBL_NO_MODULE_SELECTED'] = 'Tidak ada modul yang dipilih';
$app_strings['LBL_CLOSE_MENU'] = 'Tutup Menu';
$app_strings['LOGIN_INCORRECT'] = 'Kredensial masuk salah, coba lagi.';
$app_strings['LOGIN_TOO_MANY_FAILED'] = 'Terlalu banyak upaya login gagal, coba lagi dalam beberapa menit.';

// PDF Engines
$app_strings['LBL_LEGACY_MPDF_ENGINE'] = 'Legasi Mesin MPDF';
$app_strings['LBL_TCPDF_ENGINE'] = 'Mesin TCPDF';


$app_strings['ERR_INVALID_FILE_NAME'] = 'File nama tidak valid:';
$app_strings['LBL_LOGGER_VALID_FILENAME_CHARACTERS'] = 'Hanya boleh karakter alfanumerik, dan \'.\' , \'-\' atau \'_\'';
$app_strings['LBL_LOGGER_INVALID_FILENAME'] = 'Nama file import tidak valid';

$app_strings['LBL_PASSWORD_SET_NEW_VALUE_TO_RESET'] = 'Kata sandi diatur. Masukkan nilai untuk mengatur kata sandi baru.';
$app_strings['LBL_VALUE_SET_PLACEHOLDER'] = 'Nilai diatur. Masukkan nilai baru untuk menimpa nilai saat ini.';

$app_strings['ERR_IMAP_OAUTH_CONNECTION_ERROR'] = 'Tidak dapat menghubungkan dengan login OAuth menggunakan server Email Masuk. Untuk sambungan: ';
$app_strings['WARN_OAUTH_TOKEN_SESSION_EXPIRED'] = 'Sesi IMAP OAuth telah berakhir, masuk kembali ke sambungan: ';

$app_strings['ERR_OAUTH_CONNECTION_ERROR'] = 'Not able to connect using OAuth login. For connection: ';

$app_strings['LBL_KEY'] = 'Kunci';
$app_strings['LBL_VALUE'] = 'Value';
$app_strings['LBL_OPTIONAL'] = 'Opsional';
$app_strings['LBL_OPTIONAL_CONNECTION_STRING'] = 'Opsional. Atur untuk menggunakan string sambungan khusus';
$app_strings['LBL_OUTBOUND_ACCOUNT'] = 'Akun Keluar';
$app_strings['LBL_INBOUND_ACCOUNT'] = 'Akun Masuk';
$app_strings['LBL_SYSTEM_ACCOUNT'] = 'Akun Sistem';
$app_strings['LBL_FROM_SYSTEM'] = 'Kirim Dari Sistem';
$app_strings['LBL_SIGNATURE'] = 'Tanda tangan';
$app_strings['LBL_NEW_NOTIFICATION'] = "You have {{context.unread}} new notifications";
$app_strings['LBL_NOTIFICATION_ITEM_DATE'] = 'Due: {{fields.date_start.value}}';
$app_strings['LBL_NOTIFICATION_ITEM_DATE_ENTERED'] = 'Notified: {{fields.snooze.value}}';
$app_strings['LBL_QUICK_ACTIONS'] = 'Quick Actions';
$app_strings['LBL_RELATIONSHIPS'] = 'Hubungan';
$app_strings['LBL_SHOW_CC'] = 'Show Cc';
$app_strings['LBL_SHOW_BCC'] = 'Show Bcc';
$app_strings['LBL_CC'] = 'Cc';
$app_strings['LBL_BCC'] = 'Bcc';
$app_strings['LNK_NEW_EMAIL'] = 'Surel Baru';
$app_strings['LBL_INSERT_TEMPLATE'] = 'Insert Template';
$app_strings['LBL_MISSING_RECORD_DATA'] = 'Missing Record Data';
$app_strings['LBL_MISSING_FIELDS_DATA'] = 'Missing Fields Data';
$app_strings['LBL_WRONG_MODULE_PROVIDED'] = 'Wrong module provided';
$app_strings['LBL_NO_TEMPLATE_ID_PROVIDED'] = 'No template id provided';
$app_strings['LBL_TEMPLATE_NOT_FOUND'] = 'Template not found';
$app_strings['LBL_EMAIL_MODAL_DYNAMIC_TITLE'] = 'New Email{{fields.name.value|prefix:\' - \'}}';
$app_strings['LBL_CLOSE_EMAIL_MODAL'] = 'Are you sure you wish to discard this Email? (Changes will be lost)';
$app_strings['LBL_RELATED_TO_DYNAMIC'] = '{{fields.parent_type.value|uppercase}}';
$app_strings['LBL_RELATED_TO'] = 'Related To';
$app_strings['LBL_OUTBOUND_EMAIL_NAME_COMPOSE_LABEL'] = '{{fields.smtp_from_name}}';
$app_strings['LBL_OUTBOUND_EMAIL_NAME_COMPOSE_SUB_LABEL'] = '{{fields.smtp_from_addr}}';
$app_strings['LBL_SMALL'] = 'Small';
$app_strings['LBL_MEDIUM'] = 'Medium';
$app_strings['LBL_NORMAL'] = 'Normal';
$app_strings['LBL_LARGE'] = 'Large';
$app_strings['LBL_HUGE'] = 'Huge';
$app_strings['LBL_DEFAULT'] = 'Standar';
$app_strings['LBL_APPLY'] = 'Menggunakan';
$app_strings['LBL_INSERT_LINK_URL_DESCRIPTION'] = 'Insert URL or email:';
$app_strings['LBL_INSERT_LINK_PLACEHOLDER'] = 'e.g.: https://www.example.com';

$app_strings['LBL_COLOR_BLACK'] = 'Black';
$app_strings['LBL_COLOR_FIREBRICK'] = 'Firebrick';
$app_strings['LBL_COLOR_RED'] = 'Red';
$app_strings['LBL_COLOR_SALMON'] = 'Salmon';
$app_strings['LBL_COLOR_BLUSH'] = 'Blush';
$app_strings['LBL_COLOR_DARK_RED'] = 'Dark Red';
$app_strings['LBL_COLOR_BROWN'] = 'Brown';
$app_strings['LBL_COLOR_DARK_ORANGE'] = 'Dark Orange';
$app_strings['LBL_COLOR_ORANGE'] = 'Orange';
$app_strings['LBL_COLOR_ANTIQUE_WHITE'] = 'Antique White';
$app_strings['LBL_COLOR_SADDLE_BROWN'] = 'Saddle Brown';
$app_strings['LBL_COLOR_GOLDENROD'] = 'Golden Rod';
$app_strings['LBL_COLOR_GOLD'] = 'Gold';
$app_strings['LBL_COLOR_YELLOW'] = 'Yellow';
$app_strings['LBL_COLOR_LIGHT_YELLOW'] = 'Light Yellow';
$app_strings['LBL_COLOR_DARK_SLATE_GRAY'] = 'Dark Slate Grey';
$app_strings['LBL_COLOR_DARK_GREEN'] = 'Dark Green';
$app_strings['LBL_COLOR_GREEN'] = 'Green';
$app_strings['LBL_COLOR_LIME'] = 'Lime';
$app_strings['LBL_COLOR_HONEYDEW'] = 'Honeydew';
$app_strings['LBL_COLOR_TEAL'] = 'Teal';
$app_strings['LBL_COLOR_TURQUOISE'] = 'Turquoise';
$app_strings['LBL_COLOR_AQUA'] = 'Aqua';
$app_strings['LBL_COLOR_PALE_TURQUOISE'] = 'Pale Turquoise';
$app_strings['LBL_COLOR_AZURE'] = 'Azure';
$app_strings['LBL_COLOR_NAVY_BLUE'] = 'Navy Blue';
$app_strings['LBL_COLOR_MEDIUM_BLUE'] = 'Medium Blue';
$app_strings['LBL_COLOR_BLUE'] = 'Blue';
$app_strings['LBL_COLOR_LIGHT_BLUE'] = 'Light Blue';
$app_strings['LBL_COLOR_ALICE_BLUE'] = 'Alice Blue';
$app_strings['LBL_COLOR_INDIGO'] = 'Indigo';
$app_strings['LBL_COLOR_PATRIARCH_PURPLE'] = 'Patriarch Purple';
$app_strings['LBL_COLOR_VIOLET_PURPLE'] = 'Violet Purple';
$app_strings['LBL_COLOR_PLUM'] = 'Plum';
$app_strings['LBL_COLOR_LAVENDER'] = 'Lavender';
$app_strings['LBL_COLOR_DIM_GRAY'] = 'Dim Gray';
$app_strings['LBL_COLOR_GRAY'] = 'Gray';
$app_strings['LBL_COLOR_DARK_GRAY'] = 'Dark Gray';
$app_strings['LBL_COLOR_LIGHT_GRAY'] = 'Light Gray';
$app_strings['LBL_COLOR_WHITE'] = 'White';

$app_strings['LBL_BOLD'] = 'Tebal';
$app_strings['LBL_ITALIC'] = 'Miring';
$app_strings['LBL_UNDERLINE'] = 'Underline';
$app_strings['LBL_STRIKETHROUGH'] = 'Strikethrough';
$app_strings['LBL_FONT_FACE'] = 'Font Face';
$app_strings['LBL_TEXT_SIZE'] = 'Text Size';
$app_strings['LBL_TEXT_COLOR'] = 'Text Color';
$app_strings['LBL_TEXT_HIGHLIGHT'] = 'Text Highlight';
$app_strings['LBL_LINK'] = 'Tautan';
$app_strings['LBL_UNORDERED_LIST'] = 'Unordered List';
$app_strings['LBL_ORDERED_LIST'] = 'Ordered List';
$app_strings['LBL_QUOTE'] = 'Kutipan';
$app_strings['LBL_UNQUOTE'] = 'Unquote';
$app_strings['LBL_ALIGN_LEFT'] = 'Ke Kiri';
$app_strings['LBL_ALIGN_CENTER'] = 'Center';
$app_strings['LBL_ALIGN_RIGHT'] = 'Kanan';
$app_strings['LBL_JUSTIFY'] = 'Justify';
$app_strings['LBL_TEXT_LEFT_TO_RIGHT'] = 'Text Direction: Left to Right';
$app_strings['LBL_TEXT_RIGHT_TO_LEFT'] = 'Text Direction: Right to Left';
$app_strings['LBL_CLEAR_FORMATTING'] = 'Clear Formatting';
$app_strings['LBL_INJECT_UNSUBSCRIBE'] = 'Unsubscribe Link';
$app_strings['LBL_TEXT_INDENT_LEFT'] = 'Indent Text Left';
$app_strings['LBL_TEXT_INDENT_RIGHT'] = 'Indent Text Right';

// Day and Time labels
$app_strings['LBL_SUN'] = 'Sunday';
$app_strings['LBL_MON'] = 'Monday';
$app_strings['LBL_TUE'] = 'Tuesday';
$app_strings['LBL_WED'] = 'Wednesday';
$app_strings['LBL_THU'] = 'Thursday';
$app_strings['LBL_FRI'] = 'Friday';
$app_strings['LBL_SAT'] = 'Saturday';
$app_strings['LBL_ALL'] = 'Every Day';
$app_strings['LBL_EVERY'] = 'Setiap';
$app_strings['LBL_ON_THE'] = 'On the';
$app_strings['LBL_RANGE'] = 'to';
$app_strings['LBL_FROM'] = 'From';
$app_strings['LBL_AND'] = 'dan';
$app_strings['LBL_MINS'] = 'Menit';
$app_strings['LBL_MINUTES'] = 'menit';
$app_strings['LBL_HOUR'] = 'jam';
$app_strings['LBL_HOUR_SING'] = 'jam';
$app_strings['LBL_OFTEN'] = 'As often as possible.';
$app_strings['LBL_MIN_MARK'] = 'minute mark';
$app_strings['LBL_INBOUND_EMAIL'] = 'Inbound Email';

$app_strings['LBL_LEGEND'] = 'Legend';

$app_strings['LBL_EMAIL_MARKETING_NOT_UNSCHEDULED'] = 'Email Marketing is not Un Scheduled cannot schedule';
$app_strings['LBL_INCORRECT_RECORD_ID'] = 'Incorrect record id';

$app_strings['LBL_TEST_ENTRIES_DELETED'] = 'Test Entries Deleted.';
$app_strings['LBL_UNABLE_TO_GET_ID'] = 'Unable to retrieve Email Marketing ID';
$app_strings['LBL_UNABLE_TO_DELETE_TEST_ENTRIES'] = 'Error Deleting Test Entries. See logs for more info';
$app_strings['LBL_SECTION_KEY_NOT_DEFINED'] = 'Section key not defined';
$app_strings['LBL_DOES_BOUNCE_EXIST'] = 'Does a Bounce Email exist?';
$app_strings['LBL_CAMPAIGN_SETTINGS'] = 'Settings';

$app_strings['LBL_SEND_FROM_QUEUE_DYNAMIC_LABEL'] = '{{ fields.send-from-queue.value }}';
$app_strings['LBL_EMAIL_TO_QUEUE_DYNAMIC_LABEL'] = '{{ fields.email-to-queue.value }}';
$app_strings['LBL_POLL_BOUNCED_CAMPAIGN_DYNAMIC_LABEL'] = '{{ fields.pollMonitoredInboxesForBouncedCampaignEmails.value }}';

$app_strings['LBL_CRON_LINUX_DESC1_DYNAMIC'] = '{{ fields.desc1.value }}';
$app_strings['LBL_CRON_LINUX_DESC2_DYNAMIC'] = '{{ fields.desc2.value }}';
$app_strings['LBL_CRON_LINUX_DESC3_DYNAMIC'] = '{{ fields.desc3.value }}';
$app_strings['LBL_CRON_LINUX_DESC4_DYNAMIC'] = '{{ fields.desc4.value }}';
$app_strings['LBL_CRON_LINUX_DESC5_DYNAMIC'] = '{{ fields.desc5.value }}';
$app_strings['LBL_CRON_LINUX_DESC6_DYNAMIC'] = '{{ fields.desc6.value }}';
$app_strings['LBL_CRON_LINUX_DESC7_DYNAMIC'] = '{{ fields.desc7.value }}';
$app_strings['LBL_CRON_LINUX_DESC8_DYNAMIC'] = '{{ fields.desc8.value }}';

$app_strings['LBL_CRON_WIN_DESC1_DYNAMIC'] = '{{ fields.desc1.value }}';
$app_strings['LBL_CRON_WIN_DESC2_DYNAMIC'] = '{{ fields.desc2.value }}';
$app_strings['LBL_CRON_WIN_DESC3_DYNAMIC'] = '{{ fields.desc3.value }}';
$app_strings['LBL_CRON_WIN_DESC4_DYNAMIC'] = '{{ fields.desc4.value }}';
$app_strings['LBL_CRON_WIN_DESC5_DYNAMIC'] = '{{ fields.desc5.value }}';

$app_strings['LBL_CRON_LAST_RUN'] = 'Last successful run';
$app_strings['LBL_CRON_LAST_USER_TO_RUN'] = 'Last user to run schedulers';
$app_strings['LBL_LAST_RUN_VALUE'] = '{{ fields.lastRun.value }}';
$app_strings['LBL_LAST_USER_RUN_VALUE'] = '{{ fields.user.value }}';
$app_strings['LBL_RUN_USER_INVALID'] = 'This user is not part of `allowed_cron_users` config setting. Therefore the last run was not successful';
$app_strings['LBL_SCHEDULERS_NEVER_RUN'] = 'Schedulers have never been run.';
$app_strings['LBL_MARKETING_ITEMS_PER_RUN'] = 'Campaign Marketing Items Per Run';
$app_strings['LBL_EMAILS_PER_RUN'] = 'Campaign Emails Per Run';
$app_strings['LBL_TRACKERS_ENABLED'] = 'Trackers Enabled';
$app_strings['LBL_TRACKER_LINKS_ENABLED'] = 'Tracker Links Enabled';

$app_strings['LBL_MARKETING_ITEMS_PER_RUN_DYNAMIC_LABEL'] = '{{ fields.campaign_marketing_items_per_run.value }}';
$app_strings['LBL_EMAILS_PER_RUN_DYNAMIC_LABEL'] = '{{ fields.campaign_emails_per_run.value }}';
$app_strings['LBL_TRACKERS_ENABLED_DYNAMIC_LABEL'] = '{{ fields.trackers_enabled.value }}';
$app_strings['LBL_UNSUBSCRIBE'] = 'Unsubscribe';
$app_strings['LBL_INACTIVE'] = 'Inactive';
$app_strings['LBL_DISPLAYING_TEST_EMAIL_MARKETING_DATA'] = 'Charts and Subpanels currently displaying data generated from Test Emails.';
$app_strings['LBL_DASH_SYMBOL'] = '-';
$app_strings['LBL_FIELD_STORAGE_NOT_SET'] = 'File storage type not set for field. Unable to upload file.';
$app_strings['LBL_FIELD_STORAGE_INVALID_TYPE'] = 'File storage type is not valid for field. Unable to upload file.';
$app_strings['LBL_UPLOAD'] = 'Upload';
$app_strings['LBL_UPLOAD_FAILED'] = 'Upload failed, please try again later';
$app_strings['LBL_UPLOADING'] = 'Uploading';
$app_strings['LBL_FILE_FIELD_UPLOAD_BUTTON_DESCRIPTION'] = 'Click or drag a file here to upload';
$app_strings['LBL_ATTACHMENTS_FIELD_UPLOAD_BUTTON_DESCRIPTION'] = 'Drag and drop a file here to upload';
$app_strings['LBL_TEMPORARY'] = 'Temporary';
$app_strings['LBL_MAX_FILE_SIZE_EXCEEDED'] = 'The file exceeds the maximum allowed size.';
$app_strings['LBL_UNSUPPORTED_IMAGE_TYPE'] = 'The image type is not supported.';
$app_strings['LBL_UNSUPPORTED_FILE_TYPE'] = 'The file type is not supported.';

$app_strings['LBL_DEFAULT_OUTBOUND_NOT_SET'] = 'Unable to retrieve Default Outbound Email';
$app_strings['LBL_DEFAULT_OUTBOUND_NOT_CONFIGURED'] = 'Outbound Email Account not correctly configured.';

$app_strings['LBL_CRON_UNRECOMMENDED_USER'] = 'You are currently running as root, this is NOT recommended, would you like to continue (y,n)? ';
$app_strings['LBL_UNKNOWN_USER'] = 'Unknown User';
