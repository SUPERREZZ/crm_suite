<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
    'LBL_ASSIGNED_TO_NAME' => 'Ditugaskan kepada',
    'LBL_ID' => 'ID',
    'LBL_DATE_ENTERED' => 'Tanggal Dibuat',
    'LBL_DATE_MODIFIED' => 'Tanggal diubah',
    'LBL_MODIFIED' => 'Modified By',
    'LBL_MODIFIED_NAME' => 'Modifikasi berdasarkan Nama',
    'LBL_CREATED' => 'Created By',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_DELETED' => 'Deleted',
    'LBL_NAME' => 'Nama Produk',
    'LBL_CREATED_USER' => 'Dibuat oleh Pengguna',
    'LBL_MODIFIED_USER' => 'Modified by User',
    'LBL_LIST_FORM_TITLE' => 'Daftar Produk',
    'LBL_MODULE_NAME' => 'Products',
    'LBL_MODULE_TITLE' => 'Produk: Rumah',
    'LBL_HOMEPAGE_TITLE' => 'Produk Saya',
    'LNK_NEW_RECORD' => 'Membuat Produk',
    'LNK_LIST' => 'Melihat Produk',
    'LBL_SEARCH_FORM_TITLE' => 'Mencari Produk',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
    'LBL_NEW_FORM_TITLE' => 'Produk Baru',
    'LBL_MAINCODE' => 'Kode Produk',
    'VALUE' => 'Nama Produk',
    'LBL_PART_NUMBER' => 'Part Number',
    'LBL_CATEGORY' => 'Category',
    'LBL_TYPE' => 'Jenis Produk',
    'LBL_COST' => 'Biaya',
    'LBL_PRICE' => 'Harga',
    'LBL_URL' => 'URL',
    'LBL_CONTACT' => 'Contact',
    'LBL_PRODUCT_IMAGE' => 'Gambar Produk',
    'LBL_IMAGE_UPLOAD_FAIL' => 'ERROR: uploaded file exceeded the max filesize: max filesize: ',
    'LBL_AOS_PRODUCT_CATEGORYS_NAME' => 'Kategori Produk',
    'LBL_AOS_PRODUCT_CATEGORY' => 'Kategori ID Produk',
    'LBL_AOS_PRODUCT_CATEGORIES' => 'Product Categories',
    'LBL_COST_USDOLLAR' => 'Biaya (Mata Uang Baku)',
    'LBL_PRICE_USDOLLAR' => 'Harga (Mata Uang Baku)',
    'LBL_FILE_URL' => 'Berkas URL',
    'LBL_CUSTOMERS_PURCHASED_PRODUCTS_SUBPANEL_TITLE' => 'Pembelian',
    'LBL_PRODUCTS_PURCHASES' => 'Pembelian',
    'LBL_AOS_QUOTE_NAME' => 'Kutipan',
    'LBL_ACCOUNT_NAME' => 'Akun',
);
