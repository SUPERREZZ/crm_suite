<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
    'LBL_ASSIGNED_TO_NAME' => 'Ditugaskan kepada',
    'LBL_ID' => 'ID',
    'LBL_DATE_ENTERED' => 'Tanggal Dibuat',
    'LBL_DATE_MODIFIED' => 'Tanggal diubah',
    'LBL_MODIFIED' => 'Modified By',
    'LBL_MODIFIED_NAME' => 'Modifikasi berdasarkan Nama',
    'LBL_CREATED' => 'Created By',
    'LBL_DESCRIPTION' => 'Description',
    'LBL_DELETED' => 'Deleted',
    'LBL_NAME' => 'Nama ',
    'LBL_CREATED_USER' => 'Dibuat oleh Pengguna',
    'LBL_MODIFIED_USER' => 'Modified by User',
    'LBL_LIST_NAME' => 'Nama ',
    'LBL_EDIT_BUTTON' => 'Sunting',
    'LBL_REMOVE' => 'Remove',
    'LBL_LIST_FORM_TITLE' => 'Daftar Laporan',
    'LBL_MODULE_NAME' => 'Reports',
    'LBL_MODULE_TITLE' => 'Reports',
    'LBL_HOMEPAGE_TITLE' => 'Laporan Saya',
    'LNK_NEW_RECORD' => 'Memilih Laporan',
    'LNK_LIST' => 'Laporan',
    'LBL_SEARCH_FORM_TITLE' => 'Mencari Laporan',
    'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
    'LBL_NEW_FORM_TITLE' => 'Laporan Baru',
    'LBL_REPORT_MODULE' => 'Modul Laporan',
    'LBL_GRAPHS_PER_ROW' => 'Grafik per baris',
    'LBL_FIELD_LINES' => 'Bidang Tampilan',
    'LBL_ADD_FIELD' => 'Tambah Field',
    'LBL_CONDITION_LINES' => 'Kondisi',
    'LBL_ADD_CONDITION' => 'Tambahkan Kondisi',
    'LBL_EXPORT' => 'Export',
    'LBL_DOWNLOAD_PDF' => 'Unduh PDF',
    'LBL_ADD_TO_PROSPECT_LIST' => 'Add To Target List',
    'LBL_AOR_MODULETREE_SUBPANEL_TITLE' => 'Modul Pokok',
    'LBL_AOR_FIELDS_SUBPANEL_TITLE' => 'Bidang',
    'LBL_AOR_CONDITIONS_SUBPANEL_TITLE' => 'Kondisi',
    'LBL_TOTAL' => 'Total',
    'LBL_AOR_CHARTS_SUBPANEL_TITLE' => 'Charts',
    'LBL_ADD_CHART' => 'Tambah grafik',
    'LBL_ADD_PARENTHESIS' => 'Drop parenthesis',
    'LBL_CHART_TITLE' => 'Title',
    'LBL_CHART_TYPE' => 'Type',
    'LBL_CHART_X_FIELD' => 'Sumbu X',
    'LBL_CHART_Y_FIELD' => 'Sumbu Y',
    'LBL_AOR_REPORTS_DASHLET' => 'Reports',
    'LBL_DASHLET_TITLE' => 'Title',
    'LBL_DASHLET_REPORT' => 'Laporan',
    'LBL_DASHLET_CHOOSE_REPORT' => 'Silakan pilih sebuah laporan',
    'LBL_DASHLET_SAVE' => 'Save',
    'LBL_DASHLET_CHARTS' => 'Charts',
    'LBL_DASHLET_ONLY_CHARTS' => 'Hanya menunjukkan grafik',
    'LBL_UPDATE_PARAMETERS' => 'Memperbarui',
    'LBL_PARAMETERS' => 'Parameter',
    'LBL_TOOLTIP_DRAG_DROP_ELEMS' => 'Tarik dan lepaskan elemen ke area lapangan atau kondisi',
    'LBL_MAIN_GROUPS' => 'Grup Pokok:',
    'LBL_CHAR_UNNAMED_DEFAULT_TITLE' => 'Grafik yang tak dikenal',
    'LBL_REPORT' => 'Laporan',
);
