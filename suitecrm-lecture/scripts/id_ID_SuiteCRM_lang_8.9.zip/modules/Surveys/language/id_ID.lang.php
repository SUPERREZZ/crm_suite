<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

$mod_strings = array(
    'LBL_ASSIGNED_TO_ID'                                     => 'Assigned User Id',
    'LBL_ADD_OPTION'                                         => 'Add new option',
    'LBL_ASSIGNED_TO_NAME'                                   => 'Ditugaskan kepada',
    'LBL_SECURITYGROUPS'                                     => 'Grup Keamanan',
    'LBL_SECURITYGROUPS_SUBPANEL_TITLE'                      => 'Grup Keamanan',
    'LBL_ID'                                                 => 'ID',
    'LBL_DATE_ENTERED'                                       => 'Tanggal Dibuat',
    'LBL_DATE_MODIFIED'                                      => 'Tanggal diubah',
    'LBL_MODIFIED'                                           => 'Modified By',
    'LBL_MODIFIED_ID'                                        => 'Modified By Id',
    'LBL_MODIFIED_NAME'                                      => 'Modifikasi berdasarkan Nama',
    'LBL_CREATED'                                            => 'Created By',
    'LBL_CREATED_ID'                                         => 'Created By Id',
    'LBL_DESCRIPTION'                                        => 'Description',
    'LBL_DELETED'                                            => 'Deleted',
    'LBL_NAME'                                               => 'Nama ',
    'LBL_CREATED_USER'                                       => 'Dibuat oleh Pengguna',
    'LBL_MODIFIED_USER'                                      => 'Modified by User',
    'LBL_LIST_NAME'                                          => 'Nama ',
    'LBL_EDIT_BUTTON'                                        => 'Sunting',
    'LBL_REMOVE'                                             => 'Remove',
    'LBL_LIST_FORM_TITLE'                                    => 'Daftar survei',
    'LBL_MODULE_NAME'                                        => 'Survei',
    'LBL_MODULE_TITLE'                                       => 'Survei',
    'LBL_HOMEPAGE_TITLE'                                     => 'Survei saya',
    'LNK_NEW_RECORD'                                         => 'Buatkan survei',
    'LNK_LIST'                                               => 'Tampilan survei',
    'LNK_IMPORT_SURVEYS'                                     => 'Mengimpor survei',
    'LBL_SEARCH_FORM_TITLE'                                  => 'Mencari survei',
    'LBL_HISTORY_SUBPANEL_TITLE'                             => 'View History',
    'LBL_ACTIVITIES_SUBPANEL_TITLE'                          => 'Activities',
    'LBL_SURVEYS_SUBPANEL_TITLE'                             => 'Survei',
    'LBL_NEW_FORM_TITLE'                                     => 'Survei baru',
    'LBL_STATUS'                                             => 'Status',
    'LBL_SURVEY_QUESTIONS_DISPLAY'                           => 'Pertanyaan',
    'LBL_SURVEY_URL_DISPLAY'                                 => 'URL',
    'LBL_HAPPINESS_QUESTION'                                 => 'Pertanyaan Kebahagiaan',
    'LBL_CANT_EDIT_RESPONDED'                                => 'Pertanyaan-pertanyaan survei dengan tanggapan tidak dapat diedit',
    'LBL_VIEW_SURVEY_REPORTS'                                => 'Laporan tampilan survei',
    'LBL_CHECKED'                                            => 'Dicek',
    'LBL_UNCHECKED'                                          => 'Tidak dicek',
    'LBL_RESPONSE_ANSWER'                                    => 'Jawab',
    'LBL_RESPONSE_CONTACT'                                   => 'Contact',
    'LBL_RESPONSE_TIME'                                      => 'Date',
    'LBL_UNKNOWN_CONTACT'                                    => 'Unknown',
    'LBL_RESPONSE_COUNT'                                     => 'Hitung',
    'LBL_SUBMIT_TEXT'                                        => 'Kirim teks',
    'LBL_SATISFIED_TEXT'                                     => 'Teks yang memenuhi',
    'LBL_NEITHER_TEXT'                                       => 'Selain teks',
    'LBL_DISSATISFIED_TEXT'                                  => 'Teks yang tidak memenuhi',
    'LBL_SURVEYS_SURVEYQUESTIONS_FROM_SURVEYQUESTIONS_TITLE' => 'Pertanyaan survei',
    'LBL_SURVEYS_SURVEYRESPONSES_FROM_SURVEYRESPONSES_TITLE' => 'Tanggapan survei',
    'LBL_SHOW_RESPONSES' => 'Show responses',
    'LBL_HIDE_RESPONSES' => 'Hide responses',
    'LNK_LIST_SURVEY_RESPONSES' => 'Show Survey Responses',
    'LBL_SURVEY_QUESTION' => 'Question',
    'LBL_SURVEY_TEXT' => 'Tulisan',
    'LBL_SURVEY_TYPE' => 'Type',
    'LBL_SURVEY_ACTIONS' => 'Actions',
    'LBL_SURVEY_NEW_QUESTION' => 'New Question',
    'LBL_SURVEY_RESPONSES' => 'New Question',
    'LBL_SURVEYS_SENT' => 'Surveys Sent:',
    'LBL_SURVEY_DISTINCT' => 'Distinct Surveys Sent:',
    'LBL_DRAFT' => 'Draft',
    'LBL_SUBMIT' => 'Menyerahkan',
    'LBL_STARS' => 'Stars',
    'LBL_SURVEY_CLOSE_RESPONSE' => 'Thanks for your interest but this survey is now closed.',
    'LBL_SURVEY_THANKS' => 'Thanks for completing this survey.',
);
