<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    //module
    'LBL_MODULE_NAME' => 'Revisi Dokumen',

    'LNK_NEW_DOCUMENT' => 'Create Document',
    'LNK_DOCUMENT_LIST' => 'Lihat Dokumen',

    //vardef labels
    'LBL_REVISION_NAME' => 'Revision Number',
    'LBL_FILENAME' => 'File:',
    'LBL_MIME' => 'Tipe Mime',
    'LBL_REVISION' => 'Revision',
    'LBL_DOCUMENT' => 'Related Document',
    'LBL_LATEST_REVISION' => 'Latest Revision',
    'LBL_CHANGE_LOG' => 'Change Log',
    'LBL_ACTIVE_DATE' => 'Publish Date',
    'LBL_EXPIRATION_DATE' => 'Expiration Date',
    'LBL_FILE_EXTENSION' => 'Ekstensi Berkas',

    'LBL_DOC_NAME' => 'Document Name:',
    'LBL_DOC_VERSION' => 'Revision:',

    //document revisions.
    'LBL_REV_LIST_REVISION' => 'Revision',
    'LBL_REV_LIST_ENTERED' => 'Tanggal Dibuat',
    'LBL_REV_LIST_CREATED' => 'Created by',
    'LBL_REV_LIST_LOG' => 'Change Log',
    'LBL_REV_LIST_FILENAME' => 'File',

    'LBL_CURRENT_DOC_VERSION' => 'Revisi terbaru:',
    'LBL_SEARCH_FORM_TITLE' => 'Document Search',
    'LBL_REVISIONS' => 'Revisi',

    //error messages
    'ERR_FILENAME' => 'File Name',
    'ERR_DOC_VERSION' => 'Versi Dokumen',
    'ERR_DELETE_CONFIRM' => 'Apakah Anda ingin menghapus revisi dokumen ini?',
    'ERR_DELETE_LATEST_VERSION' => 'Anda tidak diizinkan untuk menghapus revisi terbaru dokumen.',
    'LNK_NEW_MAIL_MERGE' => 'Menggabungkan surat',
    'LBL_DOC_ID' => 'ID sumber dokumen',
    'LBL_DOC_TYPE' => 'Sumber',
    'LBL_DOC_URL' => 'Document Source URL',

    'LBL_CREATED_BY_NAME' => 'Dibuat menurut Nama',
);
