<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_MODULE_NAME' => 'Menggabungkan data',
    'LBL_MODULE_TITLE' => 'Menggabungkan Rekaman: Beranda',
    'LBL_SEARCH_FORM_TITLE' => 'Merge pencarian',
    'LBL_LIST_FORM_TITLE' => 'Daftar Merge',

    'LBL_LBL_MERGE_RECORDS_STEP_1' => 'Langkah 1: Cari Pencarian Records untuk Merge Dengan',
    'LBL_AVAIL_FIELDS' => 'Available Fields',
    'LBL_FILTER_COND' => 'Filter Kondisi',
    'LBL_MERGE_VALUE_OVER' => 'Merge nilai dengan',

    'LBL_NEXT_STEP_TITLE' => 'Pindahkan ke Langkah Berikutnya',
    'LBL_NEXT_STEP_BUTTON_LABEL' => 'Langkah Selanjutnya>',

    'LBL_PERFORM_MERGE_BUTTON_TITLE' => 'Lakukan Merge',
    'LBL_PERFORM_MERGE_BUTTON_KEY' => 'P',
    'LBL_PERFORM_MERGE_BUTTON_LABEL' => 'Perform Merge',

    'LBL_SAVE_MERGED_RECORD_BUTTON_TITLE' => 'Simpan Merge',
    'LBL_SAVE_MERGED_RECORD_BUTTON_LABEL' => 'Save Merge',

    'LBL_STEP2_FORM_TITLE' => 'Records Found Untuk Bergabung Dengan:',
    'LBL_SELECT_ERROR' => 'Anda harus membuat pilihan sebelum Anda dapat melanjutkan.',
    'LBL_CHANGE_PARENT' => 'Atur sebagai primer',
    'LBL_REMOVE_FROM_MERGE' => 'Remove',
    'LBL_DIFF_COL_VALUES' => 'Kolom yang nilainya di baris utama berbeda dari penggabungan nilai dalam baris:',
    'LBL_SAME_COL_VALUES' => 'Kolom yang nilainya sama di semua baris:',
    'LBL_DELETE_MESSAGE' => 'Tindakan ini akan menghapus catatan berikut:',
    'LBL_PROCEED' => 'Lanjutkan?',
    'LBL_STEP1_DIRECTIONS' => 'Temukan record duplikat yang mungkin ada. Jika record yang mungkin duplikat ditemukan, Anda bisa memilih record mana yang yang dimerge dengan record tersebut.',
);
