<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2019 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */

if (!defined('sugarEntry') || !sugarEntry) {
    die('Not A Valid Entry Point');
}

$mod_strings = array(
    'LBL_LIST_ID' => 'ID Daftar Prospek',
    'LBL_ID' => 'ID',
    'LBL_TARGET_TRACKER_KEY' => 'Mengunci Target',
    'LBL_TARGET_ID' => 'ID Target',
    'LBL_TARGET_TYPE' => 'Tipe Target',
    'LBL_ACTIVITY_TYPE' => 'Tipe Aktivitas',
    'LBL_ACTIVITY_DATE' => 'Tanggal Aktivitas',
    'LBL_RELATED_ID' => 'ID Terkait',
    'LBL_RELATED_TYPE' => 'Tipe Terkait',
    'LBL_DELETED' => 'Deleted',
    'LBL_MODULE_NAME' => 'Campaign Log',
    'LBL_LIST_RECIPIENT_EMAIL' => 'Email penerima',
    'LBL_LIST_TRACKER_URL' => 'Tracker Url',
    'LBL_LIST_RECIPIENT_NAME' => 'Nama penerima',
    'LBL_ARCHIVED' => 'Archived',
    'LBL_HITS' => 'Menemukan',

    'LBL_CAMPAIGN_NAME' => 'Name:',
    'LBL_CAMPAIGN' => 'Campaign:',
    'LBL_NAME' => 'Nama:',
    'LBL_INVITEE' => 'Contacts',
    'LBL_LIST_CAMPAIGN_NAME' => 'Campaign',
    'LBL_LIST_STATUS' => 'Status',
    'LBL_LIST_TYPE' => 'Type',
    'LBL_LIST_END_DATE' => 'End Date',
    'LBL_DATE_ENTERED' => 'Tanggal dimasukkan',
    'LBL_DATE_MODIFIED' => 'Tanggal diubah',
    'LBL_MODIFIED' => 'Diubah oleh',
    'LBL_CREATED' => 'Dibuat oleh',
    'LBL_TEAM' => 'Tim',
    'LBL_ASSIGNED_TO' => 'Ditugaskan kepada:',
    'LBL_CAMPAIGN_START_DATE' => 'Tanggal mulai:',
    'LBL_CAMPAIGN_END_DATE' => 'Tanggal akhir:',
    'LBL_CAMPAIGN_STATUS' => 'Status: ',
    'LBL_CAMPAIGN_BUDGET' => 'Anggaran:',
    'LBL_CAMPAIGN_EXPECTED_COST' => 'Perkiraan Biaya',
    'LBL_CAMPAIGN_ACTUAL_COST' => 'Biaya Sesugguhnya',
    'LBL_CAMPAIGN_EXPECTED_REVENUE' => 'Perkiraan Pemasukan',
    'LBL_CAMPAIGN_TYPE' => 'Tipe',
    'LBL_CAMPAIGN_OBJECTIVE' => 'Objektif',
    'LBL_CAMPAIGN_CONTENT' => 'Description: ',
    'LBL_CREATED_LEAD' => 'Lead yang dibuat',
    'LBL_CREATED_CONTACT' => 'Kontak yang dibuat',
    'LBL_CREATED_OPPORTUNITY' => 'Mencipatakan Peluang',
    'LBL_TARGETED_USER' => 'Pengguna Target',
    'LBL_SENT_EMAIL' => 'Email terkirim',
    'LBL_LIST_FORM_TITLE' => 'Target Kampanye',
    'LBL_LIST_ACTIVITY_DATE' => 'Activity Date',
    'LBL_RELATED' => 'Related',
    'LBL_MORE_INFO' => 'Informasi Lebih Lanjut',

    'LBL_CAMPAIGNS' => 'Campaigns',
    'LBL_LIST_MARKETING_NAME' => 'Marketing Name',

    'LBL_MARKETING_ID' => 'Marketing Id',
    'LBL_RELATED_NAME' => 'Nama yang Terkait',
);
